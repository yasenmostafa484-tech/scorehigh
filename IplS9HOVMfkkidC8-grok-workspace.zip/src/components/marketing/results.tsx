import * as Dialog from "@radix-ui/react-dialog";
import { useEffect, useState } from "react";
import { reports } from "@/lib/content";
import { useT } from "@/lib/use-t";
import { cn } from "@/lib/utils";

function pos(score: number) {
  return ((score - 400) / 400) * 100;
}

export function Results() {
  const { t, lang } = useT();
  const [active, setActive] = useState(reports[0].id);
  const [open, setOpen] = useState(false);
  const [drawn, setDrawn] = useState(false);
  const report = reports.find((r) => r.id === active) ?? reports[0];

  useEffect(() => {
    setDrawn(false);
    const id = window.requestAnimationFrame(() => setDrawn(true));
    return () => window.cancelAnimationFrame(id);
  }, [active, open]);

  return (
    <section className="border-y border-line bg-sheet/60">
      <div className="mx-auto max-w-6xl px-4 py-16 sm:py-24">
        <p className="font-mono text-xs tracking-stamp text-mark uppercase">{t.results.eyebrow}</p>
        <h2 className="mt-3 max-w-3xl font-display text-4xl leading-none sm:text-6xl">{t.results.title}</h2>
        <p className="mt-4 max-w-2xl text-muted">{t.results.lede}</p>

        <div className="mt-8 flex gap-2" role="tablist" aria-label={t.results.eyebrow}>
          {reports.map((item) => (
            <button
              key={item.id}
              role="tab"
              aria-selected={active === item.id}
              onClick={() => setActive(item.id)}
              className={cn(
                "min-h-11 rounded-full border px-4 text-sm font-semibold",
                active === item.id ? "border-ink bg-ink text-paper" : "border-line",
              )}
            >
              {item.name}
            </button>
          ))}
        </div>

        <Ladder reportId={report.id} drawn={drawn} />

        <div className="mt-6 flex flex-wrap items-end justify-between gap-4">
          <p className="max-w-xl text-sm text-muted">{lang === "ar" ? report.noteAr : report.noteEn}</p>
          <button
            type="button"
            onClick={() => setOpen(true)}
            className="min-h-11 rounded-full border border-line px-4 text-sm font-semibold"
          >
            {t.results.enlarge}
          </button>
        </div>
        <p className="mt-4 text-xs text-muted">{t.results.only}</p>

        <div className="mt-10 grid gap-4 sm:grid-cols-2">
          {reports.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                setActive(item.id);
                setOpen(true);
              }}
              className="border border-line bg-paper p-5 text-start"
            >
              <p className="font-mono text-xs text-muted">{t.results.rw}</p>
              <p className="mt-2 font-display text-4xl leading-none tabular-nums">
                {item.rwFrom}
                <span className="text-mark"> → </span>
                {item.rwTo}
              </p>
              <p className="mt-3 text-sm">{lang === "ar" ? item.totalLabelAr : item.totalLabel}</p>
              <p className="mt-4 text-sm text-muted">{item.name}</p>
            </button>
          ))}
          {[1, 2].map((n) => (
            <div key={n} className="border border-dashed border-line p-5">
              <p className="font-mono text-xs tracking-stamp text-muted uppercase">{t.results.placeholder}</p>
              <p className="mt-3 text-sm text-muted">{t.results.placeholderBody}</p>
            </div>
          ))}
        </div>
      </div>

      <Dialog.Root open={open} onOpenChange={setOpen}>
        <Dialog.Portal>
          <Dialog.Overlay className="fixed inset-0 z-50 bg-ink/70" />
          <Dialog.Content className="fixed inset-x-4 top-1/2 z-50 max-h-[90vh] -translate-y-1/2 overflow-auto border border-line bg-paper p-5 text-ink shadow-sheet sm:inset-x-auto sm:left-1/2 sm:w-[min(720px,92vw)] sm:-translate-x-1/2">
            <Dialog.Title className="font-display text-3xl">
              {report.name} · {t.results.rw}
            </Dialog.Title>
            <Dialog.Description className="mt-2 text-sm text-muted">
              {lang === "ar" ? report.noteAr : report.noteEn}
            </Dialog.Description>
            <div className="mt-8">
              <Ladder reportId={report.id} drawn={drawn} large />
            </div>
            <Dialog.Close className="mt-8 min-h-11 rounded-full bg-ink px-4 text-sm font-semibold text-paper">
              {t.results.close}
            </Dialog.Close>
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>
    </section>
  );
}

function Ladder({ reportId, drawn, large }: { reportId: string; drawn: boolean; large?: boolean }) {
  const { t } = useT();
  const report = reports.find((r) => r.id === reportId) ?? reports[0];
  const from = pos(report.rwFrom);
  const to = pos(report.rwTo);
  return (
    <div className={cn("mt-8", large && "mt-4")}>
      <div className="relative h-16">
        <div className="absolute inset-x-0 top-7 h-px bg-line" />
        {[400, 500, 600, 700, 800].map((n) => (
          <span
            key={n}
            className="absolute top-10 font-mono text-xs text-muted"
            style={{ insetInlineStart: `${pos(n)}%`, transform: "translateX(-50%)" }}
          >
            {n}
          </span>
        ))}
        <span
          className="absolute top-3 size-3 rounded-full border border-ink bg-paper"
          style={{ insetInlineStart: `${drawn ? from : 8}%` }}
        />
        <span
          className="absolute top-1.5 size-6 rounded-full bg-signal transition-all duration-700"
          style={{ insetInlineStart: `${drawn ? to : from}%` }}
        />
      </div>
      <div className="mt-6 flex justify-between text-sm">
        <span>
          {t.results.before} {report.rwFrom}
        </span>
        <span className="font-semibold">
          {t.results.after} {report.rwTo}
        </span>
      </div>
    </div>
  );
}
