import { useState } from "react";
import { decoder, diagnostics, domains, getQuestion, heroQuestion, twinQuestion, vocab } from "@/lib/content";
import type { DomainId } from "@/lib/content";
import { QuestionCard } from "@/components/exam/question-card";
import { useT } from "@/lib/use-t";
import { cn } from "@/lib/utils";

type Tab = "trap" | "decode" | "coach";

const roleColor = {
  claim: "border-claim text-claim",
  pivot: "border-pivot text-pivot",
  conclusion: "border-conclusion text-conclusion",
} as const;

export function LabPanel({ id }: { id?: string }) {
  const { t, lang } = useT();
  const [tab, setTab] = useState<Tab>("trap");
  const [picked, setPicked] = useState<string | null>(null);
  const [twin, setTwin] = useState(false);
  const [loading, setLoading] = useState(false);
  const [sentence, setSentence] = useState(decoder[1].id);
  const [word, setWord] = useState<string | null>("posits");
  const [band, setBand] = useState(diagnostics[0].id);

  const question = twin ? twinQuestion : heroQuestion;
  const active = decoder.find((s) => s.id === sentence) ?? decoder[0];
  const plan = diagnostics.find((d) => d.id === band) ?? diagnostics[0];
  const entry = vocab.find((v) => v.id === word);

  function generateTwin() {
    if (loading) return;
    setLoading(true);
    setPicked(null);
    window.setTimeout(() => {
      setTwin(true);
      setLoading(false);
    }, 700);
  }

  const tabs: { id: Tab; label: string; n: string }[] = [
    { id: "trap", label: t.lab.trap, n: "01" },
    { id: "decode", label: t.lab.decode, n: "02" },
    { id: "coach", label: t.lab.coach, n: "03" },
  ];

  return (
    <section id={id} className="mx-auto max-w-6xl px-4 py-16 sm:py-24">
      <p className="font-mono text-xs tracking-stamp text-mark uppercase">{t.lab.eyebrow}</p>
      <div className="mt-3 grid gap-6 lg:grid-cols-[0.9fr_1.1fr] lg:items-end">
        <h2 className="font-display text-4xl leading-none sm:text-5xl">{t.lab.title}</h2>
        <p className="max-w-xl text-muted">{t.lab.lede}</p>
      </div>
      <div role="tablist" aria-label={t.lab.eyebrow} className="mt-8 flex gap-2 overflow-x-auto border-b border-line">
        {tabs.map((item) => (
          <button
            key={item.id}
            role="tab"
            aria-selected={tab === item.id}
            className={cn(
              "min-h-12 shrink-0 border-b-2 px-3 font-medium",
              tab === item.id ? "border-mark text-ink" : "border-transparent text-muted",
            )}
            onClick={() => setTab(item.id)}
          >
            <span className="me-2 font-mono text-xs text-mark">{item.n}</span>
            {item.label}
          </button>
        ))}
      </div>

      <div className="mt-6" role="tabpanel">
        {tab === "trap" ? (
          <div className="grid gap-6">
            {loading ? (
              <div className="animate-pulse space-y-3 border border-line bg-sheet p-6" aria-hidden>
                <div className="h-3 w-40 bg-line" />
                <div className="h-5 w-full bg-line" />
                <div className="h-5 w-11/12 bg-line" />
                <div className="h-12 w-full bg-line" />
                <div className="h-12 w-full bg-line" />
              </div>
            ) : (
              <QuestionCard
                question={question}
                selected={picked}
                onSelect={setPicked}
                kicker={twin ? "Twin · same logic" : t.hero.sheet}
              />
            )}
            <div className="flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={generateTwin}
                disabled={twin || loading}
                className="inline-flex min-h-11 items-center rounded-full bg-ink px-5 text-sm font-semibold text-paper disabled:opacity-50"
              >
                {loading ? t.lab.working : t.lab.twin}
              </button>
              <p className="text-sm text-muted">{t.lab.twinNote}</p>
            </div>
          </div>
        ) : null}

        {tab === "decode" ? (
          <div className="grid gap-6 lg:grid-cols-[1.15fr_0.85fr]">
            <div className="border border-line bg-sheet p-5 sm:p-7">
              <p className="text-sm text-muted">{t.lab.decodeHelp}</p>
              <div className="mt-4 flex flex-wrap gap-2 text-xs">
                {(["claim", "pivot", "conclusion"] as const).map((role) => (
                  <span key={role} className={cn("border-s-2 px-2", roleColor[role])}>
                    {t.lab[role]}
                  </span>
                ))}
              </div>
              <div className="mt-5 space-y-3">
                {decoder.map((sentenceItem, index) => (
                  <button
                    key={sentenceItem.id}
                    type="button"
                    onClick={() => setSentence(sentenceItem.id)}
                    dir="ltr"
                    className={cn(
                      "block w-full border-s-4 px-3 py-2 text-start font-display text-lg leading-snug",
                      sentence === sentenceItem.id ? roleColor[sentenceItem.role] : "border-transparent text-ink",
                    )}
                  >
                    <span className="me-2 font-mono text-xs text-muted">{index + 1}</span>
                    {sentenceItem.en}
                  </button>
                ))}
              </div>
            </div>
            <aside className="border border-line bg-paper p-5">
              <p className={cn("font-mono text-xs tracking-stamp uppercase", roleColor[active.role])}>
                {t.lab[active.role]}
              </p>
              <h3 className="mt-3 font-mono text-xs text-muted">{t.lab.breakEn}</h3>
              <p className="mt-1" dir="ltr">
                {active.noteEn}
              </p>
              <h3 className="mt-4 font-mono text-xs text-muted">{t.lab.breakAr}</h3>
              <p className="mt-1" dir="rtl">
                {active.noteAr}
              </p>
              <h3 className="mt-6 font-mono text-xs tracking-stamp text-muted uppercase">{t.lab.vocab}</h3>
              <div className="mt-2 flex flex-wrap gap-2">
                {vocab.slice(0, 4).map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setWord(item.id)}
                    className={cn(
                      "min-h-9 rounded-full border px-3 text-sm",
                      word === item.id ? "border-ink bg-ink text-paper" : "border-line",
                    )}
                  >
                    {item.word}
                  </button>
                ))}
              </div>
              {entry ? (
                <p className="mt-3 text-sm">
                  <span className="font-mono text-xs text-muted">{entry.pos}</span>{" "}
                  {lang === "ar" ? entry.ar : entry.en}
                </p>
              ) : null}
            </aside>
          </div>
        ) : null}

        {tab === "coach" ? (
          <div>
            <p className="text-sm text-muted">{t.lab.coachHelp}</p>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              {diagnostics.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setBand(item.id)}
                  className={cn(
                    "min-h-20 border px-4 py-4 text-start",
                    band === item.id ? "border-ink bg-sheet" : "border-line",
                  )}
                >
                  <span className="font-mono text-xs text-mark">
                    {item.from} → {item.to === 760 ? "750+" : item.to}
                  </span>
                  <span className="mt-1 block font-display text-2xl">
                    {item.id === "build" ? t.lab.build : t.lab.push}
                  </span>
                </button>
              ))}
            </div>
            <div className="mt-6 grid gap-6 lg:grid-cols-[0.8fr_1.2fr]">
              <div>
                <p className="font-mono text-xs tracking-stamp text-muted uppercase">{t.lab.weak}</p>
                <ul className="mt-3 space-y-3">
                  {plan.weak.map((id) => (
                    <li key={id}>
                      <div className="mb-1 flex justify-between text-sm">
                        <span>{domainName(id, lang)}</span>
                      </div>
                      <div className="h-2 bg-line">
                        <div
                          className="h-2 bg-mark"
                          style={{ width: id === plan.weak[0] ? "38%" : "52%" }}
                        />
                      </div>
                    </li>
                  ))}
                </ul>
                <p className="mt-6 font-display text-6xl leading-none tabular-nums text-ink">
                  {plan.gainIsSample ? "+110" : plan.to - plan.from}
                </p>
                <p className="mt-1 text-sm text-muted">{plan.gainIsSample ? t.lab.projected : t.lab.gap}</p>
                <p className="mt-2 text-xs text-muted">{plan.gainIsSample ? t.lab.sampleFlag : t.lab.gapFlag}</p>
              </div>
              <ol className="border-s border-line ps-5">
                <li className="font-mono text-xs tracking-stamp text-mark uppercase">{t.lab.week}</li>
                {plan.plan.map((step, index) => (
                  <li key={step.en} className="mt-4">
                    <span className="font-mono text-xs text-muted">0{index + 1}</span>
                    <p>{lang === "ar" ? step.ar : step.en}</p>
                  </li>
                ))}
              </ol>
            </div>
          </div>
        ) : null}
      </div>
    </section>
  );
}

function domainName(id: DomainId, lang: "en" | "ar") {
  const found = domains.find((d) => d.id === id);
  if (!found) return id;
  return lang === "ar" ? found.ar : found.en;
}

export { getQuestion };
