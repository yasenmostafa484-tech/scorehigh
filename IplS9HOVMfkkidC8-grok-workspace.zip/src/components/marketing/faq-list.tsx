import * as Accordion from "@radix-ui/react-accordion";
import { faq } from "@/lib/content";
import { useT } from "@/lib/use-t";

export function FaqList({ limit }: { limit?: number }) {
  const { lang } = useT();
  const items = typeof limit === "number" ? faq.slice(0, limit) : faq;
  return (
    <Accordion.Root type="single" collapsible className="divide-y divide-line border-y border-line">
      {items.map((item, index) => (
        <Accordion.Item key={item.qEn} value={item.qEn}>
          <Accordion.Header>
            <Accordion.Trigger className="flex w-full items-center gap-4 py-4 text-start">
              <span className="font-mono text-xs text-mark">{String(index + 1).padStart(2, "0")}</span>
              <span className="font-display text-xl sm:text-2xl">{lang === "ar" ? item.qAr : item.qEn}</span>
            </Accordion.Trigger>
          </Accordion.Header>
          <Accordion.Content className="acc-panel">
            <div>
              <p className="pb-5 ps-10 text-muted">{lang === "ar" ? item.aAr : item.aEn}</p>
            </div>
          </Accordion.Content>
        </Accordion.Item>
      ))}
    </Accordion.Root>
  );
}
