import { useState } from "react";
import { WaButton } from "@/components/site/chrome";
import { useT } from "@/lib/use-t";
import { cn } from "@/lib/utils";

type Band = "lt" | "mid" | "hi";
type Style = "group" | "private" | "self";
type When = "soon" | "season" | "explore";

export function FitQuiz() {
  const { t, lang } = useT();
  const [step, setStep] = useState(0);
  const [band, setBand] = useState<Band | null>(null);
  const [style, setStyle] = useState<Style | null>(null);
  const [when, setWhen] = useState<When | null>(null);

  const result =
    style === "self" || when === "explore" ? "vault" : style === "private" || band === "hi" ? "elite" : "group";

  const steps = [
    {
      q: t.programs.q1,
      value: band,
      set: (v: string) => setBand(v as Band),
      options: [
        { id: "lt", label: t.programs.lt },
        { id: "mid", label: t.programs.mid },
        { id: "hi", label: t.programs.hi },
      ],
    },
    {
      q: t.programs.q2,
      value: style,
      set: (v: string) => setStyle(v as Style),
      options: [
        { id: "group", label: t.programs.group },
        { id: "private", label: t.programs.private },
        { id: "self", label: t.programs.self },
      ],
    },
    {
      q: t.programs.q3,
      value: when,
      set: (v: string) => setWhen(v as When),
      options: [
        { id: "soon", label: t.programs.soon },
        { id: "season", label: t.programs.season },
        { id: "explore", label: t.programs.explore },
      ],
    },
  ];

  if (step >= 3) {
    const title =
      result === "elite" ? t.programs.resultElite : result === "vault" ? t.programs.resultVault : t.programs.resultGroup;
    const body =
      result === "elite"
        ? t.programs.resultBodyElite
        : result === "vault"
          ? t.programs.resultBodyVault
          : t.programs.resultBodyGroup;
    const message =
      lang === "ar"
        ? `مرحبًا، أوصى الموقع ببرنامج ${result}. أريد التفاصيل.`
        : `Hello, the site recommended the ${result} program. I'd like the details.`;
    return (
      <div className="border border-line bg-sheet p-5 sm:p-7">
        <p className="font-mono text-xs tracking-stamp text-mark uppercase">{t.programs.fit}</p>
        <h3 className="mt-3 font-display text-4xl leading-none">{title}</h3>
        <p className="mt-3 max-w-xl text-muted">{body}</p>
        <div className="mt-6 flex flex-wrap gap-3">
          {result === "vault" ? (
            <a href="/vault" className="inline-flex min-h-12 items-center rounded-full bg-signal px-5 font-semibold text-ink">
              {t.nav.vault}
            </a>
          ) : (
            <WaButton message={message}>{t.programs.ask}</WaButton>
          )}
          <button
            type="button"
            className="min-h-12 rounded-full border border-line px-5 text-sm"
            onClick={() => {
              setStep(0);
              setBand(null);
              setStyle(null);
              setWhen(null);
            }}
          >
            {t.programs.restart}
          </button>
        </div>
      </div>
    );
  }

  const current = steps[step];
  return (
    <div className="border border-line bg-sheet p-5 sm:p-7">
      <p className="font-mono text-xs text-muted">
        0{step + 1} / 03 · {t.programs.fit}
      </p>
      <h3 className="mt-3 font-display text-3xl leading-none">{current.q}</h3>
      <div className="mt-5 grid gap-2">
        {current.options.map((option) => (
          <button
            key={option.id}
            type="button"
            onClick={() => current.set(option.id)}
            className={cn(
              "min-h-12 border px-4 text-start",
              current.value === option.id ? "border-ink bg-paper" : "border-line",
            )}
          >
            {option.label}
          </button>
        ))}
      </div>
      <div className="mt-5 flex gap-2">
        {step > 0 ? (
          <button type="button" className="min-h-11 rounded-full border border-line px-4" onClick={() => setStep((s) => s - 1)}>
            {t.programs.back}
          </button>
        ) : null}
        <button
          type="button"
          disabled={!current.value}
          className="min-h-11 rounded-full bg-ink px-4 font-semibold text-paper disabled:opacity-40"
          onClick={() => setStep((s) => s + 1)}
        >
          {t.programs.next}
        </button>
      </div>
    </div>
  );
}
