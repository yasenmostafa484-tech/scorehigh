import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import type { Question } from "@/lib/content";
import { trapLabel } from "@/lib/content";
import { useT } from "@/lib/use-t";
import { cn } from "@/lib/utils";

export function QuestionCard({
  question,
  selected,
  onSelect,
  kicker,
}: {
  question: Question;
  selected: string | null;
  onSelect: (id: string) => void;
  kicker: string;
}) {
  const { t, lang } = useT();
  const reduce = useReducedMotion();
  const choice = question.choices.find((c) => c.id === selected);
  const correct = selected === question.correct;
  const why = selected ? question.why[selected as Question["correct"]] : null;
  const tempting = question.choices.find((c) => c.id === question.tempting);

  return (
    <article className="relative border border-line bg-sheet shadow-sheet">
      <div className="border-s-4 border-mark px-5 py-5 sm:px-7 sm:py-7">
        <p className="font-mono text-xs tracking-stamp text-muted uppercase">{kicker}</p>
        <p className="mt-4 font-display text-lg leading-snug sm:text-xl" dir="ltr">
          {question.passage}
        </p>
        {lang === "ar" ? (
          <p className="mt-3 text-sm text-muted" dir="rtl">
            {question.passageAr}
          </p>
        ) : null}
        <h3 className="mt-6 text-base font-semibold" dir="ltr">
          {question.stem}
        </h3>
        {lang === "ar" ? (
          <p className="mt-1 text-sm text-muted" dir="rtl">
            {question.stemAr}
          </p>
        ) : null}
        <div role="radiogroup" aria-label={question.stem} className="mt-5 grid gap-2">
          {question.choices.map((item) => {
            const on = selected === item.id;
            const isKey = selected && item.id === question.correct;
            return (
              <button
                key={item.id}
                type="button"
                role="radio"
                aria-checked={on}
                onClick={() => onSelect(item.id)}
                dir="ltr"
                className={cn(
                  "flex min-h-12 items-start gap-3 rounded-2xl border px-3 py-3 text-start transition-colors",
                  on && !correct && "border-trap bg-paper",
                  on && correct && "border-mark bg-paper",
                  !on && isKey && "border-mark",
                  !on && !isKey && "border-line hover:border-ink",
                )}
              >
                <span className="grid size-7 shrink-0 place-items-center rounded-full border border-line font-mono text-xs">
                  {item.id}
                </span>
                <span className={cn("pt-0.5", selected && item.id !== question.correct && item.id === selected && "text-trap")}>
                  {item.en}
                  {lang === "ar" ? <span className="mt-1 block text-sm text-muted" dir="rtl">{item.ar}</span> : null}
                </span>
              </button>
            );
          })}
        </div>
        <div className="sr-only" aria-live="polite">
          {why ? (lang === "ar" ? why.ar : why.en) : ""}
        </div>
        <AnimatePresence>
          {why && choice ? (
            <motion.aside
              key={question.id + selected}
              initial={reduce ? false : { opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="mt-5 grid gap-3 border-t border-dashed border-line pt-4 sm:grid-cols-[auto_1fr]"
            >
              {correct ? (
                <span className="font-mono text-xs tracking-stamp text-mark uppercase">{t.lab.correct}</span>
              ) : (
                <span className="inline-flex w-fit -rotate-6 border-2 border-trap px-2 py-1 font-mono text-xs tracking-stamp text-trap uppercase">
                  {t.lab.trapWord}
                  {choice.trap ? ` · ${lang === "ar" ? trapLabel[choice.trap].ar : trapLabel[choice.trap].en}` : ""}
                </span>
              )}
              <p className="text-sm leading-relaxed">{lang === "ar" ? why.ar : why.en}</p>
              {correct && tempting?.trap ? (
                <p className="text-sm text-muted sm:col-start-2">
                  {lang === "ar" ? "الفخ المجاور" : "The trap next door"}: {tempting.id} —{" "}
                  {lang === "ar" ? question.why[tempting.id].ar : question.why[tempting.id].en}
                </p>
              ) : null}
            </motion.aside>
          ) : null}
        </AnimatePresence>
      </div>
    </article>
  );
}
