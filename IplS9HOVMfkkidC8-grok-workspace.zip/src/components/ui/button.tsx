import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import type { ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

const styles = cva(
  "inline-flex items-center justify-center gap-2 rounded-full font-semibold transition-transform duration-200 disabled:pointer-events-none disabled:opacity-50 min-h-11 px-5 text-sm",
  {
    variants: {
      variant: {
        signal: "bg-signal text-ink hover:-translate-y-0.5",
        ink: "bg-ink text-paper hover:-translate-y-0.5",
        ghost: "border border-line bg-transparent text-ink hover:bg-sheet",
        quiet: "bg-transparent text-ink underline-offset-4 hover:underline",
      },
      size: {
        md: "",
        lg: "min-h-12 px-6 text-base",
      },
    },
    defaultVariants: { variant: "signal", size: "md" },
  },
);

type Props = ButtonHTMLAttributes<HTMLButtonElement> &
  VariantProps<typeof styles> & { asChild?: boolean };

export function Button({ className, variant, size, asChild, ...props }: Props) {
  const Comp = asChild ? Slot : "button";
  return <Comp className={cn(styles({ variant, size }), className)} {...props} />;
}
