import { Link } from "@tanstack/react-router";
import { Menu, Moon, Sun, X } from "lucide-react";
import { useEffect, useState } from "react";
import { INSTAGRAM_URL, TIKTOK_URL, WA_DISPLAY, waLink } from "@/lib/whatsapp";
import { usePrefs } from "@/lib/store";
import { useT } from "@/lib/use-t";
import { cn } from "@/lib/utils";

const links = [
  { to: "/lab", key: "lab" },
  { to: "/programs", key: "programs" },
  { to: "/vault", key: "vault" },
  { to: "/about", key: "about" },
  { to: "/faq", key: "faq" },
] as const;

function enrollText(lang: "en" | "ar") {
  return lang === "ar"
    ? "مرحبًا، أريد السؤال عن التسجيل في ScoreHigh."
    : "Hello, I would like to ask about enrolling in ScoreHigh.";
}

export function Header() {
  const { t, lang } = useT();
  const setLang = usePrefs((s) => s.setLang);
  const theme = usePrefs((s) => s.theme);
  const toggleTheme = usePrefs((s) => s.toggleTheme);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <header className="sticky top-0 z-40 border-b border-line bg-paper">
      <div className="mx-auto flex h-16 max-w-6xl items-center gap-3 px-4">
        <Link to="/" className="flex items-center gap-2 font-display text-xl leading-none" onClick={() => setOpen(false)}>
          <Mark />
          <span>ScoreHigh</span>
        </Link>
        <nav className="ms-6 hidden items-center gap-5 text-sm text-muted lg:flex" aria-label="Primary">
          {links.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className="hover:text-ink"
              activeProps={{ className: "text-ink" }}
            >
              {t.nav[item.key]}
            </Link>
          ))}
        </nav>
        <div className="ms-auto flex items-center gap-2">
          <div className="flex rounded-full border border-line p-0.5 text-xs font-semibold" role="group" aria-label={t.nav.language}>
            <button
              type="button"
              className={cn("min-h-9 rounded-full px-2.5", lang === "en" && "bg-ink text-paper")}
              aria-pressed={lang === "en"}
              onClick={() => setLang("en")}
            >
              EN
            </button>
            <button
              type="button"
              className={cn("min-h-9 rounded-full px-2.5", lang === "ar" && "bg-ink text-paper")}
              aria-pressed={lang === "ar"}
              onClick={() => setLang("ar")}
            >
              ع
            </button>
          </div>
          <button
            type="button"
            className="grid size-11 place-items-center rounded-full border border-line"
            onClick={toggleTheme}
            aria-label={theme === "dark" ? t.nav.themeToLight : t.nav.themeToDark}
          >
            {theme === "dark" ? <Sun className="size-4" /> : <Moon className="size-4" />}
          </button>
          <a
            href={waLink(enrollText(lang))}
            className="hidden min-h-11 items-center rounded-full bg-signal px-4 text-sm font-semibold text-ink sm:inline-flex"
          >
            {t.nav.enroll}
          </a>
          <button
            type="button"
            className="grid size-11 place-items-center rounded-full border border-line lg:hidden"
            aria-expanded={open}
            aria-label={open ? t.nav.close : t.nav.menu}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </div>
      </div>
      {open ? (
        <div className="border-t border-line bg-paper px-4 py-6 lg:hidden">
          <nav className="grid gap-1" aria-label="Mobile">
            {links.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setOpen(false)}
                className="font-display text-4xl leading-tight"
              >
                {t.nav[item.key]}
              </Link>
            ))}
            <Link to="/dashboard" onClick={() => setOpen(false)} className="mt-3 text-sm text-muted">
              {t.nav.student}
            </Link>
          </nav>
          <a
            href={waLink(enrollText(lang))}
            className="mt-6 inline-flex min-h-12 items-center rounded-full bg-signal px-5 font-semibold text-ink"
          >
            {t.nav.enroll}
          </a>
        </div>
      ) : null}
    </header>
  );
}

export function Mark() {
  return (
    <svg viewBox="0 0 32 32" className="size-8" aria-hidden>
      <rect x="3" y="2" width="22" height="28" rx="2" fill="none" stroke="currentColor" strokeWidth="1.6" />
      <path d="M8 22h12" stroke="var(--mark)" strokeWidth="3" strokeLinecap="round" />
      <path d="M20 6.5h6.5v6.5" fill="none" stroke="var(--trap)" strokeWidth="1.6" />
    </svg>
  );
}

export function Footer() {
  const { t, lang } = useT();
  return (
    <footer className="border-t border-line">
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-12 md:grid-cols-[1.4fr_1fr]">
        <div>
          <p className="font-display text-3xl">ScoreHigh</p>
          <p className="mt-2 max-w-md text-sm text-muted">{t.footer.rights}</p>
          <p className="mt-4 max-w-xl text-xs leading-relaxed text-muted">{t.footer.trademark}</p>
        </div>
        <div className="flex flex-wrap content-start gap-3 text-sm">
          <a className="inline-flex min-h-11 items-center rounded-full border border-line px-4" href={waLink(enrollText(lang))}>
            {t.footer.whatsapp} · {WA_DISPLAY}
          </a>
          <a className="inline-flex min-h-11 items-center rounded-full border border-line px-4" href={INSTAGRAM_URL}>
            {t.footer.instagram}
          </a>
          <a className="inline-flex min-h-11 items-center rounded-full border border-line px-4" href={TIKTOK_URL}>
            {t.footer.tiktok}
          </a>
          <Link to="/dashboard" className="inline-flex min-h-11 items-center rounded-full border border-line px-4">
            {t.nav.student}
          </Link>
        </div>
      </div>
    </footer>
  );
}

export function SiteFrame({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-paper text-ink">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:z-50 focus:m-3 focus:rounded-full focus:bg-signal focus:px-4 focus:py-2 focus:text-ink"
      >
        Skip to content
      </a>
      <Header />
      <ScoreRail />
      <div id="main">{children}</div>
      <Footer />
    </div>
  );
}

export function ScoreRail() {
  const [progress, setProgress] = useState(8);

  useEffect(() => {
    const onScroll = () => {
      const max = document.documentElement.scrollHeight - window.innerHeight;
      const next = max <= 0 ? 8 : Math.min(100, Math.max(8, (window.scrollY / max) * 100));
      setProgress(next);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div className="pointer-events-none fixed top-16 bottom-0 start-3 z-30 hidden w-10 lg:block" aria-hidden>
      <div className="absolute inset-y-24 start-4 w-px bg-line" />
      <div
        className="absolute start-4 bottom-24 w-px bg-mark"
        style={{ height: `calc((100% - 12rem) * ${progress / 100})` }}
      />
      <span className="absolute start-0 top-20 font-mono text-xs text-muted">800</span>
      <span className="absolute start-0 top-1/2 font-mono text-xs text-muted">600</span>
      <span className="absolute start-0 bottom-16 font-mono text-xs text-muted">400</span>
    </div>
  );
}

export function WaButton({
  children,
  message,
  variant = "signal",
  className,
}: {
  children: React.ReactNode;
  message: string;
  variant?: "signal" | "ink" | "ghost";
  className?: string;
}) {
  const look =
    variant === "ink"
      ? "bg-ink text-paper"
      : variant === "ghost"
        ? "border border-line bg-transparent text-ink"
        : "bg-signal text-ink";
  return (
    <a
      href={waLink(message)}
      className={cn(
        "inline-flex min-h-12 items-center justify-center rounded-full px-5 text-sm font-semibold",
        look,
        className,
      )}
    >
      {children}
    </a>
  );
}
