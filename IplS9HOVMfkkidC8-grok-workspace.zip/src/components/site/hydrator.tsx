/** Theme and language rehydrate in the root document shell. */
export function Hydrator() {
  return null;
}
