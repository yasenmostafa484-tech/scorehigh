import { Link } from "@tanstack/react-router";
import { BookOpen, Home, Library, PenLine, Rows3 } from "lucide-react";
import type { ReactNode } from "react";
import { Mark } from "@/components/site/chrome";
import { usePrefs } from "@/lib/store";
import { useT } from "@/lib/use-t";
import { cn } from "@/lib/utils";

const items = [
  { to: "/dashboard", key: "home", icon: Home },
  { to: "/skills", key: "skills", icon: Rows3 },
  { to: "/error-vault", key: "vault", icon: Library },
  { to: "/practice", key: "practice", icon: PenLine },
  { to: "/vocab", key: "vocab", icon: BookOpen },
] as const;

export function StudioShell({ children }: { children: ReactNode }) {
  const { t } = useT();
  const setLang = usePrefs((s) => s.setLang);
  const lang = usePrefs((s) => s.lang);
  const toggleTheme = usePrefs((s) => s.toggleTheme);
  const theme = usePrefs((s) => s.theme);

  return (
    <div className="min-h-screen bg-paper text-ink">
      <header className="sticky top-0 z-30 flex h-14 items-center gap-3 border-b border-line bg-paper/95 px-4">
        <Link to="/" className="flex items-center gap-2 font-display">
          <Mark />
          <span className="hidden sm:inline">ScoreHigh</span>
        </Link>
        <nav className="ms-4 hidden gap-4 text-sm lg:flex" aria-label="Studio">
          {items.map((item) => (
            <Link key={item.to} to={item.to} className="text-muted" activeProps={{ className: "text-ink font-semibold" }}>
              {t.dash[item.key]}
            </Link>
          ))}
          <Link to="/teacher" className="text-muted" activeProps={{ className: "text-ink font-semibold" }}>
            {t.dash.teacher}
          </Link>
        </nav>
        <div className="ms-auto flex items-center gap-2 text-xs">
          <button type="button" className="min-h-9 px-2 font-semibold" onClick={() => setLang(lang === "ar" ? "en" : "ar")}>
            {lang === "ar" ? "EN" : "ع"}
          </button>
          <button type="button" className="min-h-9 px-2" onClick={toggleTheme} aria-label={theme}>
            {theme === "dark" ? "Aa" : "Aa"}
          </button>
          <Link to="/" className="min-h-9 px-2 text-muted">
            {t.dash.exit}
          </Link>
        </div>
      </header>
      <div className="mx-auto max-w-5xl px-4 py-6 pb-28 lg:pb-10">{children}</div>
      <nav className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t border-line bg-paper lg:hidden" aria-label="Studio mobile">
        {items.map((item) => {
          const Icon = item.icon;
          return (
            <Link
              key={item.to}
              to={item.to}
              className="flex min-h-16 flex-col items-center justify-center gap-1 text-xs text-muted"
              activeProps={{ className: "text-ink" }}
            >
              <Icon className="size-4" />
              <span className={cn("max-w-16 truncate")}>{t.dash[item.key]}</span>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
