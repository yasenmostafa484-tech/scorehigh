import { ar, en, type Dict } from "@/lib/i18n";
import { usePrefs, type Lang } from "@/lib/store";

export function useT(): { t: Dict; lang: Lang } {
  const lang = usePrefs((s) => s.lang);
  return { t: lang === "ar" ? ar : en, lang };
}
