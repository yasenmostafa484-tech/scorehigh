import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import type { DomainId, TrapKind } from "@/lib/content";
import { todayKey, weekKey } from "@/lib/utils";

export type Lang = "en" | "ar";
export type ThemeMode = "light" | "dark";

export type Profile = {
  name: string;
  current: number;
  target: number;
  testDate: string;
};

export type VaultCard = {
  id: string;
  questionId: string;
  chosen: string;
  trap: TrapKind;
  domain: DomainId;
  due: string;
  retries: number;
  resolved: boolean;
};

export type DomainStat = { correct: number; total: number };

type Missions = { date: string; practice: boolean; vocab: number; vault: number };

type State = {
  lang: Lang;
  theme: ThemeMode;
  profile: Profile | null;
  xp: number;
  streak: number;
  lastActive: string | null;
  weekId: string;
  missions: Missions;
  vault: VaultCard[];
  domains: Record<DomainId, DomainStat>;
  history: { n: number; accuracy: number }[];
  setLang: (lang: Lang) => void;
  setTheme: (theme: ThemeMode) => void;
  toggleTheme: () => void;
  setProfile: (profile: Profile) => void;
  recordAnswer: (domain: DomainId, correct: boolean) => void;
  finishModule: () => void;
  addVocab: (good: boolean) => void;
  addMistake: (card: Omit<VaultCard, "due" | "retries" | "resolved">) => void;
  retryCard: (id: string, correct: boolean) => void;
  resetDemo: () => void;
};

const emptyDomains = (): Record<DomainId, DomainStat> => ({
  craft: { correct: 0, total: 0 },
  info: { correct: 0, total: 0 },
  sec: { correct: 0, total: 0 },
  expression: { correct: 0, total: 0 },
});

function freshMissions(): Missions {
  return { date: todayKey(), practice: false, vocab: 0, vault: 0 };
}

const memoryStorage = {
  getItem: () => null,
  setItem: () => {},
  removeItem: () => {},
};

function bumpStreak(lastActive: string | null, streak: number) {
  const today = todayKey();
  if (lastActive === today) return { lastActive: today, streak };
  const y = new Date();
  y.setDate(y.getDate() - 1);
  const yesterday = todayKey(y);
  return { lastActive: today, streak: lastActive === yesterday ? streak + 1 : 1 };
}

export const usePrefs = create<State>()(
  persist(
    (set, get) => ({
      lang: "en",
      theme: "light",
      profile: null,
      xp: 0,
      streak: 0,
      lastActive: null,
      weekId: weekKey(),
      missions: freshMissions(),
      vault: [],
      domains: emptyDomains(),
      history: [],
      setLang: (lang) => set({ lang }),
      setTheme: (theme) => set({ theme }),
      toggleTheme: () => {
        const next = get().theme === "dark" ? "light" : "dark";
        get().setTheme(next);
      },
      setProfile: (profile) => set({ profile }),
      recordAnswer: (domain, correct) => {
        const domains = { ...get().domains, [domain]: { ...get().domains[domain] } };
        domains[domain] = {
          correct: domains[domain].correct + (correct ? 1 : 0),
          total: domains[domain].total + 1,
        };
        const totals = Object.values(domains).reduce(
          (acc, d) => ({ correct: acc.correct + d.correct, total: acc.total + d.total }),
          { correct: 0, total: 0 },
        );
        const accuracy = totals.total ? Math.round((totals.correct / totals.total) * 100) : 0;
        set({ domains, history: [...get().history, { n: totals.total, accuracy }] });
      },
      finishModule: () => {
        const missions = normalizeMissions(get().missions);
        const streak = bumpStreak(get().lastActive, get().streak);
        set({
          missions: { ...missions, practice: true },
          xp: get().xp + 40,
          ...streak,
        });
      },
      addVocab: (good) => {
        const missions = normalizeMissions(get().missions);
        const streak = bumpStreak(get().lastActive, get().streak);
        set({
          missions: { ...missions, vocab: missions.vocab + 1 },
          xp: get().xp + (good ? 10 : 2),
          ...streak,
        });
      },
      addMistake: (card) => {
        if (get().vault.some((v) => v.questionId === card.questionId && !v.resolved)) return;
        set({
          vault: [
            {
              ...card,
              due: todayKey(),
              retries: 0,
              resolved: false,
            },
            ...get().vault,
          ],
        });
      },
      retryCard: (id, correct) => {
        const missions = normalizeMissions(get().missions);
        const streak = bumpStreak(get().lastActive, get().streak);
        set({
          vault: get().vault.map((card) => {
            if (card.id !== id) return card;
            const retries = card.retries + 1;
            const due = new Date();
            due.setDate(due.getDate() + (correct ? 4 : 1));
            return {
              ...card,
              retries,
              due: todayKey(due),
              resolved: correct && retries >= 1,
            };
          }),
          missions: { ...missions, vault: missions.vault + 1 },
          xp: get().xp + (correct ? 15 : 4),
          ...streak,
        });
      },
      resetDemo: () =>
        set({
          xp: 0,
          streak: 0,
          lastActive: null,
          missions: freshMissions(),
          vault: [],
          domains: emptyDomains(),
          history: [],
        }),
    }),
    {
      name: "scorehigh-prefs",
      skipHydration: true,
      storage: createJSONStorage(() =>
        typeof window === "undefined" ? memoryStorage : localStorage,
      ),
    },
  ),
);

function normalizeMissions(missions: Missions): Missions {
  const today = todayKey();
  if (missions.date !== today) return freshMissions();
  return missions;
}

export function useI18n() {
  const lang = usePrefs((s) => s.lang);
  return lang;
}

export function missionCount(missions: Missions) {
  const m = missions.date === todayKey() ? missions : freshMissions();
  return (m.practice ? 1 : 0) + (m.vocab >= 5 ? 1 : 0) + (m.vault >= 1 ? 1 : 0);
}

export function dueCount(vault: VaultCard[]) {
  const today = todayKey();
  return vault.filter((c) => !c.resolved && c.due <= today).length;
}
