import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function weekKey(date = new Date()) {
  const start = new Date(date.getFullYear(), 0, 1);
  const day = Math.floor((date.getTime() - start.getTime()) / 86400000);
  const week = Math.ceil((day + start.getDay() + 1) / 7);
  return `${date.getFullYear()}-W${week}`;
}

export function todayKey(date = new Date()) {
  return date.toISOString().slice(0, 10);
}
