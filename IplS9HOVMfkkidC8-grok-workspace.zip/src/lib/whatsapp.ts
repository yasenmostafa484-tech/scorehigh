export const WA_DISPLAY = "+20 159 990 6731";
export const WA_PHONE = "201599906731";

export function waLink(text: string) {
  return `https://wa.me/${WA_PHONE}?text=${encodeURIComponent(text)}`;
}

export const TIKTOK_URL = "https://www.tiktok.com/@scorehightutoring";
/* Same public handle as the confirmed TikTok. Swap if the Instagram differs. */
export const INSTAGRAM_URL = "https://www.instagram.com/scorehightutoring/";
