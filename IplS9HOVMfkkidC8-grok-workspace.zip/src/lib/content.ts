export type ChoiceId = "A" | "B" | "C" | "D";

export type TrapKind =
  | "too-extreme"
  | "half-right"
  | "out-of-scope"
  | "wrong-sense"
  | "opposite"
  | "agreement";

export type DomainId = "craft" | "info" | "sec" | "expression";

export type Choice = {
  id: ChoiceId;
  en: string;
  ar: string;
  trap?: TrapKind;
};

export type Question = {
  id: string;
  domain: DomainId;
  passage: string;
  passageAr: string;
  stem: string;
  stemAr: string;
  choices: Choice[];
  correct: ChoiceId;
  tempting: ChoiceId;
  why: Record<ChoiceId, { en: string; ar: string }>;
};

export type SentenceRole = "claim" | "pivot" | "conclusion";

export type DecoderSentence = {
  id: string;
  role: SentenceRole;
  en: string;
  ar: string;
  noteEn: string;
  noteAr: string;
};

export const trapLabel: Record<TrapKind, { en: string; ar: string }> = {
  "too-extreme": { en: "Too extreme", ar: "مبالغة زائدة" },
  "half-right": { en: "Half-right", ar: "نصفها صحيح" },
  "out-of-scope": { en: "Out of scope", ar: "خارج النص" },
  "wrong-sense": { en: "Wrong sense", ar: "معنى خاطئ" },
  opposite: { en: "Opposite", ar: "العكس" },
  agreement: { en: "Agreement", ar: "المطابقة" },
};

export const domains: { id: DomainId; en: string; ar: string }[] = [
  { id: "craft", en: "Craft & Structure", ar: "الصياغة والبنية" },
  { id: "info", en: "Information & Ideas", ar: "المعلومات والأفكار" },
  { id: "sec", en: "Standard English Conventions", ar: "قواعد الإنجليزية المعيارية" },
  { id: "expression", en: "Expression of Ideas", ar: "التعبير عن الأفكار" },
];

export const questions: Question[] = [
  {
    id: "archive",
    domain: "info",
    passage:
      "The historian argues that the archive does not merely record the past; it posits a version of events that later readers treat as neutral.",
    passageAr:
      "يرى المؤرخ أن الأرشيف لا يكتفي بتسجيل الماضي؛ إنه يطرح نسخة من الأحداث يعاملها القرّاء اللاحقون كأنها محايدة.",
    stem: "As used in the sentence, “posits” most nearly means",
    stemAr: "كما وردت في الجملة، أقرب معنى لكلمة posits هو",
    correct: "B",
    tempting: "C",
    choices: [
      { id: "A", en: "accidentally misplaces.", ar: "يضع في غير موضعه بالخطأ.", trap: "wrong-sense" },
      { id: "B", en: "puts forward as a claim.", ar: "يطرحه بوصفه ادّعاء." },
      { id: "C", en: "proves beyond any doubt.", ar: "يثبت بما لا يدع شكًا.", trap: "too-extreme" },
      { id: "D", en: "hides from the public.", ar: "يخفيه عن الجمهور.", trap: "out-of-scope" },
    ],
    why: {
      A: {
        en: "Wrong sense. “Posit” is not “deposit.” The sentence is about a claim, not a filing error.",
        ar: "معنى خاطئ. posit ليست deposit. الجملة عن ادّعاء لا عن خطأ في الحفظ.",
      },
      B: {
        en: "Yes. To posit is to put something forward so it can be examined. The next words — “a version… treat as neutral” — confirm it is a claim, not a proof.",
        ar: "صحيح. posit تعني أن تطرح فكرة لتُفحص. بقية الجملة — نسخة يعاملها الناس كأنها محايدة — تؤكد أنها ادّعاء لا برهان.",
      },
      C: {
        en: "Too extreme. “Proves” and “beyond any doubt” upgrade a suggestion into a courtroom verdict. That upgrade is the trap.",
        ar: "مبالغة. «يثبت» و«بما لا يدع شكًا» يحوّلان الاقتراح إلى حكم نهائي. هذه القفزة هي الفخ.",
      },
      D: {
        en: "Out of scope. Nothing in the sentence says the archive conceals records.",
        ar: "خارج النص. لا شيء في الجملة يقول إن الأرشيف يخفي الوثائق.",
      },
    },
  },
  {
    id: "archive-twin",
    domain: "info",
    passage:
      "The editorial does not settle the debate; it advances a reading that impatient commenters then repeat as if it were the only one.",
    passageAr:
      "الافتتاحية لا تحسم الجدل؛ إنها تقدّم قراءةً يردّدها المعلّقون المستعجلون كأنّها القراءة الوحيدة.",
    stem: "As used in the sentence, “advances” most nearly means",
    stemAr: "كما وردت في الجملة، أقرب معنى لكلمة advances هو",
    correct: "A",
    tempting: "D",
    choices: [
      { id: "A", en: "puts forward for others to take up.", ar: "يطرحها ليلتقطها الآخرون." },
      { id: "B", en: "moves a piece on a board.", ar: "يحرّك قطعة على رقعة.", trap: "wrong-sense" },
      { id: "C", en: "delays a decision on purpose.", ar: "يؤجّل القرار عمدًا.", trap: "opposite" },
      { id: "D", en: "ends the argument for good.", ar: "ينهي الجدال نهائيًا.", trap: "too-extreme" },
    ],
    why: {
      A: {
        en: "Same logic as “posits.” The verb offers a reading. It does not close the case.",
        ar: "نفس منطق posits. الفعل يقدّم قراءة ولا يغلق القضية.",
      },
      B: {
        en: "Wrong sense. A game meaning of “advance,” dropped into an editorial.",
        ar: "معنى خاطئ. معنى اللعب لكلمة advance أُقحم في سياق مقال.",
      },
      C: {
        en: "Opposite. The sentence says the reading spreads, not that it is postponed.",
        ar: "العكس. الجملة تقول إن القراءة تنتشر لا إنها تُؤجَّل.",
      },
      D: {
        en: "Too extreme — and it contradicts “does not settle.” The trap repeats a word the sentence already cancelled.",
        ar: "مبالغة، وتناقض «لا تحسم». الفخ يعيد كلمة ألغتها الجملة أصلًا.",
      },
    },
  },
  {
    id: "buses",
    domain: "craft",
    passage:
      "Last spring the city added three night buses on routes that previously stopped at midnight. Riders who finish shifts after 1 a.m. no longer have to choose between a taxi and a long walk. Officials say the pilot will be judged on ridership and on whether early-morning complaints about safety decline, not on whether traffic disappears.",
    passageAr:
      "في الربيع الماضي أضافت المدينة ثلاث حافلات ليلية على خطوط كانت تتوقف عند منتصف الليل. لم يعد العاملون بعد الواحدة فجرًا مضطرين للاختيار بين سيارة أجرة ومشي طويل. يقول المسؤولون إن التجربة ستُقاس بعدد الركّاب وبانخفاض شكاوى الأمان فجرًا، لا باختفاء الزحام.",
    stem: "Which choice best states the main purpose of the passage?",
    stemAr: "أي خيار يصف الغرض الرئيس من الفقرة؟",
    correct: "B",
    tempting: "A",
    choices: [
      {
        id: "A",
        en: "To argue that night buses will end traffic in the city.",
        ar: "للقول إن الحافلات الليلية ستنهي الزحام في المدينة.",
        trap: "too-extreme",
      },
      {
        id: "B",
        en: "To explain a night-bus pilot and the standard officials will use to judge it.",
        ar: "لشرح تجربة الحافلات الليلية والمعيار الذي سيحكم به المسؤولون عليها.",
      },
      {
        id: "C",
        en: "To compare this city’s transit with every neighboring system.",
        ar: "لمقارنة نقل هذه المدينة بكل الأنظمة المجاورة.",
        trap: "out-of-scope",
      },
      {
        id: "D",
        en: "To criticize people who still drive after midnight.",
        ar: "لانتقاد من ما زالوا يقودون بعد منتصف الليل.",
        trap: "half-right",
      },
    ],
    why: {
      A: {
        en: "Too extreme. The last sentence explicitly says the pilot is not judged on traffic disappearing. The trap copies a city-transit cliché the passage refuses.",
        ar: "مبالغة. الجملة الأخيرة تقول صراحة إن التجربة لا تُقاس باختفاء الزحام. الفخ يكرّر كليشيه ترفضه الفقرة.",
      },
      B: {
        en: "Yes. The passage introduces the pilot and names the two measures that matter.",
        ar: "صحيح. الفقرة تقدّم التجربة وتسمّي المقياسين المهمّين.",
      },
      C: {
        en: "Out of scope. No other city is described.",
        ar: "خارج النص. لا مدينة أخرى موصوفة.",
      },
      D: {
        en: "Half-right at best. Drivers are never judged. A negative tone was imported, not written.",
        ar: "نصفها صحيح في أحسن الأحوال. لا حكم على السائقين. النبرة السلبية مستوردة لا مكتوبة.",
      },
    },
  },
  {
    id: "neither",
    domain: "sec",
    passage: "Neither of the editors ____ willing to cut the paragraph that carried the study’s caveat.",
    passageAr: "لا أحد من المحرّرين ____ مستعدًا لحذف الفقرة التي حملت تحفّظ الدراسة.",
    stem: "Which choice completes the sentence so that it follows Standard English conventions?",
    stemAr: "أي خيار يُكمل الجملة وفق قواعد الإنجليزية المعيارية؟",
    correct: "C",
    tempting: "A",
    choices: [
      { id: "A", en: "were", ar: "were", trap: "agreement" },
      { id: "B", en: "being", ar: "being", trap: "agreement" },
      { id: "C", en: "was", ar: "was" },
      { id: "D", en: "are", ar: "are", trap: "agreement" },
    ],
    why: {
      A: {
        en: "Agreement trap. “Editors” sits next to the verb, but the subject is “Neither,” which is singular.",
        ar: "فخ المطابقة. كلمة editors أقرب إلى الفعل، لكن الفاعل هو Neither وهو مفرد.",
      },
      B: {
        en: "“Being” doesn’t give the clause a finite verb. The sentence would hang open.",
        ar: "being لا تعطي الجملة فعلًا مصرّفًا. تبقى الجملة مفتوحة.",
      },
      C: {
        en: "Yes. Neither … was. Ignore the plural noun parked between the subject and the verb.",
        ar: "صحيح. Neither … was. تجاهل الاسم الجمع الواقع بين الفاعل والفعل.",
      },
      D: {
        en: "Same agreement error as “were,” plus the tense doesn’t match a completed editorial decision described as a fact.",
        ar: "خطأ المطابقة نفسه في were، والزمن لا يناسب قرارًا تحريريًا موصوفًا كحقيقة.",
      },
    },
  },
  {
    id: "reef",
    domain: "expression",
    passage:
      "The reef looked healthy in March. ____, by August the same corals had expelled their algae.",
    passageAr: "بدت الشعاب سليمة في مارس. ____، وبحلول أغسطس كانت المرجانيات نفسها قد طردت طحالبها.",
    stem: "Which choice provides the most logical transition?",
    stemAr: "أي خيار يوفّر الانتقال الأكثر منطقية؟",
    correct: "B",
    tempting: "D",
    choices: [
      { id: "A", en: "Similarly,", ar: "وبالمثل،", trap: "opposite" },
      { id: "B", en: "Nevertheless,", ar: "ومع ذلك،" },
      { id: "C", en: "For example,", ar: "على سبيل المثال،", trap: "wrong-sense" },
      { id: "D", en: "In fact,", ar: "في الواقع،", trap: "half-right" },
    ],
    why: {
      A: {
        en: "Opposite relation. August is not like March. The transition has to turn.",
        ar: "علاقة عكسية. أغسطس ليس مثل مارس. الانتقال يجب أن ينعطف.",
      },
      B: {
        en: "Yes. Healthy, and yet bleached. The contrast is the whole point of the pair.",
        ar: "صحيح. سليمة، ومع ذلك ابيضّت. التباين هو كل المعنى.",
      },
      C: {
        en: "“For example” promises an instance of the previous claim. Bleaching is not an example of looking healthy.",
        ar: "«على سبيل المثال» تعد بمثال على الجملة السابقة. الابيضاض ليس مثالًا على السلامة.",
      },
      D: {
        en: "Half-right. “In fact” intensifies, it doesn’t contrast. It feels serious, which is why it tempts, but the logic is “despite,” not “indeed.”",
        ar: "نصفها صحيح. «في الواقع» تقوّي الكلام ولا تعارضه. تبدو جادّة لذلك تغري، لكن المنطق هو «رغم» لا «بالفعل».",
      },
    },
  },
  {
    id: "poet",
    domain: "info",
    passage:
      "In the second draft the poet did not swap the metaphor to make the image prettier. She changed who was allowed to speak the line. The room in the poem stays the same; the person holding the key does not.",
    passageAr:
      "في المسودة الثانية لم تستبدل الشاعرة الاستعارة لتجميل الصورة. لقد غيّرت من يُسمح له بنطق السطر. الغرفة في القصيدة تبقى كما هي؛ الشخص الذي يمسك المفتاح لا يبقى.",
    stem: "Which choice is best supported by the passage?",
    stemAr: "أي خيار تدعمه الفقرة أكثر؟",
    correct: "C",
    tempting: "A",
    choices: [
      {
        id: "A",
        en: "The poet revised a metaphor so the image would be more beautiful.",
        ar: "عدّلت الشاعرة استعارةً لتصبح الصورة أجمل.",
        trap: "half-right",
      },
      {
        id: "B",
        en: "Readers preferred the first draft.",
        ar: "فضّل القرّاء المسودة الأولى.",
        trap: "out-of-scope",
      },
      {
        id: "C",
        en: "The revision changes the speaker, not merely the decoration of the line.",
        ar: "التعديل يغيّر المتكلّم لا مجرد زخرفة السطر.",
      },
      {
        id: "D",
        en: "The poet refuses to use any adjectives.",
        ar: "ترفض الشاعرة استخدام أي صفة.",
        trap: "too-extreme",
      },
    ],
    why: {
      A: {
        en: "Half-right. A metaphor was in play — and the passage says the change was not to make it prettier. The trap keeps the topic and drops the negation.",
        ar: "نصفها صحيح. الاستعارة حاضرة، والفقرة تقول إن التغيير لم يكن للتجميل. الفخ يُبقي الموضوع ويسقط النفي.",
      },
      B: {
        en: "Out of scope. No reader’s preference is mentioned.",
        ar: "خارج النص. لا ذكر لتفضيل القرّاء.",
      },
      C: {
        en: "Yes. “Who was allowed to speak” and “the person holding the key” are the point.",
        ar: "صحيح. «من يُسمح له بالنطق» و«من يمسك المفتاح» هما المقصود.",
      },
      D: {
        en: "Too extreme. Nothing bans adjectives. A total ban is easier to feel than the actual claim.",
        ar: "مبالغة. لا شيء يمنع الصفات. المنع الكلّي أسهل إحساسًا من الادّعاء الفعلي.",
      },
    },
  },
  {
    id: "catalyst",
    domain: "info",
    passage:
      "The grant was not the discovery. It was the catalyst: a small sum that let the team run the trial they had already designed.",
    passageAr:
      "المنحة لم تكن الاكتشاف. كانت العامل المحفّز: مبلغًا صغيرًا سمح للفريق بإجراء التجربة التي صمّموها مسبقًا.",
    stem: "As used in the sentence, “catalyst” most nearly means",
    stemAr: "كما وردت، أقرب معنى لكلمة catalyst هو",
    correct: "D",
    tempting: "B",
    choices: [
      { id: "A", en: "the final result of the trial.", ar: "النتيجة النهائية للتجربة.", trap: "opposite" },
      { id: "B", en: "a large fortune that replaced the research.", ar: "ثروة كبيرة حلّت محل البحث.", trap: "too-extreme" },
      { id: "C", en: "a chemical the team poured into samples.", ar: "مادة كيميائية صبّها الفريق في العيّنات.", trap: "wrong-sense" },
      { id: "D", en: "something that sets a prepared change in motion.", ar: "ما يُحرّك تغييرًا كان جاهزًا." },
    ],
    why: {
      A: {
        en: "Opposite. The sentence separates the grant from the discovery.",
        ar: "العكس. الجملة تفصل المنحة عن الاكتشاف.",
      },
      B: {
        en: "Too extreme. It was “a small sum,” and it did not replace the work. Size and role are both inflated.",
        ar: "مبالغة. كانت «مبلغًا صغيرًا» ولم تستبدل العمل. الحجم والدور كلاهما مُضخَّم.",
      },
      C: {
        en: "Wrong sense. The chemistry meaning is real, and it is not the one this sentence builds.",
        ar: "معنى خاطئ. معنى الكيمياء حقيقي، لكنه ليس المعنى الذي تبنيه الجملة.",
      },
      D: {
        en: "Yes. A catalyst starts a reaction that was ready. Here, the trial was already designed.",
        ar: "صحيح. المحفّز يبدأ تفاعلًا كان جاهزًا. هنا التجربة كانت مصمَّمة سلفًا.",
      },
    },
  },
  {
    id: "notes",
    domain: "sec",
    passage:
      "The lab released three things to the reviewers ____ the method, the raw counts, and the revised chart.",
    passageAr: "نشر المختبر ثلاثة أشياء للمراجعين ____ المنهج، والأعداد الخام، والرسم المعدَّل.",
    stem: "Which choice completes the sentence so that it follows Standard English conventions?",
    stemAr: "أي خيار يُكمل الجملة وفق القواعد المعيارية؟",
    correct: "A",
    tempting: "C",
    choices: [
      { id: "A", en: "reviewers:", ar: "reviewers:" },
      { id: "B", en: "reviewers", ar: "reviewers", trap: "agreement" },
      { id: "C", en: "reviewers,", ar: "reviewers,", trap: "agreement" },
      { id: "D", en: "reviewers;", ar: "reviewers;", trap: "agreement" },
    ],
    why: {
      A: {
        en: "Yes. A colon introduces a list that the words before it have already announced (“three things”).",
        ar: "صحيح. النقطتان الرأسيتان تقدّمان قائمة أعلنت عنها الكلمات السابقة («ثلاثة أشياء»).",
      },
      B: {
        en: "Nothing joins the announcement to the list. The sentence runs straight through.",
        ar: "لا شيء يصل الإعلان بالقائمة. الجملة تجري بلا مفصل.",
      },
      C: {
        en: "A comma can’t introduce this list. It is the familiar pause, which is why it tempts, but the convention here is a colon.",
        ar: "الفاصلة لا تقدّم هذه القائمة. الوقف مألوف لذلك يغري، لكن القاعدة هنا النقطتان.",
      },
      D: {
        en: "A semicolon links independent clauses. What follows is a list, not a clause.",
        ar: "الفاصلة المنقوطة تربط جملتين مستقلتين. ما يلي قائمة لا جملة.",
      },
    },
  },
  {
    id: "synthesis",
    domain: "expression",
    passage:
      "A student is writing a note about a library policy. The student wants to emphasize that the change affects evening readers, not the whole city. Which choice most effectively uses relevant information from the notes below?\n\n• Evening hours cut from 10 p.m. to 8 p.m. on weekdays.\n• Weekend hours unchanged.\n• City council also discussed streetlights, a separate topic.",
    passageAr:
      "يكتب طالب ملاحظة عن سياسة مكتبة. يريد أن يؤكّد أن التغيير يخص قرّاء المساء لا المدينة كلها. أي خيار يستخدم المعلومة المناسبة من الملاحظات؟\n\n• ساعات المساء تُقلَّص من 10 إلى 8 مساءً في أيام الأسبوع.\n• ساعات عطلة الأسبوع بلا تغيير.\n• مجلس المدينة ناقش أيضًا إنارة الشوارع، وهو موضوع منفصل.",
    stem: "Which choice most effectively accomplishes the student’s goal?",
    stemAr: "أي خيار يحقّق هدف الطالب بفعالية أكبر؟",
    correct: "B",
    tempting: "D",
    choices: [
      {
        id: "A",
        en: "The council debated streetlights and also considered the library.",
        ar: "ناقش المجلس إنارة الشوارع ونظر أيضًا في المكتبة.",
        trap: "out-of-scope",
      },
      {
        id: "B",
        en: "On weekdays the library now closes at 8 p.m., so the cut lands on evening readers; weekends are unchanged.",
        ar: "في أيام الأسبوع تغلق المكتبة الآن عند 8 مساءً، فالتقصير يقع على قرّاء المساء؛ وعطلة الأسبوع بلا تغيير.",
      },
      {
        id: "C",
        en: "The library has ruined reading for everyone in the city.",
        ar: "دمّرت المكتبة القراءة لكل سكان المدينة.",
        trap: "too-extreme",
      },
      {
        id: "D",
        en: "The library changed its hours, which shows the city is rethinking public space.",
        ar: "غيّرت المكتبة ساعات عملها، ما يُظهر أن المدينة تعيد التفكير في الفضاء العام.",
        trap: "half-right",
      },
    ],
    why: {
      A: {
        en: "Out of scope. Streetlights are labeled a separate topic. Using them misses the goal.",
        ar: "خارج النطاق. إنارة الشوارع موصوفة كموضوع منفصل. استخدامها يضيّع الهدف.",
      },
      B: {
        en: "Yes. It keeps the weekday cut, names who is affected, and uses the weekend fact to limit the claim.",
        ar: "صحيح. يُبقي تقليص أيام الأسبوع، ويسمّي المتأثرين، ويستخدم حقيقة العطلة ليحدّ الادّعاء.",
      },
      C: {
        en: "Too extreme. “Ruined” and “everyone” are not in the notes, and they contradict the goal.",
        ar: "مبالغة. «دمّرت» و«كل السكان» ليستا في الملاحظات، وتناقضان الهدف.",
      },
      D: {
        en: "Half-right. Hours did change. “The whole city is rethinking public space” widens the claim the student wanted to narrow.",
        ar: "نصفها صحيح. الساعات تغيّرت. «المدينة كلها تعيد التفكير» يوسّع ادّعاءً أراد الطالب تضييقه.",
      },
    },
  },
];

export const heroQuestion = questions[0];

export const twinQuestion = questions[1];

export const moduleOne = ["buses", "neither", "reef", "archive"];
export const moduleTwo = ["poet", "catalyst", "notes", "synthesis"];

export function getQuestion(id: string) {
  const found = questions.find((q) => q.id === id);
  if (!found) throw new Error(`Missing question ${id}`);
  return found;
}

export const decoder: DecoderSentence[] = [
  {
    id: "s1",
    role: "claim",
    en: "Scientists once treated coral bleaching as a local nuisance.",
    ar: "كان العلماء يعاملون ابيضاض المرجان كإزعاج محلي.",
    noteEn: "Claim, and an old one. “Once” tells you this view is about to be retired. Don’t fall in love with it.",
    noteAr: "ادّعاء، وقديم. كلمة once تقول إن هذا الرأي سيُستبدَل. لا تتعلّق به.",
  },
  {
    id: "s2",
    role: "pivot",
    en: "Newer surveys, however, show the same heat-driven collapse repeating across distant reefs.",
    ar: "غير أن مسوحًا أحدث تُظهر الانهيار نفسه المدفوع بالحرارة يتكرّر في شعاب بعيدة.",
    noteEn: "Pivot. “However” turns the local story into a repeated pattern. This is the sentence the question will lean on.",
    noteAr: "انعطاف. however تقلب القصة المحلية إلى نمط متكرّر. هذه الجملة التي سيستند إليها السؤال.",
  },
  {
    id: "s3",
    role: "claim",
    en: "The pattern posits a global stressor rather than a string of isolated accidents.",
    ar: "النمط يطرح عامل ضغط عالميًا لا سلسلة حوادث معزولة.",
    noteEn: "Second claim. “Posits” offers an interpretation. “Rather than” cancels the accident reading. Vocab lives here.",
    noteAr: "ادّعاء ثانٍ. posits تطرح تفسيرًا. rather than تلغي قراءة «الحوادث». المفردات هنا.",
  },
  {
    id: "s4",
    role: "conclusion",
    en: "If that reading is right, protecting a single shoreline will not, by itself, stop the loss.",
    ar: "إن صحّت هذه القراءة، فحماية شاطئ واحد لن توقف الفقد وحدها.",
    noteEn: "Conclusion, hedged. “If” and “by itself” keep it from saying local work is useless. Watch for a trap that deletes those limits.",
    noteAr: "نتيجة بحذر. if و by itself تمنعان القول إن العمل المحلي بلا جدوى. انتبه لفخ يحذف هذين القيدين.",
  },
];

export const vocab = [
  {
    id: "posits",
    word: "posits",
    pos: "v.",
    en: "Puts an idea forward as a claim to be considered.",
    ar: "يطرح فكرة بوصفها ادّعاءً قابلًا للنظر.",
    example: "The paper posits a cause; it does not prove one.",
  },
  {
    id: "catalyst",
    word: "catalyst",
    pos: "n.",
    en: "Something that starts a change without being the whole change.",
    ar: "ما يبدأ التغيير من غير أن يكون التغيير كله.",
    example: "The grant was a catalyst, not the discovery.",
  },
  {
    id: "caveat",
    word: "caveat",
    pos: "n.",
    en: "A warning or limit attached to a claim.",
    ar: "تحفّظ أو قيد مُلحَق بادّعاء.",
    example: "The result stands, with one caveat.",
  },
  {
    id: "undermine",
    word: "undermine",
    pos: "v.",
    en: "To weaken something gradually from underneath.",
    ar: "يُضعف شيئًا تدريجيًا من أساسه.",
    example: "One contrary count can undermine a tidy theory.",
  },
  {
    id: "corroborate",
    word: "corroborate",
    pos: "v.",
    en: "To support a claim with further evidence.",
    ar: "يدعم ادّعاءً بدليل إضافي.",
    example: "A second survey corroborated the first.",
  },
  {
    id: "ambivalent",
    word: "ambivalent",
    pos: "adj.",
    en: "Holding two conflicting feelings at once.",
    ar: "يحمل شعورين متعارضين في الوقت نفسه.",
    example: "She was ambivalent about the revision.",
  },
  {
    id: "pragmatic",
    word: "pragmatic",
    pos: "adj.",
    en: "Concerned with what works, not with a pure theory.",
    ar: "يهتم بما ينجح عمليًا لا بالنظرية الخالصة.",
    example: "The fix was pragmatic: shorter evenings, same weekends.",
  },
  {
    id: "ostensibly",
    word: "ostensibly",
    pos: "adv.",
    en: "Seemingly, as presented — often with doubt.",
    ar: "في الظاهر، كما يُعرَض — وغالبًا مع شك.",
    example: "The cut was ostensibly about staffing.",
  },
  {
    id: "mitigate",
    word: "mitigate",
    pos: "v.",
    en: "To make something harmful less severe.",
    ar: "يخفّف من شدّة شيء ضار.",
    example: "Shade can mitigate heat; it cannot erase it.",
  },
  {
    id: "pervasive",
    word: "pervasive",
    pos: "adj.",
    en: "Spreading through every part of something.",
    ar: "ينتشر في كل جزء من الشيء.",
    example: "The stressor was pervasive, not local.",
  },
];

export const diagnostics = [
  {
    id: "build",
    from: 570,
    to: 680,
    gain: 110,
    gainIsSample: true,
    weak: ["sec", "info"] as DomainId[],
    plan: [
      { en: "Boundaries and agreement, 20 focused minutes, four days.", ar: "علامات الترقيم والمطابقة، عشرون دقيقة مركّزة، أربعة أيام." },
      { en: "One passage decoded sentence by sentence — claim, pivot, conclusion.", ar: "فقرة واحدة تُفكَّك جملةً جملة: ادّعاء، انعطاف، نتيجة." },
      { en: "Error vault: retry every “too extreme” card that is due.", ar: "خزنة الأخطاء: أعد كل بطاقة «مبالغة» استحقّت المراجعة." },
      { en: "Fifteen vocabulary cards, said out loud, not highlighted and forgotten.", ar: "خمس عشرة بطاقة مفردات تُقال بصوت، لا تُظلَّل ثم تُنسى." },
    ],
  },
  {
    id: "push",
    from: 650,
    to: 760,
    gain: 110,
    gainIsSample: false,
    weak: ["craft", "expression"] as DomainId[],
    plan: [
      { en: "Main purpose and function questions: name the trap before you pick.", ar: "أسئلة الغرض ووظيفة الجملة: سمِّ الفخ قبل أن تختار." },
      { en: "Transitions: decide the relationship (contrast, example, result) before reading the words.", ar: "أدوات الربط: حدّد العلاقة (تباين، مثال، نتيجة) قبل قراءة الكلمات." },
      { en: "Rhetorical synthesis: cross out any note the goal did not ask for.", ar: "التركيب البلاغي: اشطب أي ملاحظة لم يطلبها الهدف." },
      { en: "Keep a weekly vault review. At this band, repeated traps cost more than new content.", ar: "مراجعة أسبوعية للخزنة. في هذا النطاق، تكرار الفخ أغلى من محتوى جديد." },
    ],
  },
];

export const reports = [
  {
    id: "zaid",
    name: "Zaid",
    rwFrom: 630,
    rwTo: 740,
    totalLabel: "1500 total",
    totalLabelAr: "المجموع 1500",
    noteEn: "Reading & Writing, as reported. Total score 1500.",
    noteAr: "القراءة والكتابة كما أُبلغ عنها. المجموع 1500.",
  },
  {
    id: "nancy",
    name: "Nancy",
    rwFrom: 440,
    rwTo: 650,
    totalLabel: "900 → 1360 total",
    totalLabelAr: "المجموع من 900 إلى 1360",
    noteEn: "Reading & Writing 440 to 650. Total score from 900 to 1360.",
    noteAr: "القراءة والكتابة من 440 إلى 650. المجموع من 900 إلى 1360.",
  },
];

export const faq = [
  {
    qEn: "Is this only Digital SAT English?",
    qAr: "هل هذا لإنجليزي السات الرقمي فقط؟",
    aEn: "Yes. ScoreHigh with Teacher Ziad Ahmed is Reading & Writing: the logic of passages, the traps in the choices, and the conventions that decide close calls. Math is not part of the program.",
    aAr: "نعم. سكورهاي مع المدرّس زياد أحمد للقراءة والكتابة: منطق الفقرات، وفخاخ الاختيارات، والقواعد التي تحسم الخيارات المتقاربة. الرياضيات ليست ضمن البرنامج.",
  },
  {
    qEn: "Who is it for?",
    qAr: "لمن هذا البرنامج؟",
    aEn: "High-school students, mostly 16 to 18, in Egypt, Saudi Arabia, and the UAE — and the parents who are deciding whether to pay. The site is in English and Arabic.",
    aAr: "لطلاب الثانوية، غالبًا من 16 إلى 18، في مصر والسعودية والإمارات — وللأهل الذين يقررون الدفع. الموقع بالإنجليزية والعربية.",
  },
  {
    qEn: "What is the difference between the group and the 1-on-1?",
    qAr: "ما الفرق بين المجموعة والتدريب الفردي؟",
    aEn: "The live group is the main road: shared sessions, the AI lab, the error vault, vocabulary, practice modules, the question bank, recordings, and homework quizzes. Elite 1-on-1 adds a private coach and a personal weekly plan. Seats there are limited. Prices are confirmed on WhatsApp before anyone pays — this page does not invent a number.",
    aAr: "المجموعة المباشرة هي الطريق الأساسي: حصص مشتركة، ومختبر الذكاء، وخزنة الأخطاء، والمفردات، ووحدات التدريب، وبنك الأسئلة، والتسجيلات، وواجبات قصيرة. التدريب الفردي يضيف مدرّبًا خاصًا وخطة أسبوعية شخصية. المقاعد فيه محدودة. السعر يُؤكَّد على واتساب قبل أي دفع — هذه الصفحة لا تخترع رقمًا.",
  },
  {
    qEn: "Do you guarantee a score?",
    qAr: "هل تضمنون درجة؟",
    aEn: "No. Zaid’s move from 630 to 740 in Reading & Writing (1500 total) and Nancy’s from 440 to 650 (900 to 1360 total) are reported results, not a promise that the next student will match them. The work is to train how you think under the test’s traps.",
    aAr: "لا. انتقال زيد من 630 إلى 740 في القراءة والكتابة (المجموع 1500) ونانسي من 440 إلى 650 (المجموع من 900 إلى 1360) نتائج مُبلَّغ عنها، ليست وعدًا بأن الطالب التالي سيطابقها. العمل هو تدريب طريقة التفكير تحت فخاخ الاختبار.",
  },
  {
    qEn: "What does the AI actually do?",
    qAr: "ماذا يفعل الذكاء الاصطناعي فعلًا؟",
    aEn: "Three things you can try on this site with sample items: it clones a question into a twin that tests the same logic, it names the trap inside a wrong answer, and it breaks a dense passage sentence by sentence in English and Arabic. It is a training tool. It is not the College Board, and it does not see your official Bluebook exam.",
    aAr: "ثلاثة أشياء يمكن تجربتها هنا بأمثلة: يصنع سؤالًا توأمًا يختبر المنطق نفسه، ويسمّي الفخ داخل الإجابة الخطأ، ويفكك فقرة كثيفة جملةً جملة بالإنجليزية والعربية. هو أداة تدريب. ليس College Board، ولا يرى اختبار بلو بوك الرسمي الخاص بك.",
  },
  {
    qEn: "What is in the free vault?",
    qAr: "ماذا في الخزنة المجانية؟",
    aEn: "A masterclass recording, a walkthrough of Bluebook Exam 11, and a Drive folder of real questions. The page asks for a name and an email or WhatsApp number so the studio can send them. Submitting the form on this demo does not yet deliver the files — the links are placeholders until the studio connects them.",
    aAr: "تسجيل للماستر كلاس، وشرح لامتحان بلو بوك 11، ومجلد درايف لأسئلة حقيقية. الصفحة تطلب اسمًا وبريدًا أو رقم واتساب ليرسل الاستوديو المواد. إرسال النموذج في هذا العرض لا يسلّم الملفات بعد — الروابط عناصر نائبة إلى أن يربطها الاستوديو.",
  },
  {
    qEn: "How do we enroll?",
    qAr: "كيف يتم التسجيل؟",
    aEn: "WhatsApp, +20 159 990 6731. That is the door for the group, the 1-on-1, and questions from parents. Say which program you are asking about and a current Reading & Writing score if you have one.",
    aAr: "واتساب، ‎+20 159 990 6731. هذا باب المجموعة والتدريب الفردي وأسئلة الأهل. اذكر البرنامج الذي تسأل عنه ودرجة القراءة والكتابة الحالية إن وُجدت.",
  },
  {
    qEn: "What does “structured, strategic, supportive” mean in practice?",
    qAr: "ماذا تعني «منظّم، استراتيجي، داعم» عمليًا؟",
    aEn: "Structured: a diagnostic, a weekly plan, and a vault of your own mistakes — not a pile of random worksheets. Strategic: every wrong answer has a job; you name the trap, then you choose. Supportive: a live group, a limited 1-on-1, and a free vault you can open before you pay.",
    aAr: "منظّم: تشخيص، وخطة أسبوعية، وخزنة لأخطائك أنت — لا كومة أوراق عشوائية. استراتيجي: لكل إجابة خطأ وظيفة؛ تسمّي الفخ ثم تختار. داعم: مجموعة مباشرة، وتدريب فردي محدود، وخزنة مجانية يمكن فتحها قبل الدفع.",
  },
];

export const pillars = [
  {
    id: "structured",
    en: "Structured",
    ar: "منظّم",
    bodyEn: "A diagnostic, a week you can see, and a vault that remembers the miss. The path is visible before the homework is.",
    bodyAr: "تشخيص، وأسبوع يمكن رؤيته، وخزنة تتذكّر الخطأ. الطريق ظاهر قبل الواجب.",
  },
  {
    id: "strategic",
    en: "Strategic",
    ar: "استراتيجي",
    bodyEn: "Content is not the product. The product is the moment two answers look the same and you know which word is doing the lying.",
    bodyAr: "المحتوى ليس المنتج. المنتج هو اللحظة التي تتشابه فيها إجابتان وتعرف أي كلمة تكذب.",
  },
  {
    id: "supportive",
    en: "Supportive",
    ar: "داعم",
    bodyEn: "Live company when you want it, a person when you need one, and a free door if you are not ready to pay.",
    bodyAr: "رفقة مباشرة حين تريدها، وشخص حين تحتاجه، وباب مجاني إن لم تكن جاهزًا للدفع.",
  },
];

export type ProgramId = "group" | "elite" | "vault";

export const programs: {
  id: ProgramId;
  en: string;
  ar: string;
  tagEn: string;
  tagAr: string;
  points: { en: string; ar: string }[];
}[] = [
  {
    id: "group",
    en: "Live Group Course",
    ar: "دورة المجموعة المباشرة",
    tagEn: "Most students start here",
    tagAr: "هنا يبدأ أكثر الطلاب",
    points: [
      { en: "Live sessions with Teacher Ziad Ahmed", ar: "حصص مباشرة مع المدرّس زياد أحمد" },
      { en: "AI lab: cloner, trap notes, passage decoder", ar: "مختبر الذكاء: النسخ، وملاحظات الفخ، ومفكّك الفقرات" },
      { en: "Error vault, vocabulary arena, practice modules, question bank", ar: "خزنة الأخطاء، وساحة المفردات، ووحدات التدريب، وبنك الأسئلة" },
      { en: "Recorded sessions and homework quizzes", ar: "تسجيلات الحصص وواجبات قصيرة" },
    ],
  },
  {
    id: "elite",
    en: "Elite 1-on-1",
    ar: "تدريب فردي نخبة",
    tagEn: "Limited spots",
    tagAr: "مقاعد محدودة",
    points: [
      { en: "Everything in the group course", ar: "كل ما في دورة المجموعة" },
      { en: "Private coaching and a personal weekly plan", ar: "تدريب خاص وخطة أسبوعية شخصية" },
      { en: "A diagnostic read against your target, not a generic ladder", ar: "قراءة تشخيصية مقابل هدفك، لا سلّم عام" },
      { en: "Seats stay few on purpose", ar: "المقاعد قليلة عن قصد" },
    ],
  },
  {
    id: "vault",
    en: "Free Masterclass & Exam Vault",
    ar: "الماستر كلاس وخزنة الاختبار مجانًا",
    tagEn: "Open before you pay",
    tagAr: "مفتوح قبل أن تدفع",
    points: [
      { en: "Masterclass recording", ar: "تسجيل الماستر كلاس" },
      { en: "Bluebook Exam 11 walkthrough", ar: "شرح امتحان بلو بوك 11" },
      { en: "Drive folder of real questions", ar: "مجلد درايف لأسئلة حقيقية" },
      { en: "No price. A name and a way to reach you.", ar: "بلا سعر. اسم وطريقة للتواصل." },
    ],
  },
];

export const sampleMistakes: {
  id: string;
  questionId: string;
  chosen: ChoiceId;
  trap: TrapKind;
  domain: DomainId;
}[] = [
  { id: "sample-1", questionId: "archive", chosen: "C", trap: "too-extreme", domain: "info" },
  { id: "sample-2", questionId: "buses", chosen: "A", trap: "too-extreme", domain: "craft" },
  { id: "sample-3", questionId: "poet", chosen: "A", trap: "half-right", domain: "info" },
  { id: "sample-4", questionId: "reef", chosen: "D", trap: "half-right", domain: "expression" },
];

export const sampleMastery: Record<DomainId, number> = {
  craft: 62,
  info: 48,
  sec: 71,
  expression: 55,
};
