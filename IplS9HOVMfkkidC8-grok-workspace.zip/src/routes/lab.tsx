import { createFileRoute } from "@tanstack/react-router";
import { LabPanel } from "@/components/marketing/lab-panel";
import { FinalCta, } from "@/routes/index";
import { SiteFrame } from "@/components/site/chrome";

export const Route = createFileRoute("/lab")({
  head: () => ({
    meta: [
      { title: "AI lab · ScoreHigh" },
      {
        name: "description",
        content:
          "Trap lab, bilingual passage decoder, and a sample AI coach diagnostic for Digital SAT Reading & Writing.",
      },
    ],
  }),
  component: LabPage,
});

function LabPage() {
  return (
    <SiteFrame>
      <LabPanel />
      <FinalCta />
    </SiteFrame>
  );
}
