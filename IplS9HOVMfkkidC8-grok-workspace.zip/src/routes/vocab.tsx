import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { StudioShell } from "@/components/studio/shell";
import { vocab } from "@/lib/content";
import { usePrefs } from "@/lib/store";
import { useT } from "@/lib/use-t";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/vocab")({
  head: () => ({
    meta: [
      { title: "Vocabulary arena · ScoreHigh" },
      { name: "description", content: "Flashcards and a quick-fire word game for Digital SAT Reading & Writing." },
    ],
  }),
  component: VocabPage,
});

function VocabPage() {
  const { t, lang } = useT();
  const xp = usePrefs((s) => s.xp);
  const addVocab = usePrefs((s) => s.addVocab);
  const [mode, setMode] = useState<"cards" | "fire">("cards");
  const [i, setI] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [streak, setStreak] = useState(0);
  const [picked, setPicked] = useState<string | null>(null);
  const card = vocab[i % vocab.length];

  const options = useMemo(() => {
    const others = vocab.filter((w) => w.id !== card.id).slice(0, 3);
    return [...others, card].sort((a, b) => a.word.localeCompare(b.word));
  }, [card]);

  function next(good: boolean) {
    addVocab(good);
    setStreak((s) => (good ? s + 1 : 0));
    setFlipped(false);
    setPicked(null);
    setI((n) => n + 1);
  }

  return (
    <StudioShell>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-5xl leading-none">{t.vocab.title}</h1>
          <p className="mt-2 font-mono text-sm text-muted">
            {t.vocab.streak} {streak} · {t.vocab.xp} {xp}
          </p>
        </div>
        <div className="flex rounded-full border border-line p-1">
          <button type="button" className={cn("min-h-10 rounded-full px-3", mode === "cards" && "bg-ink text-paper")} onClick={() => setMode("cards")}>
            {t.vocab.cards}
          </button>
          <button type="button" className={cn("min-h-10 rounded-full px-3", mode === "fire" && "bg-ink text-paper")} onClick={() => setMode("fire")}>
            {t.vocab.fire}
          </button>
        </div>
      </div>

      {mode === "cards" ? (
        <div className="mt-8 max-w-lg">
          <button
            type="button"
            onClick={() => setFlipped((v) => !v)}
            className="min-h-56 w-full border border-line bg-sheet p-6 text-start"
          >
            <p className="font-mono text-xs text-muted">{flipped ? card.pos : t.vocab.flip}</p>
            <p className="mt-3 font-display text-5xl" dir="ltr">
              {flipped ? (lang === "ar" ? card.ar : card.en) : card.word}
            </p>
            {flipped ? (
              <p className="mt-4 text-sm text-muted" dir="ltr">
                {card.example}
              </p>
            ) : null}
          </button>
          <div className="mt-4 flex gap-2">
            <button type="button" className="min-h-11 flex-1 rounded-full border border-line" onClick={() => next(false)}>
              {t.vocab.missed}
            </button>
            <button type="button" className="min-h-11 flex-1 rounded-full bg-signal font-semibold text-ink" onClick={() => next(true)}>
              {t.vocab.knew}
            </button>
          </div>
        </div>
      ) : (
        <div className="mt-8 max-w-lg">
          <p className="text-sm text-muted">{t.vocab.prompt}</p>
          <p className="mt-2 font-display text-3xl">{lang === "ar" ? card.ar : card.en}</p>
          <div className="mt-4 grid gap-2">
            {options.map((option) => {
              const show = picked !== null;
              const good = option.id === card.id;
              return (
                <button
                  key={option.id}
                  type="button"
                  disabled={picked !== null}
                  dir="ltr"
                  onClick={() => {
                    setPicked(option.id);
                    addVocab(good);
                    setStreak((s) => (good ? s + 1 : 0));
                  }}
                  className={cn(
                    "min-h-12 border px-3 text-start",
                    show && good && "border-mark bg-signal",
                    show && picked === option.id && !good && "border-trap",
                  )}
                >
                  {option.word}
                </button>
              );
            })}
          </div>
          {picked ? (
            <button
              type="button"
              className="mt-4 min-h-11 rounded-full bg-ink px-4 font-semibold text-paper"
              onClick={() => {
                setPicked(null);
                setI((n) => n + 1);
              }}
            >
              {t.vocab.next}
            </button>
          ) : null}
        </div>
      )}
    </StudioShell>
  );
}
