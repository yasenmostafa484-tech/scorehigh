import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { StudioShell } from "@/components/studio/shell";
import { domains, reports } from "@/lib/content";
import { usePrefs } from "@/lib/store";
import { useT } from "@/lib/use-t";

export const Route = createFileRoute("/teacher")({
  head: () => ({
    meta: [
      { title: "Teacher view · ScoreHigh" },
      { name: "description", content: "Reported scores for Zaid and Nancy, plus this browser’s live demo." },
    ],
  }),
  component: TeacherPage,
});

function TeacherPage() {
  const { t, lang } = useT();
  const history = usePrefs((s) => s.history);
  const stats = usePrefs((s) => s.domains);
  const profile = usePrefs((s) => s.profile);
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  const total = Object.values(stats).reduce((a, d) => a + d.total, 0);
  const correct = Object.values(stats).reduce((a, d) => a + d.correct, 0);

  return (
    <StudioShell>
      <p className="font-mono text-xs tracking-stamp text-mark uppercase">{t.teacher.eyebrow}</p>
      <h1 className="mt-2 font-display text-5xl leading-none">{t.teacher.title}</h1>
      <p className="mt-3 max-w-2xl text-muted">{t.teacher.lede}</p>
      <div className="mt-8 grid gap-4 md:grid-cols-2">
        {reports.map((report) => (
          <article key={report.id} className="border border-line bg-sheet p-5">
            <p className="font-mono text-xs text-muted">{t.teacher.reported}</p>
            <h2 className="mt-1 font-display text-3xl">{report.name}</h2>
            <p className="mt-4 font-display text-5xl tabular-nums leading-none">
              {report.rwFrom}
              <span className="text-mark"> → </span>
              {report.rwTo}
            </p>
            <p className="mt-3 text-sm">{lang === "ar" ? report.totalLabelAr : report.totalLabel}</p>
            <p className="mt-2 text-xs text-muted">{t.results.only}</p>
          </article>
        ))}
        <article className="border border-dashed border-line p-5 md:col-span-2">
          <h2 className="font-display text-3xl">{t.teacher.placeholder}</h2>
          <p className="mt-2 text-sm text-muted">{t.teacher.placeholderBody}</p>
        </article>
      </div>

      <section className="mt-10 border border-line p-5">
        <p className="font-mono text-xs text-muted">{t.teacher.you}</p>
        <h2 className="font-display text-3xl">{profile?.name ?? (lang === "ar" ? "زائر" : "Guest")}</h2>
        {total === 0 ? (
          <p className="mt-3 text-sm text-muted">{t.teacher.none}</p>
        ) : (
          <>
            <p className="mt-3 font-display text-4xl tabular-nums">
              {Math.round((correct / total) * 100)}%
            </p>
            <p className="text-sm text-muted">{t.teacher.accuracy}</p>
            <div className="mt-4 h-52">
              {mounted ? (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={history}>
                    <CartesianGrid stroke="var(--line)" vertical={false} />
                    <XAxis dataKey="n" stroke="var(--muted)" />
                    <YAxis domain={[0, 100]} stroke="var(--muted)" />
                    <Tooltip />
                    <Line type="monotone" dataKey="accuracy" stroke="var(--mark)" strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              ) : null}
            </div>
            <h3 className="mt-4 text-sm font-semibold">{t.teacher.domains}</h3>
            <ul className="mt-2 space-y-2">
              {domains.map((domain) => {
                const s = stats[domain.id];
                const pct = s.total ? Math.round((s.correct / s.total) * 100) : 0;
                return (
                  <li key={domain.id} className="grid grid-cols-[1fr_auto] gap-3 text-sm">
                    <span>{lang === "ar" ? domain.ar : domain.en}</span>
                    <span className="font-mono tabular-nums">{s.total ? `${pct}%` : "—"}</span>
                  </li>
                );
              })}
            </ul>
          </>
        )}
      </section>
    </StudioShell>
  );
}
