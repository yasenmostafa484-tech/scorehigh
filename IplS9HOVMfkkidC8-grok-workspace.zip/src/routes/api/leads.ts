import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";

const Lead = z.object({
  name: z.string().trim().min(1).max(80),
  contact: z.string().trim().min(5).max(120),
  note: z.string().trim().max(400).optional(),
});

export const Route = createFileRoute("/api/leads")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const body = await request.json().catch(() => null);
        const parsed = Lead.safeParse(body);
        if (!parsed.success) {
          return Response.json({ ok: false, error: "invalid" }, { status: 400 });
        }
        return Response.json({
          ok: true,
          id: `lead_${Date.now()}`,
          received: { name: parsed.data.name },
        });
      },
    },
  },
});
