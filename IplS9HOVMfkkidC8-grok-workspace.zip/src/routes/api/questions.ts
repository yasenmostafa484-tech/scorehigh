import { createFileRoute } from "@tanstack/react-router";
import { questions } from "@/lib/content";

export const Route = createFileRoute("/api/questions")({
  server: {
    handlers: {
      GET: async () => Response.json({ questions }),
    },
  },
});
