import { createFileRoute } from "@tanstack/react-router";
import { diagnostics } from "@/lib/content";

export const Route = createFileRoute("/api/diagnostics")({
  server: {
    handlers: {
      GET: async () => Response.json({ diagnostics }),
    },
  },
});
