import { createFileRoute } from "@tanstack/react-router";
import { FaqList } from "@/components/marketing/faq-list";
import { FinalCta } from "@/routes/index";
import { SiteFrame } from "@/components/site/chrome";
import { useT } from "@/lib/use-t";

export const Route = createFileRoute("/faq")({
  head: () => ({
    meta: [
      { title: "FAQ · ScoreHigh" },
      { name: "description", content: "Straight answers about ScoreHigh SAT Prep, programs, the AI lab, and enrollment." },
    ],
  }),
  component: FaqPage,
});

function FaqPage() {
  const { t } = useT();
  return (
    <SiteFrame>
      <section className="mx-auto max-w-3xl px-4 py-14">
        <p className="font-mono text-xs tracking-stamp text-mark uppercase">{t.faq.eyebrow}</p>
        <h1 className="mt-3 font-display text-5xl leading-none">{t.faq.title}</h1>
        <div className="mt-8">
          <FaqList />
        </div>
      </section>
      <FinalCta />
    </SiteFrame>
  );
}
