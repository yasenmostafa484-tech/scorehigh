import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { StudioShell } from "@/components/studio/shell";
import { domains } from "@/lib/content";
import { dueCount, missionCount, usePrefs, type Profile } from "@/lib/store";
import { useT } from "@/lib/use-t";

export const Route = createFileRoute("/dashboard")({
  head: () => ({
    meta: [
      { title: "Today · ScoreHigh" },
      { name: "description", content: "Student demo: today’s mission, streak, and a score sketch for ScoreHigh." },
    ],
  }),
  component: DashboardPage,
});

const MONTHS = ["Mar 2026", "May 2026", "Jun 2026", "Aug 2026", "Sep 2026", "Oct 2026", "Nov 2026", "Dec 2026", "Mar 2027", "Not set"];

function DashboardPage() {
  const profile = usePrefs((s) => s.profile);
  if (!profile) return <Onboarding />;
  return (
    <StudioShell>
      <Today profile={profile} />
    </StudioShell>
  );
}

function Onboarding() {
  const { t, lang } = useT();
  const setProfile = usePrefs((s) => s.setProfile);
  const [step, setStep] = useState(0);
  const [name, setName] = useState("");
  const [current, setCurrent] = useState(580);
  const [target, setTarget] = useState(700);
  const [testDate, setTestDate] = useState(MONTHS[1]);
  const [ready, setReady] = useState(false);

  const focus = current < 600 ? (["sec", "info"] as const) : current < 700 ? (["craft", "info"] as const) : (["craft", "expression"] as const);

  const draft: Profile = {
    name: name.trim() || (lang === "ar" ? "طالب" : "Student"),
    current,
    target: Math.max(target, current),
    testDate,
  };

  if (ready) {
    return (
      <StudioShell>
        <p className="font-mono text-xs tracking-stamp text-mark uppercase">{t.dash.roadmap}</p>
        <h1 className="mt-2 font-display text-5xl leading-none">{draft.name}</h1>
        <Scale current={draft.current} target={draft.target} />
        <p className="mt-2 text-xs text-muted">{t.dash.estimate}</p>
        <h2 className="mt-8 font-display text-2xl">{t.dash.focus}</h2>
        <ul className="mt-3 space-y-2">
          {focus.map((id) => {
            const d = domains.find((item) => item.id === id);
            return (
              <li key={id} className="border-s-4 border-mark ps-3">
                {lang === "ar" ? d?.ar : d?.en}
              </li>
            );
          })}
        </ul>
        <p className="mt-4 text-sm text-muted">{testDate === "Not set" ? t.dash.noDate : t.dash.weeks}</p>
        <button
          type="button"
          className="mt-6 min-h-12 rounded-full bg-signal px-5 font-semibold text-ink"
          onClick={() => setProfile(draft)}
        >
          {t.dash.enter}
        </button>
      </StudioShell>
    );
  }

  return (
    <main className="mx-auto min-h-screen max-w-xl bg-paper px-4 py-12 text-ink">
      <p className="font-mono text-xs tracking-stamp text-mark uppercase">{t.dash.onboardKicker}</p>
      <h1 className="mt-3 font-display text-5xl leading-none">{t.dash.onboardTitle}</h1>
      <p className="mt-6 font-mono text-xs text-muted">0{step + 1} / 03</p>
      {step === 0 ? (
        <label className="mt-4 grid gap-2">
          <span>{t.dash.name}</span>
          <input
            value={name}
            placeholder={t.dash.namePh}
            onChange={(e) => setName(e.target.value)}
            className="min-h-12 border border-line bg-sheet px-3"
          />
        </label>
      ) : null}
      {step === 1 ? (
        <div className="mt-4 grid gap-6">
          <ScoreField label={t.dash.currentQ} value={current} onChange={setCurrent} />
          <ScoreField label={t.dash.targetQ} value={target} onChange={setTarget} />
        </div>
      ) : null}
      {step === 2 ? (
        <label className="mt-4 grid gap-2">
          <span>{t.dash.dateQ}</span>
          <select
            value={testDate}
            onChange={(e) => setTestDate(e.target.value)}
            className="min-h-12 border border-line bg-sheet px-3"
          >
            {MONTHS.map((month) => (
              <option key={month}>{month}</option>
            ))}
          </select>
        </label>
      ) : null}
      <div className="mt-8 flex gap-2">
        {step > 0 ? (
          <button type="button" className="min-h-11 rounded-full border border-line px-4" onClick={() => setStep((s) => s - 1)}>
            {t.programs.back}
          </button>
        ) : null}
        <button
          type="button"
          className="min-h-11 rounded-full bg-ink px-4 font-semibold text-paper"
          onClick={() => (step === 2 ? setReady(true) : setStep((s) => s + 1))}
        >
          {t.programs.next}
        </button>
      </div>
    </main>
  );
}

function ScoreField({ label, value, onChange }: { label: string; value: number; onChange: (n: number) => void }) {
  return (
    <label className="grid gap-2">
      <span className="flex justify-between">
        {label}
        <span className="font-display text-3xl tabular-nums">{value}</span>
      </span>
      <input
        type="range"
        min={400}
        max={800}
        step={10}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="accent-ink"
      />
    </label>
  );
}

function Today({ profile }: { profile: Profile }) {
  const { t } = useT();
  const missions = usePrefs((s) => s.missions);
  const streak = usePrefs((s) => s.streak);
  const vault = usePrefs((s) => s.vault);
  const done = missionCount(missions);
  const due = dueCount(vault);
  const ring = useMemo(() => {
    const r = 42;
    const c = 2 * Math.PI * r;
    return { r, c, dash: `${(c * done) / 3} ${c}` };
  }, [done]);

  const rows = [
    { ok: missions.practice, label: t.dash.missionPractice },
    { ok: missions.vocab >= 5, label: t.dash.missionVocab },
    { ok: missions.vault >= 1, label: t.dash.missionVault },
  ];

  return (
    <div className="grid gap-6 lg:grid-cols-[1.2fr_0.8fr]">
      <div>
        <p className="font-mono text-xs tracking-stamp text-muted uppercase">{t.dash.hello}</p>
        <h1 className="mt-2 font-display text-5xl leading-none">{profile.name}</h1>
        <div className="mt-6 border border-line bg-sheet p-5">
          <p className="font-mono text-xs tracking-stamp text-mark uppercase">{t.dash.mission}</p>
          <ul className="mt-4 space-y-3">
            {rows.map((row) => (
              <li key={row.label} className="flex items-center gap-3">
                <span className={row.ok ? "bg-signal text-ink" : "border border-line"} style={{ width: 18, height: 18, display: "inline-grid", placeItems: "center", fontSize: 12 }}>
                  {row.ok ? "✓" : ""}
                </span>
                <span className={row.ok ? "text-muted line-through" : ""}>{row.label}</span>
              </li>
            ))}
          </ul>
          <Link to="/practice" className="mt-6 inline-flex min-h-11 items-center rounded-full bg-signal px-4 text-sm font-semibold text-ink">
            {t.dash.continue}
          </Link>
        </div>
      </div>
      <div className="grid gap-4">
        <div className="flex items-center gap-4 border border-line p-4">
          <svg width="100" height="100" viewBox="0 0 100 100" aria-hidden>
            <circle cx="50" cy="50" r={ring.r} fill="none" stroke="var(--line)" strokeWidth="8" />
            <circle
              cx="50"
              cy="50"
              r={ring.r}
              fill="none"
              stroke="var(--mark)"
              strokeWidth="8"
              strokeDasharray={ring.dash}
              strokeLinecap="round"
              transform="rotate(-90 50 50)"
            />
          </svg>
          <div>
            <p className="font-mono text-xs text-muted">{t.dash.week}</p>
            <p className="font-display text-4xl tabular-nums">
              {done} <span className="text-lg text-muted">{t.dash.of} 3</span>
            </p>
            <p className="text-sm text-muted">
              {t.dash.streak}: {streak}
            </p>
          </div>
        </div>
        <div className="border border-line p-4">
          <p className="font-mono text-xs text-muted">{t.dash.gauge}</p>
          <Scale current={profile.current} target={profile.target} />
          <p className="mt-2 text-xs text-muted">{t.dash.estimate}</p>
          <p className="mt-3 text-sm">
            {t.dash.due}: {due}
          </p>
        </div>
      </div>
    </div>
  );
}

function Scale({ current, target }: { current: number; target: number }) {
  const { t } = useT();
  const place = (n: number) => `${((n - 400) / 400) * 100}%`;
  return (
    <div className="mt-4">
      <div className="relative h-10">
        <div className="absolute inset-x-0 top-3 h-px bg-line" />
        <span className="absolute top-1 size-4 rounded-full bg-ink" style={{ insetInlineStart: place(current) }} />
        <span className="absolute top-0.5 size-5 rounded-full bg-signal" style={{ insetInlineStart: place(target) }} />
      </div>
      <div className="flex justify-between text-xs text-muted">
        <span>
          {t.dash.current} {current}
        </span>
        <span>
          {t.dash.target} {target}
        </span>
      </div>
    </div>
  );
}
