import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { SiteFrame } from "@/components/site/chrome";
import { useT } from "@/lib/use-t";

export const Route = createFileRoute("/vault")({
  head: () => ({
    meta: [
      { title: "Free vault · ScoreHigh" },
      {
        name: "description",
        content: "Masterclass recording, Bluebook Exam 11 walkthrough, and a real-question folder from ScoreHigh.",
      },
    ],
  }),
  component: VaultPage,
});

function VaultPage() {
  const { t } = useT();
  const [name, setName] = useState("");
  const [contact, setContact] = useState("");
  const [note, setNote] = useState("");
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);
  const [done, setDone] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (name.trim().length < 1) {
      setError(t.vault.errName);
      return;
    }
    if (contact.trim().length < 5) {
      setError(t.vault.errContact);
      return;
    }
    setError("");
    setPending(true);
    try {
      const res = await fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, contact, note }),
      });
      if (!res.ok) throw new Error("no");
      const prev = JSON.parse(localStorage.getItem("scorehigh-leads") || "[]") as unknown[];
      localStorage.setItem("scorehigh-leads", JSON.stringify([...prev, { name, contact, note }]));
      setDone(true);
    } catch {
      setError(t.vault.errContact);
    } finally {
      setPending(false);
    }
  }

  const resources = [
    { title: t.vault.master, detail: "Recording" },
    { title: t.vault.exam, detail: "Bluebook 11" },
    { title: t.vault.drive, detail: "Drive" },
  ];

  return (
    <SiteFrame>
      <section className="mx-auto grid max-w-6xl gap-10 px-4 py-14 lg:grid-cols-2">
        <div>
          <p className="font-mono text-xs tracking-stamp text-mark uppercase">{t.vault.eyebrow}</p>
          <h1 className="mt-3 font-display text-5xl leading-none">{t.vault.title}</h1>
          <p className="mt-4 text-muted">{t.vault.lede}</p>
        </div>
        {done ? (
          <div className="border border-line bg-sheet p-6">
            <h2 className="font-display text-3xl">{t.vault.thanks}</h2>
            <p className="mt-3 text-sm text-muted">{t.vault.thanksBody}</p>
            <button type="button" className="mt-5 text-sm font-semibold underline" onClick={() => setDone(false)}>
              {t.vault.again}
            </button>
          </div>
        ) : (
          <form onSubmit={submit} className="grid gap-3 border border-line bg-sheet p-6">
            <label className="grid gap-1 text-sm">
              {t.vault.name}
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="min-h-11 border border-line bg-paper px-3"
                autoComplete="name"
                required
              />
            </label>
            <label className="grid gap-1 text-sm">
              {t.vault.contact}
              <input
                value={contact}
                onChange={(e) => setContact(e.target.value)}
                className="min-h-11 border border-line bg-paper px-3"
                autoComplete="email"
                required
              />
            </label>
            <label className="grid gap-1 text-sm">
              {t.vault.note}
              <textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
                className="min-h-24 border border-line bg-paper px-3 py-2"
              />
            </label>
            {error ? <p className="text-sm text-trap">{error}</p> : null}
            <button
              type="submit"
              disabled={pending}
              className="min-h-12 rounded-full bg-signal px-5 font-semibold text-ink disabled:opacity-60"
            >
              {pending ? t.vault.sending : t.vault.send}
            </button>
          </form>
        )}
      </section>
      <section className="mx-auto max-w-6xl px-4 pb-16">
        <h2 className="font-display text-3xl">{t.vault.items}</h2>
        <div className="mt-4 grid gap-3 md:grid-cols-3">
          {resources.map((item) => (
            <article key={item.title} className="border border-dashed border-line p-5">
              <p className="font-mono text-xs text-muted">{item.detail}</p>
              <h3 className="mt-2 font-display text-2xl">{item.title}</h3>
              <p className="mt-4 font-mono text-xs tracking-stamp text-trap uppercase">{t.vault.locked}</p>
            </article>
          ))}
        </div>
      </section>
    </SiteFrame>
  );
}
