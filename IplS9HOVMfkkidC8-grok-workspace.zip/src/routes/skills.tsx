import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { StudioShell } from "@/components/studio/shell";
import { domains, sampleMastery, type DomainId } from "@/lib/content";
import { usePrefs } from "@/lib/store";
import { useT } from "@/lib/use-t";

export const Route = createFileRoute("/skills")({
  head: () => ({
    meta: [
      { title: "Skill map · ScoreHigh" },
      { name: "description", content: "Reading & Writing domains with mastery from your demo modules." },
    ],
  }),
  component: SkillsPage,
});

function SkillsPage() {
  const { t, lang } = useT();
  const stats = usePrefs((s) => s.domains);
  const [sample, setSample] = useState(false);
  return (
    <StudioShell>
      <p className="font-mono text-xs tracking-stamp text-mark uppercase">{t.skills.title}</p>
      <h1 className="mt-2 font-display text-5xl leading-none">{t.skills.title}</h1>
      <p className="mt-3 max-w-xl text-muted">{t.skills.lede}</p>
      <button type="button" className="mt-4 text-sm font-semibold underline" onClick={() => setSample((v) => !v)}>
        {sample ? t.skills.hide : t.skills.sample}
      </button>
      {sample ? <p className="mt-2 text-sm text-trap">{t.skills.sampleOn}</p> : null}
      <ul className="mt-8 space-y-6">
        {domains.map((domain) => {
          const live = stats[domain.id];
          const pct = sample ? sampleMastery[domain.id as DomainId] : live.total ? Math.round((live.correct / live.total) * 100) : 0;
          return (
            <li key={domain.id}>
              <div className="flex items-baseline justify-between gap-3">
                <h2 className="font-display text-2xl">{lang === "ar" ? domain.ar : domain.en}</h2>
                <span className="font-mono text-sm tabular-nums">{live.total || sample ? `${pct}%` : t.skills.empty}</span>
              </div>
              <div className="mt-2 h-3 bg-line" aria-hidden>
                <div className="h-3 bg-mark transition-all" style={{ width: `${pct}%` }} />
              </div>
              <Link to="/practice" className="mt-2 inline-flex min-h-10 items-center text-sm font-semibold">
                {t.skills.drill}
              </Link>
            </li>
          );
        })}
      </ul>
    </StudioShell>
  );
}
