import { createFileRoute } from "@tanstack/react-router";
import { FitQuiz } from "@/components/marketing/quiz";
import { FinalCta } from "@/routes/index";
import { SiteFrame, WaButton } from "@/components/site/chrome";
import { programs } from "@/lib/content";
import { useT } from "@/lib/use-t";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/programs")({
  head: () => ({
    meta: [
      { title: "Programs · ScoreHigh" },
      {
        name: "description",
        content:
          "Live group course, elite 1-on-1 coaching, and a free masterclass vault. Enrollment on WhatsApp.",
      },
    ],
  }),
  component: ProgramsPage,
});

function ProgramsPage() {
  const { t, lang } = useT();
  return (
    <SiteFrame>
      <section className="mx-auto max-w-6xl px-4 py-14">
        <p className="font-mono text-xs tracking-stamp text-mark uppercase">{t.programs.eyebrow}</p>
        <h1 className="mt-3 max-w-3xl font-display text-5xl leading-none sm:text-6xl">{t.programs.title}</h1>
        <div className="mt-10 grid gap-5">
          {programs.map((program) => (
            <article
              key={program.id}
              className={cn(
                "grid gap-6 border p-5 sm:p-7 lg:grid-cols-[0.8fr_1.2fr]",
                program.id === "group" && "border-ink bg-ink text-paper",
                program.id === "elite" && "border-dashed border-trap bg-sheet",
                program.id === "vault" && "border-line bg-paper",
              )}
            >
              <div>
                <p
                  className={cn(
                    "font-mono text-xs tracking-stamp uppercase",
                    program.id === "group" ? "text-signal" : program.id === "elite" ? "text-trap" : "text-mark",
                  )}
                >
                  {lang === "ar" ? program.tagAr : program.tagEn}
                </p>
                <h2 className={cn("mt-3 font-display text-4xl", program.id === "group" && "text-paper")}>
                  {lang === "ar" ? program.ar : program.en}
                </h2>
                <p className={cn("mt-4 font-display text-5xl", program.id === "group" && "text-signal")}>
                  {program.id === "vault" ? (lang === "ar" ? "مجاني" : "Free") : t.programs.price}
                </p>
                {program.id !== "vault" ? (
                  <p className={cn("mt-1 text-sm", program.id === "group" ? "text-paper/75" : "text-muted")}>
                    {t.programs.priceNote}
                  </p>
                ) : null}
                <div className="mt-5">
                  {program.id === "vault" ? (
                    <a
                      href="/vault"
                      className="inline-flex min-h-12 items-center rounded-full bg-signal px-5 font-semibold text-ink"
                    >
                      {t.nav.vault}
                    </a>
                  ) : (
                    <WaButton
                      message={
                        lang === "ar"
                          ? `مرحبًا، أريد برنامج ${program.ar}. ما السعر والمقاعد؟`
                          : `Hello, I want the ${program.en}. What is the price and availability?`
                      }
                      variant={program.id === "group" ? "signal" : "ink"}
                    >
                      {t.programs.ask}
                    </WaButton>
                  )}
                </div>
              </div>
              <ul className="space-y-3 text-sm">
                {program.points.map((point) => (
                  <li key={point.en} className="border-s-2 border-signal ps-3">
                    {lang === "ar" ? point.ar : point.en}
                  </li>
                ))}
              </ul>
            </article>
          ))}
        </div>
        <div className="mt-12">
          <FitQuiz />
        </div>
      </section>
      <FinalCta />
    </SiteFrame>
  );
}
