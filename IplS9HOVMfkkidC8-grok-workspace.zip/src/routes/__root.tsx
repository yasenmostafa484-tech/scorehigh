import { createRootRoute, HeadContent, Outlet, Scripts } from "@tanstack/react-router";
import { useLayoutEffect, useState } from "react";
import { AuthProvider } from "@/lib/auth/provider";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import { usePrefs } from "@/lib/store";
import appCss from "../styles.css?url";

const FONT =
  "https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,560;0,9..144,680;1,9..144,560&family=IBM+Plex+Mono:ital,wght@0,400;0,500;1,400&family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&family=Manrope:wght@400;500;600;700;800&display=swap";

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "ScoreHigh SAT Prep" },
      {
        name: "description",
        content:
          "Digital SAT Reading & Writing with Teacher Ziad Ahmed. Stop guessing between two almost-identical answers. Egypt, Saudi Arabia, and the UAE.",
      },
      { name: "theme-color", content: "#102833" },
    ],
    links: [
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: FONT },
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/__grok/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/__grok/icon-180.png" },
    ],
  }),
  component: RootShell,
});

function RootShell() {
  const lang = usePrefs((s) => s.lang);
  const theme = usePrefs((s) => s.theme);
  const [ready, setReady] = useState(false);

  useLayoutEffect(() => {
    void (async () => {
      await usePrefs.persist.rehydrate();
      const stored = localStorage.getItem("scorehigh-prefs");
      if (!stored) {
        const osDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
        usePrefs.setState({ theme: osDark ? "dark" : "light" });
      }
      setReady(true);
    })();
  }, []);

  return (
    <html
      lang={lang}
      dir={lang === "ar" ? "rtl" : "ltr"}
      className={ready ? theme : undefined}
      suppressHydrationWarning
    >
      <head>
        <HeadContent />
      </head>
      <body>
        <PreviewHostBridge />
        <AuthProvider>
          <Outlet />
        </AuthProvider>
        <Scripts />
      </body>
    </html>
  );
}
