import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { getQuestion, moduleOne, moduleTwo, trapLabel, type ChoiceId, type Question } from "@/lib/content";
import { usePrefs } from "@/lib/store";
import { useT } from "@/lib/use-t";
import { cn } from "@/lib/utils";

type Search = { q?: string; card?: string };

export const Route = createFileRoute("/practice")({
  validateSearch: (search: Record<string, unknown>): Search => ({
    q: typeof search.q === "string" ? search.q : undefined,
    card: typeof search.card === "string" ? search.card : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Practice · ScoreHigh" },
      { name: "description", content: "A Bluebook-style Reading & Writing module with elimination, a marker, and trap review." },
    ],
  }),
  component: PracticePage,
});

type Phase = "test" | "review" | "shift" | "done";

function PracticePage() {
  const search = Route.useSearch();
  if (search.q) return <Retry qid={search.q} card={search.card} />;
  return <ModuleRun />;
}

function ModuleRun() {
  const { t, lang } = useT();
  const recordAnswer = usePrefs((s) => s.recordAnswer);
  const finishModule = usePrefs((s) => s.finishModule);
  const addMistake = usePrefs((s) => s.addMistake);
  const [module, setModule] = useState<1 | 2>(1);
  const [index, setIndex] = useState(0);
  const [phase, setPhase] = useState<Phase>("test");
  const [answers, setAnswers] = useState<Record<string, ChoiceId | undefined>>({});
  const [struck, setStruck] = useState<Record<string, ChoiceId[]>>({});
  const [flags, setFlags] = useState<string[]>([]);
  const [marks, setMarks] = useState<Record<string, number[]>>({});
  const [marker, setMarker] = useState(false);
  const [eliminate, setEliminate] = useState(false);
  const [seconds, setSeconds] = useState(15 * 60);
  const [running, setRunning] = useState(false);
  const [confirm, setConfirm] = useState(false);
  const [committed, setCommitted] = useState<1 | 2 | 0>(0);

  const ids = module === 1 ? moduleOne : moduleTwo;
  const question = getQuestion(ids[index]);

  useEffect(() => {
    if (!running) return;
    const id = window.setInterval(() => setSeconds((s) => (s > 0 ? s - 1 : 0)), 1000);
    return () => window.clearInterval(id);
  }, [running]);

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (phase !== "test") return;
      const map: Record<string, ChoiceId> = { a: "A", b: "B", c: "C", d: "D", "1": "A", "2": "B", "3": "C", "4": "D" };
      const hit = map[e.key.toLowerCase()];
      if (hit) choose(hit);
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });

  function choose(id: ChoiceId) {
    if (eliminate) {
      setStruck((prev) => {
        const cur = prev[question.id] ?? [];
        const next = cur.includes(id) ? cur.filter((c) => c !== id) : [...cur, id];
        return { ...prev, [question.id]: next };
      });
      return;
    }
    setAnswers((prev) => ({ ...prev, [question.id]: id }));
  }

  function commit(which: 1 | 2) {
    if (committed >= which) return;
    const list = which === 1 ? moduleOne : moduleTwo;
    list.forEach((id) => {
      const q = getQuestion(id);
      const chosen = answers[id];
      const ok = chosen === q.correct;
      recordAnswer(q.domain, Boolean(chosen) && ok);
      if (chosen && !ok) {
        const trap = q.choices.find((c) => c.id === chosen)?.trap ?? "half-right";
        addMistake({ id: `live-${q.id}`, questionId: q.id, chosen, trap, domain: q.domain });
      }
    });
    finishModule();
    setCommitted(which);
  }

  function submit() {
    const missing = ids.some((id) => !answers[id]);
    if (missing && !confirm) {
      setConfirm(true);
      return;
    }
    setConfirm(false);
    commit(module);
    setPhase("review");
  }

  const clock = `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
  const correctCount = ids.filter((id) => answers[id] === getQuestion(id).correct).length;

  if (phase === "shift") {
    return (
      <main className="grid min-h-screen place-items-center bg-ink px-6 text-paper">
        <div>
          <p className="font-mono text-xs tracking-stamp text-signal uppercase">{t.practice.mod} 02</p>
          <h1 className="mt-3 font-display text-6xl">{t.practice.transition}</h1>
          <p className="mt-3 max-w-md text-paper/80">{t.practice.transitionBody}</p>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-paper text-ink">
      <header className="sticky top-0 z-20 flex flex-wrap items-center gap-2 border-b border-line bg-paper px-3 py-2">
        <Link to="/dashboard" className="font-display">
          ScoreHigh
        </Link>
        <span className="font-mono text-xs text-muted">
          {t.practice.mod} {module}
        </span>
        <span className="ms-auto font-mono text-lg tabular-nums" aria-live="polite">
          {clock}
        </span>
        <button type="button" className="min-h-10 rounded-full border border-line px-3 text-sm" onClick={() => setRunning((v) => !v)}>
          {running ? t.practice.pause : t.practice.start}
        </button>
      </header>

      {phase === "test" ? (
        <div className="mx-auto grid max-w-6xl gap-4 px-3 py-4 lg:grid-cols-2">
          <section className="border border-line bg-sheet p-4" aria-label={t.practice.passage}>
            <div className="mb-3 flex flex-wrap gap-2">
              <Tool on={marker} onClick={() => { setMarker((v) => !v); setEliminate(false); }}>
                {t.practice.marker}
              </Tool>
              <Tool on={eliminate} onClick={() => { setEliminate((v) => !v); setMarker(false); }}>
                {t.practice.eliminate}
              </Tool>
              <Tool
                on={flags.includes(question.id)}
                onClick={() =>
                  setFlags((prev) => (prev.includes(question.id) ? prev.filter((id) => id !== question.id) : [...prev, question.id]))
                }
              >
                {flags.includes(question.id) ? t.practice.flagged : t.practice.flag}
              </Tool>
            </div>
            {marker ? <p className="mb-2 text-xs text-mark">{t.practice.highlightHelp}</p> : null}
            <p className="font-display text-lg leading-relaxed" dir="ltr">
              {question.passage.split(" ").map((word, i) => {
                const on = (marks[question.id] ?? []).includes(i);
                return (
                  <span key={`${question.id}-${i}`}>
                    <button
                      type="button"
                      className={cn("rounded px-0.5", on && "bg-signal text-ink", !marker && "cursor-text")}
                      onClick={() => {
                        if (!marker) return;
                        setMarks((prev) => {
                          const cur = prev[question.id] ?? [];
                          const next = cur.includes(i) ? cur.filter((n) => n !== i) : [...cur, i];
                          return { ...prev, [question.id]: next };
                        });
                      }}
                    >
                      {word}
                    </button>{" "}
                  </span>
                );
              })}
            </p>
          </section>
          <section aria-label={t.practice.question}>
            <p className="font-mono text-xs text-muted">
              {index + 1} / {ids.length}
            </p>
            <h1 className="mt-2 text-lg font-semibold" dir="ltr">
              {question.stem}
            </h1>
            <div role="radiogroup" aria-label={question.stem} className="mt-4 grid gap-2">
              {question.choices.map((choice) => {
                const selected = answers[question.id] === choice.id;
                const gone = (struck[question.id] ?? []).includes(choice.id);
                return (
                  <button
                    key={choice.id}
                    type="button"
                    role="radio"
                    aria-checked={selected}
                    dir="ltr"
                    onClick={() => choose(choice.id)}
                    className={cn(
                      "flex min-h-12 items-start gap-3 border px-3 py-3 text-start",
                      selected ? "border-ink bg-sheet" : "border-line",
                      gone && "text-muted line-through",
                    )}
                  >
                    <span className="font-mono text-xs">{choice.id}</span>
                    <span>{choice.en}</span>
                  </button>
                );
              })}
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              <button type="button" className="min-h-11 rounded-full border border-line px-4" disabled={index === 0} onClick={() => setIndex((n) => n - 1)}>
                {t.programs.back}
              </button>
              {index < ids.length - 1 ? (
                <button type="button" className="min-h-11 rounded-full bg-ink px-4 font-semibold text-paper" onClick={() => setIndex((n) => n + 1)}>
                  {t.programs.next}
                </button>
              ) : (
                <button type="button" className="min-h-11 rounded-full bg-signal px-4 font-semibold text-ink" onClick={submit}>
                  {t.practice.submit}
                </button>
              )}
            </div>
            {confirm ? <p className="mt-3 text-sm text-trap">{t.practice.need}</p> : null}
            <div className="mt-5 flex flex-wrap gap-2" aria-label={t.practice.nav}>
              {ids.map((id, i) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => setIndex(i)}
                  className={cn(
                    "grid size-11 place-items-center border font-mono text-sm",
                    i === index && "border-ink",
                    answers[id] && "bg-signal text-ink",
                    flags.includes(id) && "border-trap",
                  )}
                >
                  {i + 1}
                </button>
              ))}
            </div>
          </section>
        </div>
      ) : null}

      {phase === "review" || phase === "done" ? (
        <section className="mx-auto max-w-3xl px-4 py-8">
          <p className="font-mono text-xs tracking-stamp text-mark uppercase">{t.practice.review}</p>
          <h1 className="mt-2 font-display text-5xl leading-none">
            {correctCount}/{ids.length}
          </h1>
          <p className="text-sm text-muted">{t.practice.notOfficial}</p>
          <ol className="mt-6 space-y-6">
            {ids.map((id) => (
              <ReviewItem key={id} question={getQuestion(id)} chosen={answers[id]} lang={lang} your={t.practice.your} />
            ))}
          </ol>
          <div className="mt-8 flex flex-wrap gap-3">
            {module === 1 && phase === "review" ? (
              <button
                type="button"
                className="min-h-12 rounded-full bg-ink px-5 font-semibold text-paper"
                onClick={() => {
                  setPhase("shift");
                  window.setTimeout(() => {
                    setModule(2);
                    setIndex(0);
                    setPhase("test");
                    setConfirm(false);
                  }, 1400);
                }}
              >
                {t.practice.nextMod}
              </button>
            ) : (
              <Link to="/dashboard" className="inline-flex min-h-12 items-center rounded-full bg-signal px-5 font-semibold text-ink">
                {t.practice.dash}
              </Link>
            )}
          </div>
        </section>
      ) : null}
    </main>
  );
}

function Retry({ qid, card }: { qid: string; card?: string }) {
  const { t, lang } = useT();
  const retryCard = usePrefs((s) => s.retryCard);
  const question = useMemo(() => {
    try {
      return getQuestion(qid);
    } catch {
      return null;
    }
  }, [qid]);
  const [picked, setPicked] = useState<ChoiceId | null>(null);
  const [saved, setSaved] = useState(false);
  if (!question) {
    return (
      <main className="grid min-h-screen place-items-center bg-paper px-6 text-ink">
        <Link to="/error-vault">{t.errors.title}</Link>
      </main>
    );
  }
  const why = picked ? question.why[picked] : null;
  return (
    <main className="mx-auto min-h-screen max-w-2xl bg-paper px-4 py-8 text-ink">
      <Link to="/error-vault" className="text-sm text-muted">
        {t.errors.title}
      </Link>
      <h1 className="mt-4 font-display text-4xl" dir="ltr">
        {question.stem}
      </h1>
      <p className="mt-3 font-display text-lg" dir="ltr">
        {question.passage}
      </p>
      <div className="mt-4 grid gap-2">
        {question.choices.map((choice) => (
          <button
            key={choice.id}
            type="button"
            dir="ltr"
            onClick={() => {
              setPicked(choice.id);
              if (card && !saved) {
                retryCard(card, choice.id === question.correct);
                setSaved(true);
              }
            }}
            className={cn(
              "min-h-12 border px-3 text-start",
              picked === choice.id && choice.id === question.correct && "border-mark",
              picked === choice.id && choice.id !== question.correct && "border-trap",
            )}
          >
            {choice.id}. {choice.en}
          </button>
        ))}
      </div>
      {why ? <p className="mt-4 text-sm">{lang === "ar" ? why.ar : why.en}</p> : null}
    </main>
  );
}

function ReviewItem({
  question,
  chosen,
  lang,
  your,
}: {
  question: Question;
  chosen?: ChoiceId;
  lang: "en" | "ar";
  your: string;
}) {
  const ok = chosen === question.correct;
  const note = chosen ? question.why[chosen] : question.why[question.correct];
  const trap = question.choices.find((c) => c.id === chosen)?.trap;
  return (
    <li className="border-s-4 border-line ps-4">
      <p className="font-semibold" dir="ltr">
        {question.stem}
      </p>
      <p className="mt-1 text-sm">
        {your}: {chosen ?? "—"} {ok ? "· OK" : trap ? `· ${lang === "ar" ? trapLabel[trap].ar : trapLabel[trap].en}` : ""}
      </p>
      <p className="mt-2 text-sm text-muted">{lang === "ar" ? note.ar : note.en}</p>
    </li>
  );
}

function Tool({ on, onClick, children }: { on: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      type="button"
      aria-pressed={on}
      onClick={onClick}
      className={cn("min-h-10 rounded-full border px-3 text-sm", on ? "border-ink bg-signal text-ink" : "border-line")}
    >
      {children}
    </button>
  );
}
