import { createFileRoute } from "@tanstack/react-router";
import { FinalCta, Pillars } from "@/routes/index";
import { SiteFrame } from "@/components/site/chrome";
import { useT } from "@/lib/use-t";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "Teacher Ziad Ahmed · ScoreHigh" },
      {
        name: "description",
        content:
          "Top 1% SAT, 36/36 ACT English, multiple 1500+ PSATs. Ziad Ahmed trains Digital SAT Reading & Writing.",
      },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  const { t } = useT();
  return (
    <SiteFrame>
      <section className="mx-auto grid max-w-6xl gap-10 px-4 py-14 lg:grid-cols-[1.1fr_0.9fr]">
        <div>
          <p className="font-mono text-xs tracking-stamp text-mark uppercase">{t.about.eyebrow}</p>
          <h1 className="mt-3 font-display text-5xl leading-none sm:text-6xl">{t.about.title}</h1>
          <p className="mt-6 text-lg text-muted">{t.about.lede}</p>
          <p className="mt-4 text-muted">{t.about.noBio}</p>
          <blockquote className="mt-8 font-display text-3xl italic leading-snug">{t.about.quote}</blockquote>
        </div>
        <div className="border border-line bg-sheet p-6">
          <p className="font-display text-7xl leading-none">Z.A.</p>
          <ul className="mt-6 space-y-3 font-mono text-sm">
            <li className="border-b border-line pb-2">Top 1% SAT</li>
            <li className="border-b border-line pb-2">36/36 ACT English</li>
            <li className="border-b border-line pb-2">1500+ PSAT · multiple</li>
            <li>23K+ followers</li>
          </ul>
          <p className="mt-6 text-sm text-muted">{t.about.pillars}</p>
        </div>
      </section>
      <section className="mx-auto max-w-6xl px-4 pb-16">
        <Pillars />
      </section>
      <FinalCta />
    </SiteFrame>
  );
}
