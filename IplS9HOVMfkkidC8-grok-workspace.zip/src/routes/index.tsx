import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { QuestionCard } from "@/components/exam/question-card";
import { FaqList } from "@/components/marketing/faq-list";
import { LabPanel } from "@/components/marketing/lab-panel";
import { Results } from "@/components/marketing/results";
import { SiteFrame, WaButton } from "@/components/site/chrome";
import { heroQuestion, pillars } from "@/lib/content";
import { useT } from "@/lib/use-t";
import { cn } from "@/lib/utils";

const LD = {
  "@context": "https://schema.org",
  "@type": "EducationalOrganization",
  name: "ScoreHigh SAT Prep",
  description:
    "Digital SAT Reading & Writing studio led by Teacher Ziad Ahmed for students in Egypt, Saudi Arabia, and the UAE.",
  founder: { "@type": "Person", name: "Ziad Ahmed" },
  areaServed: ["EG", "SA", "AE"],
  telephone: "+201599906731",
  knowsLanguage: ["en", "ar"],
};

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ScoreHigh SAT Prep · Stop guessing between two answers" },
      {
        name: "description",
        content:
          "Teacher Ziad Ahmed trains Digital SAT Reading & Writing. Trap lab, bilingual passage decoder, and a weekly plan. Enroll on WhatsApp.",
      },
    ],
  }),
  component: Home,
});

function Home() {
  const { t, lang } = useT();
  const [picked, setPicked] = useState<string | null>(null);
  const message =
    lang === "ar"
      ? "مرحبًا، أريد التسجيل في ScoreHigh. هذه درجتي الحالية في القراءة والكتابة: "
      : "Hello, I want to enroll in ScoreHigh. My current Reading & Writing score is ";

  return (
    <SiteFrame>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(LD) }} />
      <section className="mx-auto flex max-w-6xl flex-col gap-8 px-4 py-8 lg:grid lg:grid-cols-2 lg:items-start lg:gap-12 lg:py-14">
        <div className="order-1 lg:col-start-1 lg:row-start-1">
          <p className="font-mono text-xs tracking-stamp text-mark uppercase">{t.hero.kicker}</p>
          <h1 className="mt-3 font-display text-4xl leading-none sm:text-6xl">
            {t.hero.line1} <span className="marker-underline">{t.hero.emphasis}</span>
            {t.hero.line2 ? ` ${t.hero.line2}` : ""}
          </h1>
        </div>
        <div className="order-2 lg:col-start-2 lg:row-start-1 lg:row-span-2">
          <p className="mb-3 text-sm text-muted">{t.hero.instruct}</p>
          <QuestionCard question={heroQuestion} selected={picked} onSelect={setPicked} kicker={t.hero.sheet} />
        </div>
        <div className="order-3 lg:col-start-1 lg:row-start-2">
          <p className="max-w-xl text-lg text-muted">{t.hero.lede}</p>
          <div className="mt-6 flex flex-wrap gap-3">
            <WaButton message={message}>{t.hero.primary}</WaButton>
            <Link
              to="/lab"
              className="inline-flex min-h-12 items-center rounded-full border border-line px-5 text-sm font-semibold"
            >
              {t.hero.secondary}
            </Link>
          </div>
          <p className="mt-6 max-w-md font-display text-2xl italic leading-snug">{t.hero.philosophy}</p>
        </div>
      </section>

      <Trust />

      <LabPanel />
      <Results />

      <section className="mx-auto grid max-w-6xl gap-10 px-4 py-16 lg:grid-cols-[0.8fr_1.2fr] sm:py-24">
        <div>
          <p className="font-mono text-xs tracking-stamp text-mark uppercase">{t.about.eyebrow}</p>
          <h2 className="mt-3 font-display text-4xl leading-none sm:text-5xl">{t.about.title}</h2>
          <blockquote className="mt-6 border-s-4 border-signal ps-4 font-display text-2xl italic">{t.about.quote}</blockquote>
          <Link to="/about" className="mt-6 inline-flex min-h-11 items-center text-sm font-semibold underline-offset-4 hover:underline">
            {t.nav.about}
          </Link>
        </div>
        <Pillars />
      </section>

      <section className="border-t border-line">
        <div className="mx-auto max-w-6xl px-4 py-16 sm:py-20">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <h2 className="font-display text-4xl leading-none sm:text-5xl">{t.programs.title}</h2>
            <Link to="/programs" className="text-sm font-semibold underline-offset-4 hover:underline">
              {t.nav.programs}
            </Link>
          </div>
          <ProgramStrip />
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16">
        <h2 className="font-display text-4xl leading-none">{t.faq.title}</h2>
        <div className="mt-8">
          <FaqList limit={4} />
        </div>
        <Link to="/faq" className="mt-6 inline-flex min-h-11 items-center text-sm font-semibold underline-offset-4 hover:underline">
          {t.faq.more}
        </Link>
      </section>

      <FinalCta />
    </SiteFrame>
  );
}

function Trust() {
  const { t } = useT();
  const items = [
    { k: t.trust.topK, v: t.trust.topV },
    { k: t.trust.actK, v: `${t.trust.actV}${t.trust.actS}` },
    { k: t.trust.psatK, v: `${t.trust.psatV}${t.trust.psatS}` },
    { k: t.trust.folK, v: `${t.trust.folV}${t.trust.folS}` },
  ];
  return (
    <section className="border-y border-line" aria-label={t.trust.note}>
      <div className="mx-auto grid max-w-6xl gap-6 px-4 py-8 sm:grid-cols-4">
        {items.map((item) => (
          <p key={item.k} className="flex items-baseline justify-between gap-3 border-s border-line ps-4 sm:block">
            <span className="block font-mono text-xs tracking-stamp text-muted uppercase">{item.k}</span>
            <span className="font-display text-4xl leading-none tabular-nums">{item.v}</span>
          </p>
        ))}
      </div>
      <p className="mx-auto max-w-6xl px-4 pb-6 text-xs text-muted">{t.trust.note}</p>
    </section>
  );
}

export function Pillars() {
  const { t, lang } = useT();
  return (
    <ol className="relative space-y-8 border-s border-line ps-6">
      {pillars.map((pillar, index) => (
        <li key={pillar.id}>
          <span
            className={cn(
              "font-mono text-xs tracking-stamp",
              index === 2 ? "inline-block -rotate-6 border border-trap px-1.5 py-0.5 text-trap" : "text-mark",
              index === 1 && "inline-grid size-8 place-items-center rounded-full border border-mark",
            )}
          >
            0{index + 1}
          </span>
          <h3 className="mt-2 font-display text-3xl">{lang === "ar" ? pillar.ar : pillar.en}</h3>
          <p className="mt-2 max-w-xl text-muted">{lang === "ar" ? pillar.bodyAr : pillar.bodyEn}</p>
        </li>
      ))}
      <span className="sr-only">{t.about.pillars}</span>
    </ol>
  );
}

export function ProgramStrip() {
  const { t, lang } = useT();
  const message =
    lang === "ar" ? "مرحبًا، أريد تفاصيل برنامج ScoreHigh والسعر." : "Hello, I want the ScoreHigh program details and the price.";
  return (
    <div className="mt-8 grid gap-4 lg:grid-cols-12">
      <article className="border border-ink bg-ink p-6 text-paper lg:col-span-7">
        <p className="font-mono text-xs tracking-stamp text-signal uppercase">{t.programs.popular}</p>
        <h3 className="mt-3 font-display text-4xl text-paper">
          {lang === "ar" ? "دورة المجموعة المباشرة" : "Live Group Course"}
        </h3>
        <p className="mt-4 font-display text-5xl text-signal">{t.programs.price}</p>
        <p className="mt-1 text-sm text-paper/80">{t.programs.priceNote}</p>
        <WaButton message={message} className="mt-6">
          {t.programs.ask}
        </WaButton>
      </article>
      <article className="border border-dashed border-trap bg-sheet p-6 lg:col-span-5">
        <p className="font-mono text-xs tracking-stamp text-trap uppercase">{t.programs.spots}</p>
        <h3 className="mt-3 font-display text-3xl">{lang === "ar" ? "تدريب فردي نخبة" : "Elite 1-on-1"}</h3>
        <p className="mt-4 font-display text-4xl">{t.programs.price}</p>
        <Link to="/programs" className="mt-6 inline-flex min-h-11 items-center text-sm font-semibold underline-offset-4 hover:underline">
          {t.nav.programs}
        </Link>
      </article>
    </div>
  );
}

export function FinalCta() {
  const { t, lang } = useT();
  const message =
    lang === "ar"
      ? "مرحبًا أستاذ زياد، هذه درجتي وموعد اختباري: "
      : "Hello Teacher Ziad, here is my score and test date: ";
  return (
    <section className="border-t border-line">
      <div className="mx-auto max-w-6xl px-4 py-16 sm:py-24">
        <h2 className="max-w-3xl font-display text-5xl leading-none sm:text-7xl">{t.cta.title}</h2>
        <p className="mt-4 max-w-xl text-muted">{t.cta.lede}</p>
        <WaButton message={message} className="mt-8">
          {t.cta.button}
        </WaButton>
      </div>
    </section>
  );
}
