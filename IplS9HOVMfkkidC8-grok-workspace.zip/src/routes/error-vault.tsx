import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { StudioShell } from "@/components/studio/shell";
import { getQuestion, sampleMistakes, trapLabel, type TrapKind } from "@/lib/content";
import { usePrefs } from "@/lib/store";
import { todayKey } from "@/lib/utils";
import { useT } from "@/lib/use-t";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/error-vault")({
  head: () => ({
    meta: [
      { title: "Error vault · ScoreHigh" },
      { name: "description", content: "Mistakes tagged by trap type, with retry and spaced review." },
    ],
  }),
  component: VaultPage,
});

const filters: (TrapKind | "all")[] = ["all", "too-extreme", "half-right", "out-of-scope", "wrong-sense", "opposite", "agreement"];

function VaultPage() {
  const { t, lang } = useT();
  const vault = usePrefs((s) => s.vault);
  const [filter, setFilter] = useState<(typeof filters)[number]>("all");
  const today = todayKey();

  const mine = vault.filter((card) => filter === "all" || card.trap === filter);
  const samples = sampleMistakes.filter((card) => filter === "all" || card.trap === filter);

  return (
    <StudioShell>
      <p className="font-mono text-xs tracking-stamp text-mark uppercase">{t.errors.title}</p>
      <h1 className="mt-2 font-display text-5xl leading-none">{t.errors.title}</h1>
      <p className="mt-3 max-w-xl text-muted">{t.errors.lede}</p>
      <div className="mt-5 flex gap-2 overflow-x-auto" role="group" aria-label={t.errors.filter}>
        {filters.map((item) => (
          <button
            key={item}
            type="button"
            onClick={() => setFilter(item)}
            className={cn(
              "min-h-10 shrink-0 rounded-full border px-3 text-sm",
              filter === item ? "border-ink bg-ink text-paper" : "border-line",
            )}
          >
            {item === "all" ? t.errors.all : lang === "ar" ? trapLabel[item].ar : trapLabel[item].en}
          </button>
        ))}
      </div>

      <h2 className="mt-8 font-display text-2xl">{t.errors.yours}</h2>
      {mine.length === 0 ? <p className="mt-2 text-sm text-muted">{t.errors.empty}</p> : null}
      <ul className="mt-3 grid gap-3">
        {mine.map((card) => {
          const q = getQuestion(card.questionId);
          const due = !card.resolved && card.due <= today;
          return (
            <li key={card.id} className="border border-line bg-sheet p-4">
              <div className="flex flex-wrap items-center gap-2 text-xs">
                <span className="border border-trap px-1.5 py-0.5 font-mono tracking-stamp text-trap uppercase">
                  {lang === "ar" ? trapLabel[card.trap].ar : trapLabel[card.trap].en}
                </span>
                <span className="font-mono text-muted">{due ? t.errors.due : card.resolved ? t.errors.done : t.errors.later}</span>
              </div>
              <p className="mt-2" dir="ltr">
                {q.stem}
              </p>
              <Link
                to="/practice"
                search={{ q: card.questionId, card: card.id }}
                className="mt-3 inline-flex min-h-10 items-center text-sm font-semibold"
              >
                {t.errors.retry}
              </Link>
            </li>
          );
        })}
      </ul>

      <h2 className="mt-10 font-display text-2xl">{t.errors.samples}</h2>
      <p className="mt-1 text-sm text-muted">{t.errors.samplesNote}</p>
      <ul className="mt-3 grid gap-3 sm:grid-cols-2">
        {samples.map((card) => {
          const q = getQuestion(card.questionId);
          return (
            <li key={card.id} className="border border-dashed border-line p-4">
              <p className="font-mono text-xs text-trap">
                {lang === "ar" ? trapLabel[card.trap].ar : trapLabel[card.trap].en}
              </p>
              <p className="mt-2 text-sm" dir="ltr">
                {q.stem}
              </p>
              <p className="mt-2 font-mono text-xs text-mark">{t.errors.due}</p>
              <Link to="/practice" search={{ q: card.questionId }} className="mt-3 inline-flex min-h-10 items-center text-sm font-semibold">
                {t.errors.retry}
              </Link>
            </li>
          );
        })}
      </ul>
    </StudioShell>
  );
}
