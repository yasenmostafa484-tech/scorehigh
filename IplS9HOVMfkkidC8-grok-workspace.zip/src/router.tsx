import { createRouter, Link } from "@tanstack/react-router";
import { AppErrorComponent } from "@/lib/error-component";
import { previewPathRewrite } from "@/lib/preview-path-prefix";
import { routeTree } from "./routeTree.gen";

function NotFound() {
  return (
    <main className="grid min-h-screen place-items-center bg-paper px-6 text-ink">
      <div className="max-w-lg">
        <p className="font-mono text-xs tracking-stamp text-trap uppercase">404</p>
        <h1 className="mt-3 font-display text-5xl leading-none">This page isn’t on the answer sheet.</h1>
        <p className="mt-4 text-muted">The link may be old. The question, fortunately, is not.</p>
        <Link
          to="/"
          className="mt-8 inline-flex min-h-11 items-center rounded-full bg-signal px-5 font-semibold text-ink"
        >
          Back to ScoreHigh
        </Link>
      </div>
    </main>
  );
}

export function getRouter() {
  return createRouter({
    routeTree,
    rewrite: previewPathRewrite(),
    defaultErrorComponent: AppErrorComponent,
    defaultNotFoundComponent: NotFound,
  });
}
