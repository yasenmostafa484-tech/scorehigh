# ScoreHigh SAT Prep

Public site and student demo for Teacher Ziad Ahmed’s Digital SAT Reading & Writing studio.

## Run

```bash
npm run dev
```

The dev server listens on port 8080.

## Check

```bash
npm run typecheck
npm run build
```

## Deploy

The app is a TanStack Start project and deploys on Vercel with the existing `vercel.json`. No environment variables are required for the demo. Lead capture (`POST /api/leads`) validates input and returns an id; it does not store personal data.

## Notes

- Enrollment CTAs open WhatsApp `+20 159 990 6731`.
- English / Arabic toggle sets `dir` and uses IBM Plex Sans Arabic.
- Prices are the placeholder `[PRICE]`.
- Instagram uses `@scorehightutoring`, the same handle as the confirmed TikTok. Change it in `src/lib/whatsapp.ts` if the account differs.
- Student progress in the demo stays in this browser (`localStorage`).
