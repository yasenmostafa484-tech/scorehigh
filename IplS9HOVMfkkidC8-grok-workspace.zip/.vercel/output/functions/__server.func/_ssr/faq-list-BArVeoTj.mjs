import { a as AccordionTrigger, g as require_jsx_runtime, i as AccordionItem, n as AccordionContent, r as AccordionHeader, t as Accordion } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { l as useT } from "./chrome-ixJ0YwnM.mjs";
import { c as faq } from "./router-DNg9Mb-U.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/faq-list-BArVeoTj.js
var import_jsx_runtime = require_jsx_runtime();
function FaqList({ limit }) {
	const { lang } = useT();
	const items = typeof limit === "number" ? faq.slice(0, limit) : faq;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Accordion, {
		type: "single",
		collapsible: true,
		className: "divide-y divide-line border-y border-line",
		children: items.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionItem, {
			value: item.qEn,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionTrigger, {
				className: "flex w-full items-center gap-4 py-4 text-start",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono text-xs text-mark",
					children: String(index + 1).padStart(2, "0")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-xl sm:text-2xl",
					children: lang === "ar" ? item.qAr : item.qEn
				})]
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionContent, {
				className: "acc-panel",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pb-5 ps-10 text-muted",
					children: lang === "ar" ? item.aAr : item.aEn
				}) })
			})]
		}, item.qEn))
	});
}
//#endregion
export { FaqList as t };
