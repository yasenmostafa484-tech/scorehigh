import { i as __toESM } from "../_runtime.mjs";
import { _ as require_react, g as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { c as usePrefs, i as cn, l as useT } from "./chrome-ixJ0YwnM.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as moduleOne, f as moduleTwo, l as getQuestion, n as Route$8, v as trapLabel } from "./router-DNg9Mb-U.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/practice-gV0IMv1O.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PracticePage() {
	const search = Route$8.useSearch();
	if (search.q) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Retry, {
		qid: search.q,
		card: search.card
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModuleRun, {});
}
function ModuleRun() {
	const { t, lang } = useT();
	const recordAnswer = usePrefs((s) => s.recordAnswer);
	const finishModule = usePrefs((s) => s.finishModule);
	const addMistake = usePrefs((s) => s.addMistake);
	const [module, setModule] = (0, import_react.useState)(1);
	const [index, setIndex] = (0, import_react.useState)(0);
	const [phase, setPhase] = (0, import_react.useState)("test");
	const [answers, setAnswers] = (0, import_react.useState)({});
	const [struck, setStruck] = (0, import_react.useState)({});
	const [flags, setFlags] = (0, import_react.useState)([]);
	const [marks, setMarks] = (0, import_react.useState)({});
	const [marker, setMarker] = (0, import_react.useState)(false);
	const [eliminate, setEliminate] = (0, import_react.useState)(false);
	const [seconds, setSeconds] = (0, import_react.useState)(900);
	const [running, setRunning] = (0, import_react.useState)(false);
	const [confirm, setConfirm] = (0, import_react.useState)(false);
	const [committed, setCommitted] = (0, import_react.useState)(0);
	const ids = module === 1 ? moduleOne : moduleTwo;
	const question = getQuestion(ids[index]);
	(0, import_react.useEffect)(() => {
		if (!running) return;
		const id = window.setInterval(() => setSeconds((s) => s > 0 ? s - 1 : 0), 1e3);
		return () => window.clearInterval(id);
	}, [running]);
	(0, import_react.useEffect)(() => {
		function onKey(e) {
			if (phase !== "test") return;
			const hit = {
				a: "A",
				b: "B",
				c: "C",
				d: "D",
				"1": "A",
				"2": "B",
				"3": "C",
				"4": "D"
			}[e.key.toLowerCase()];
			if (hit) choose(hit);
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	});
	function choose(id) {
		if (eliminate) {
			setStruck((prev) => {
				const cur = prev[question.id] ?? [];
				const next = cur.includes(id) ? cur.filter((c) => c !== id) : [...cur, id];
				return {
					...prev,
					[question.id]: next
				};
			});
			return;
		}
		setAnswers((prev) => ({
			...prev,
			[question.id]: id
		}));
	}
	function commit(which) {
		if (committed >= which) return;
		(which === 1 ? moduleOne : moduleTwo).forEach((id) => {
			const q = getQuestion(id);
			const chosen = answers[id];
			const ok = chosen === q.correct;
			recordAnswer(q.domain, Boolean(chosen) && ok);
			if (chosen && !ok) {
				const trap = q.choices.find((c) => c.id === chosen)?.trap ?? "half-right";
				addMistake({
					id: `live-${q.id}`,
					questionId: q.id,
					chosen,
					trap,
					domain: q.domain
				});
			}
		});
		finishModule();
		setCommitted(which);
	}
	function submit() {
		if (ids.some((id) => !answers[id]) && !confirm) {
			setConfirm(true);
			return;
		}
		setConfirm(false);
		commit(module);
		setPhase("review");
	}
	const clock = `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
	const correctCount = ids.filter((id) => answers[id] === getQuestion(id).correct).length;
	if (phase === "shift") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-screen place-items-center bg-ink px-6 text-paper",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "font-mono text-xs tracking-stamp text-signal uppercase",
				children: [t.practice.mod, " 02"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-6xl",
				children: t.practice.transition
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-md text-paper/80",
				children: t.practice.transitionBody
			})
		] })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-screen bg-paper text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-20 flex flex-wrap items-center gap-2 border-b border-line bg-paper px-3 py-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/dashboard",
						className: "font-display",
						children: "ScoreHigh"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-mono text-xs text-muted",
						children: [
							t.practice.mod,
							" ",
							module
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ms-auto font-mono text-lg tabular-nums",
						"aria-live": "polite",
						children: clock
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-10 rounded-full border border-line px-3 text-sm",
						onClick: () => setRunning((v) => !v),
						children: running ? t.practice.pause : t.practice.start
					})
				]
			}),
			phase === "test" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-6xl gap-4 px-3 py-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "border border-line bg-sheet p-4",
					"aria-label": t.practice.passage,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-3 flex flex-wrap gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tool, {
									on: marker,
									onClick: () => {
										setMarker((v) => !v);
										setEliminate(false);
									},
									children: t.practice.marker
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tool, {
									on: eliminate,
									onClick: () => {
										setEliminate((v) => !v);
										setMarker(false);
									},
									children: t.practice.eliminate
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tool, {
									on: flags.includes(question.id),
									onClick: () => setFlags((prev) => prev.includes(question.id) ? prev.filter((id) => id !== question.id) : [...prev, question.id]),
									children: flags.includes(question.id) ? t.practice.flagged : t.practice.flag
								})
							]
						}),
						marker ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-2 text-xs text-mark",
							children: t.practice.highlightHelp
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-lg leading-relaxed",
							dir: "ltr",
							children: question.passage.split(" ").map((word, i) => {
								const on = (marks[question.id] ?? []).includes(i);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: cn("rounded px-0.5", on && "bg-signal text-ink", !marker && "cursor-text"),
									onClick: () => {
										if (!marker) return;
										setMarks((prev) => {
											const cur = prev[question.id] ?? [];
											const next = cur.includes(i) ? cur.filter((n) => n !== i) : [...cur, i];
											return {
												...prev,
												[question.id]: next
											};
										});
									},
									children: word
								}), " "] }, `${question.id}-${i}`);
							})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					"aria-label": t.practice.question,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-mono text-xs text-muted",
							children: [
								index + 1,
								" / ",
								ids.length
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-2 text-lg font-semibold",
							dir: "ltr",
							children: question.stem
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							role: "radiogroup",
							"aria-label": question.stem,
							className: "mt-4 grid gap-2",
							children: question.choices.map((choice) => {
								const selected = answers[question.id] === choice.id;
								const gone = (struck[question.id] ?? []).includes(choice.id);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									role: "radio",
									"aria-checked": selected,
									dir: "ltr",
									onClick: () => choose(choice.id),
									className: cn("flex min-h-12 items-start gap-3 border px-3 py-3 text-start", selected ? "border-ink bg-sheet" : "border-line", gone && "text-muted line-through"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-xs",
										children: choice.id
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: choice.en })]
								}, choice.id);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "min-h-11 rounded-full border border-line px-4",
								disabled: index === 0,
								onClick: () => setIndex((n) => n - 1),
								children: t.programs.back
							}), index < ids.length - 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "min-h-11 rounded-full bg-ink px-4 font-semibold text-paper",
								onClick: () => setIndex((n) => n + 1),
								children: t.programs.next
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "min-h-11 rounded-full bg-signal px-4 font-semibold text-ink",
								onClick: submit,
								children: t.practice.submit
							})]
						}),
						confirm ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-trap",
							children: t.practice.need
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-5 flex flex-wrap gap-2",
							"aria-label": t.practice.nav,
							children: ids.map((id, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setIndex(i),
								className: cn("grid size-11 place-items-center border font-mono text-sm", i === index && "border-ink", answers[id] && "bg-signal text-ink", flags.includes(id) && "border-trap"),
								children: i + 1
							}, id))
						})
					]
				})]
			}) : null,
			phase === "review" || phase === "done" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto max-w-3xl px-4 py-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs tracking-stamp text-mark uppercase",
						children: t.practice.review
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "mt-2 font-display text-5xl leading-none",
						children: [
							correctCount,
							"/",
							ids.length
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: t.practice.notOfficial
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "mt-6 space-y-6",
						children: ids.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewItem, {
							question: getQuestion(id),
							chosen: answers[id],
							lang,
							your: t.practice.your
						}, id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 flex flex-wrap gap-3",
						children: module === 1 && phase === "review" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "min-h-12 rounded-full bg-ink px-5 font-semibold text-paper",
							onClick: () => {
								setPhase("shift");
								window.setTimeout(() => {
									setModule(2);
									setIndex(0);
									setPhase("test");
									setConfirm(false);
								}, 1400);
							},
							children: t.practice.nextMod
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/dashboard",
							className: "inline-flex min-h-12 items-center rounded-full bg-signal px-5 font-semibold text-ink",
							children: t.practice.dash
						})
					})
				]
			}) : null
		]
	});
}
function Retry({ qid, card }) {
	const { t, lang } = useT();
	const retryCard = usePrefs((s) => s.retryCard);
	const question = (0, import_react.useMemo)(() => {
		try {
			return getQuestion(qid);
		} catch {
			return null;
		}
	}, [qid]);
	const [picked, setPicked] = (0, import_react.useState)(null);
	const [saved, setSaved] = (0, import_react.useState)(false);
	if (!question) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-screen place-items-center bg-paper px-6 text-ink",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/error-vault",
			children: t.errors.title
		})
	});
	const why = picked ? question.why[picked] : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto min-h-screen max-w-2xl bg-paper px-4 py-8 text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/error-vault",
				className: "text-sm text-muted",
				children: t.errors.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-4 font-display text-4xl",
				dir: "ltr",
				children: question.stem
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 font-display text-lg",
				dir: "ltr",
				children: question.passage
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 grid gap-2",
				children: question.choices.map((choice) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					dir: "ltr",
					onClick: () => {
						setPicked(choice.id);
						if (card && !saved) {
							retryCard(card, choice.id === question.correct);
							setSaved(true);
						}
					},
					className: cn("min-h-12 border px-3 text-start", picked === choice.id && choice.id === question.correct && "border-mark", picked === choice.id && choice.id !== question.correct && "border-trap"),
					children: [
						choice.id,
						". ",
						choice.en
					]
				}, choice.id))
			}),
			why ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm",
				children: lang === "ar" ? why.ar : why.en
			}) : null
		]
	});
}
function ReviewItem({ question, chosen, lang, your }) {
	const ok = chosen === question.correct;
	const note = chosen ? question.why[chosen] : question.why[question.correct];
	const trap = question.choices.find((c) => c.id === chosen)?.trap;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "border-s-4 border-line ps-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-semibold",
				dir: "ltr",
				children: question.stem
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm",
				children: [
					your,
					": ",
					chosen ?? "—",
					" ",
					ok ? "· OK" : trap ? `· ${lang === "ar" ? trapLabel[trap].ar : trapLabel[trap].en}` : ""
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: lang === "ar" ? note.ar : note.en
			})
		]
	});
}
function Tool({ on, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": on,
		onClick,
		className: cn("min-h-10 rounded-full border px-3 text-sm", on ? "border-ink bg-signal text-ink" : "border-line"),
		children
	});
}
//#endregion
export { PracticePage as component };
