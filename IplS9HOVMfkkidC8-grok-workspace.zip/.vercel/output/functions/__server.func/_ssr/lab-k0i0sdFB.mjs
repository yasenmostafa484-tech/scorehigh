import { g as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { n as SiteFrame } from "./chrome-ixJ0YwnM.mjs";
import { r as FinalCta } from "./router-DNg9Mb-U.mjs";
import { t as LabPanel } from "./lab-panel-D4trqfbv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/lab-k0i0sdFB.js
var import_jsx_runtime = require_jsx_runtime();
function LabPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteFrame, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LabPanel, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FinalCta, {})] });
}
//#endregion
export { LabPage as component };
