import { i as __toESM } from "../_runtime.mjs";
import { _ as require_react, g as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { c as usePrefs, i as cn, l as useT } from "./chrome-ixJ0YwnM.mjs";
import { b as vocab } from "./router-DNg9Mb-U.mjs";
import { t as StudioShell } from "./shell-B05Xmgs2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/vocab-Db29IebR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function VocabPage() {
	const { t, lang } = useT();
	const xp = usePrefs((s) => s.xp);
	const addVocab = usePrefs((s) => s.addVocab);
	const [mode, setMode] = (0, import_react.useState)("cards");
	const [i, setI] = (0, import_react.useState)(0);
	const [flipped, setFlipped] = (0, import_react.useState)(false);
	const [streak, setStreak] = (0, import_react.useState)(0);
	const [picked, setPicked] = (0, import_react.useState)(null);
	const card = vocab[i % vocab.length];
	const options = (0, import_react.useMemo)(() => {
		return [...vocab.filter((w) => w.id !== card.id).slice(0, 3), card].sort((a, b) => a.word.localeCompare(b.word));
	}, [card]);
	function next(good) {
		addVocab(good);
		setStreak((s) => good ? s + 1 : 0);
		setFlipped(false);
		setPicked(null);
		setI((n) => n + 1);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(StudioShell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-end justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-5xl leading-none",
			children: t.vocab.title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-2 font-mono text-sm text-muted",
			children: [
				t.vocab.streak,
				" ",
				streak,
				" · ",
				t.vocab.xp,
				" ",
				xp
			]
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex rounded-full border border-line p-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: cn("min-h-10 rounded-full px-3", mode === "cards" && "bg-ink text-paper"),
				onClick: () => setMode("cards"),
				children: t.vocab.cards
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: cn("min-h-10 rounded-full px-3", mode === "fire" && "bg-ink text-paper"),
				onClick: () => setMode("fire"),
				children: t.vocab.fire
			})]
		})]
	}), mode === "cards" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-8 max-w-lg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => setFlipped((v) => !v),
			className: "min-h-56 w-full border border-line bg-sheet p-6 text-start",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-xs text-muted",
					children: flipped ? card.pos : t.vocab.flip
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 font-display text-5xl",
					dir: "ltr",
					children: flipped ? lang === "ar" ? card.ar : card.en : card.word
				}),
				flipped ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-muted",
					dir: "ltr",
					children: card.example
				}) : null
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "min-h-11 flex-1 rounded-full border border-line",
				onClick: () => next(false),
				children: t.vocab.missed
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "min-h-11 flex-1 rounded-full bg-signal font-semibold text-ink",
				onClick: () => next(true),
				children: t.vocab.knew
			})]
		})]
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-8 max-w-lg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: t.vocab.prompt
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 font-display text-3xl",
				children: lang === "ar" ? card.ar : card.en
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 grid gap-2",
				children: options.map((option) => {
					const show = picked !== null;
					const good = option.id === card.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: picked !== null,
						dir: "ltr",
						onClick: () => {
							setPicked(option.id);
							addVocab(good);
							setStreak((s) => good ? s + 1 : 0);
						},
						className: cn("min-h-12 border px-3 text-start", show && good && "border-mark bg-signal", show && picked === option.id && !good && "border-trap"),
						children: option.word
					}, option.id);
				})
			}),
			picked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "mt-4 min-h-11 rounded-full bg-ink px-4 font-semibold text-paper",
				onClick: () => {
					setPicked(null);
					setI((n) => n + 1);
				},
				children: t.vocab.next
			}) : null
		]
	})] });
}
//#endregion
export { VocabPage as component };
