import { i as __toESM } from "../_runtime.mjs";
import { _ as require_react, g as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { i as cn, l as useT } from "./chrome-ixJ0YwnM.mjs";
import { a as decoder, b as vocab, o as diagnostics, s as domains, u as heroQuestion, v as trapLabel, y as twinQuestion } from "./router-DNg9Mb-U.mjs";
import { n as motion, r as AnimatePresence, t as useReducedMotion } from "../_libs/framer-motion+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/lab-panel-D4trqfbv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function QuestionCard({ question, selected, onSelect, kicker }) {
	const { t, lang } = useT();
	const reduce = useReducedMotion();
	const choice = question.choices.find((c) => c.id === selected);
	const correct = selected === question.correct;
	const why = selected ? question.why[selected] : null;
	const tempting = question.choices.find((c) => c.id === question.tempting);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
		className: "relative border border-line bg-sheet shadow-sheet",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border-s-4 border-mark px-5 py-5 sm:px-7 sm:py-7",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-xs tracking-stamp text-muted uppercase",
					children: kicker
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 font-display text-lg leading-snug sm:text-xl",
					dir: "ltr",
					children: question.passage
				}),
				lang === "ar" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					dir: "rtl",
					children: question.passageAr
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-6 text-base font-semibold",
					dir: "ltr",
					children: question.stem
				}),
				lang === "ar" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					dir: "rtl",
					children: question.stemAr
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					role: "radiogroup",
					"aria-label": question.stem,
					className: "mt-5 grid gap-2",
					children: question.choices.map((item) => {
						const on = selected === item.id;
						const isKey = selected && item.id === question.correct;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							role: "radio",
							"aria-checked": on,
							onClick: () => onSelect(item.id),
							dir: "ltr",
							className: cn("flex min-h-12 items-start gap-3 rounded-2xl border px-3 py-3 text-start transition-colors", on && !correct && "border-trap bg-paper", on && correct && "border-mark bg-paper", !on && isKey && "border-mark", !on && !isKey && "border-line hover:border-ink"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-7 shrink-0 place-items-center rounded-full border border-line font-mono text-xs",
								children: item.id
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: cn("pt-0.5", selected && item.id !== question.correct && item.id === selected && "text-trap"),
								children: [item.en, lang === "ar" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block text-sm text-muted",
									dir: "rtl",
									children: item.ar
								}) : null]
							})]
						}, item.id);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sr-only",
					"aria-live": "polite",
					children: why ? lang === "ar" ? why.ar : why.en : ""
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: why && choice ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.aside, {
					initial: reduce ? false : {
						opacity: 0,
						y: 8
					},
					animate: {
						opacity: 1,
						y: 0
					},
					exit: { opacity: 0 },
					className: "mt-5 grid gap-3 border-t border-dashed border-line pt-4 sm:grid-cols-[auto_1fr]",
					children: [
						correct ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs tracking-stamp text-mark uppercase",
							children: t.lab.correct
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex w-fit -rotate-6 border-2 border-trap px-2 py-1 font-mono text-xs tracking-stamp text-trap uppercase",
							children: [t.lab.trapWord, choice.trap ? ` · ${lang === "ar" ? trapLabel[choice.trap].ar : trapLabel[choice.trap].en}` : ""]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm leading-relaxed",
							children: lang === "ar" ? why.ar : why.en
						}),
						correct && tempting?.trap ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted sm:col-start-2",
							children: [
								lang === "ar" ? "الفخ المجاور" : "The trap next door",
								": ",
								tempting.id,
								" —",
								" ",
								lang === "ar" ? question.why[tempting.id].ar : question.why[tempting.id].en
							]
						}) : null
					]
				}, question.id + selected) : null })
			]
		})
	});
}
var roleColor = {
	claim: "border-claim text-claim",
	pivot: "border-pivot text-pivot",
	conclusion: "border-conclusion text-conclusion"
};
function LabPanel({ id }) {
	const { t, lang } = useT();
	const [tab, setTab] = (0, import_react.useState)("trap");
	const [picked, setPicked] = (0, import_react.useState)(null);
	const [twin, setTwin] = (0, import_react.useState)(false);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [sentence, setSentence] = (0, import_react.useState)(decoder[1].id);
	const [word, setWord] = (0, import_react.useState)("posits");
	const [band, setBand] = (0, import_react.useState)(diagnostics[0].id);
	const question = twin ? twinQuestion : heroQuestion;
	const active = decoder.find((s) => s.id === sentence) ?? decoder[0];
	const plan = diagnostics.find((d) => d.id === band) ?? diagnostics[0];
	const entry = vocab.find((v) => v.id === word);
	function generateTwin() {
		if (loading) return;
		setLoading(true);
		setPicked(null);
		window.setTimeout(() => {
			setTwin(true);
			setLoading(false);
		}, 700);
	}
	const tabs = [
		{
			id: "trap",
			label: t.lab.trap,
			n: "01"
		},
		{
			id: "decode",
			label: t.lab.decode,
			n: "02"
		},
		{
			id: "coach",
			label: t.lab.coach,
			n: "03"
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id,
		className: "mx-auto max-w-6xl px-4 py-16 sm:py-24",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-xs tracking-stamp text-mark uppercase",
				children: t.lab.eyebrow
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid gap-6 lg:grid-cols-[0.9fr_1.1fr] lg:items-end",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-4xl leading-none sm:text-5xl",
					children: t.lab.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-xl text-muted",
					children: t.lab.lede
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				role: "tablist",
				"aria-label": t.lab.eyebrow,
				className: "mt-8 flex gap-2 overflow-x-auto border-b border-line",
				children: tabs.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					role: "tab",
					"aria-selected": tab === item.id,
					className: cn("min-h-12 shrink-0 border-b-2 px-3 font-medium", tab === item.id ? "border-mark text-ink" : "border-transparent text-muted"),
					onClick: () => setTab(item.id),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "me-2 font-mono text-xs text-mark",
						children: item.n
					}), item.label]
				}, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6",
				role: "tabpanel",
				children: [
					tab === "trap" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-6",
						children: [loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "animate-pulse space-y-3 border border-line bg-sheet p-6",
							"aria-hidden": true,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-3 w-40 bg-line" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-5 w-full bg-line" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-5 w-11/12 bg-line" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-12 w-full bg-line" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-12 w-full bg-line" })
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuestionCard, {
							question,
							selected: picked,
							onSelect: setPicked,
							kicker: twin ? "Twin · same logic" : t.hero.sheet
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: generateTwin,
								disabled: twin || loading,
								className: "inline-flex min-h-11 items-center rounded-full bg-ink px-5 text-sm font-semibold text-paper disabled:opacity-50",
								children: loading ? t.lab.working : t.lab.twin
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: t.lab.twinNote
							})]
						})]
					}) : null,
					tab === "decode" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-6 lg:grid-cols-[1.15fr_0.85fr]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border border-line bg-sheet p-5 sm:p-7",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted",
									children: t.lab.decodeHelp
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-4 flex flex-wrap gap-2 text-xs",
									children: [
										"claim",
										"pivot",
										"conclusion"
									].map((role) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: cn("border-s-2 px-2", roleColor[role]),
										children: t.lab[role]
									}, role))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-5 space-y-3",
									children: decoder.map((sentenceItem, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => setSentence(sentenceItem.id),
										dir: "ltr",
										className: cn("block w-full border-s-4 px-3 py-2 text-start font-display text-lg leading-snug", sentence === sentenceItem.id ? roleColor[sentenceItem.role] : "border-transparent text-ink"),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "me-2 font-mono text-xs text-muted",
											children: index + 1
										}), sentenceItem.en]
									}, sentenceItem.id))
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
							className: "border border-line bg-paper p-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: cn("font-mono text-xs tracking-stamp uppercase", roleColor[active.role]),
									children: t.lab[active.role]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-3 font-mono text-xs text-muted",
									children: t.lab.breakEn
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1",
									dir: "ltr",
									children: active.noteEn
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-4 font-mono text-xs text-muted",
									children: t.lab.breakAr
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1",
									dir: "rtl",
									children: active.noteAr
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-6 font-mono text-xs tracking-stamp text-muted uppercase",
									children: t.lab.vocab
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2 flex flex-wrap gap-2",
									children: vocab.slice(0, 4).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setWord(item.id),
										className: cn("min-h-9 rounded-full border px-3 text-sm", word === item.id ? "border-ink bg-ink text-paper" : "border-line"),
										children: item.word
									}, item.id))
								}),
								entry ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-3 text-sm",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-mono text-xs text-muted",
											children: entry.pos
										}),
										" ",
										lang === "ar" ? entry.ar : entry.en
									]
								}) : null
							]
						})]
					}) : null,
					tab === "coach" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: t.lab.coachHelp
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 grid gap-3 sm:grid-cols-2",
							children: diagnostics.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setBand(item.id),
								className: cn("min-h-20 border px-4 py-4 text-start", band === item.id ? "border-ink bg-sheet" : "border-line"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-mono text-xs text-mark",
									children: [
										item.from,
										" → ",
										item.to === 760 ? "750+" : item.to
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block font-display text-2xl",
									children: item.id === "build" ? t.lab.build : t.lab.push
								})]
							}, item.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 grid gap-6 lg:grid-cols-[0.8fr_1.2fr]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono text-xs tracking-stamp text-muted uppercase",
									children: t.lab.weak
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-3 space-y-3",
									children: plan.weak.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mb-1 flex justify-between text-sm",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: domainName(id, lang) })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-2 bg-line",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "h-2 bg-mark",
											style: { width: id === plan.weak[0] ? "38%" : "52%" }
										})
									})] }, id))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-6 font-display text-6xl leading-none tabular-nums text-ink",
									children: plan.gainIsSample ? "+110" : plan.to - plan.from
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted",
									children: plan.gainIsSample ? t.lab.projected : t.lab.gap
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-xs text-muted",
									children: plan.gainIsSample ? t.lab.sampleFlag : t.lab.gapFlag
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
								className: "border-s border-line ps-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
									className: "font-mono text-xs tracking-stamp text-mark uppercase",
									children: t.lab.week
								}), plan.plan.map((step, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "mt-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-mono text-xs text-muted",
										children: ["0", index + 1]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: lang === "ar" ? step.ar : step.en })]
								}, step.en))]
							})]
						})
					] }) : null
				]
			})
		]
	});
}
function domainName(id, lang) {
	const found = domains.find((d) => d.id === id);
	if (!found) return id;
	return lang === "ar" ? found.ar : found.en;
}
//#endregion
export { QuestionCard as n, LabPanel as t };
