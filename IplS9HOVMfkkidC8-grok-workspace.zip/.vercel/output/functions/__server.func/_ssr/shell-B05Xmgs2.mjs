import { g as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { c as usePrefs, i as cn, l as useT, t as Mark } from "./chrome-ixJ0YwnM.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as PenLine, c as Library, i as Rows3, l as House, u as BookOpen } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shell-B05Xmgs2.js
var import_jsx_runtime = require_jsx_runtime();
var items = [
	{
		to: "/dashboard",
		key: "home",
		icon: House
	},
	{
		to: "/skills",
		key: "skills",
		icon: Rows3
	},
	{
		to: "/error-vault",
		key: "vault",
		icon: Library
	},
	{
		to: "/practice",
		key: "practice",
		icon: PenLine
	},
	{
		to: "/vocab",
		key: "vocab",
		icon: BookOpen
	}
];
function StudioShell({ children }) {
	const { t } = useT();
	const setLang = usePrefs((s) => s.setLang);
	const lang = usePrefs((s) => s.lang);
	const toggleTheme = usePrefs((s) => s.toggleTheme);
	const theme = usePrefs((s) => s.theme);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-paper text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-30 flex h-14 items-center gap-3 border-b border-line bg-paper/95 px-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "flex items-center gap-2 font-display",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden sm:inline",
							children: "ScoreHigh"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "ms-4 hidden gap-4 text-sm lg:flex",
						"aria-label": "Studio",
						children: [items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: item.to,
							className: "text-muted",
							activeProps: { className: "text-ink font-semibold" },
							children: t.dash[item.key]
						}, item.to)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/teacher",
							className: "text-muted",
							activeProps: { className: "text-ink font-semibold" },
							children: t.dash.teacher
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "ms-auto flex items-center gap-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "min-h-9 px-2 font-semibold",
								onClick: () => setLang(lang === "ar" ? "en" : "ar"),
								children: lang === "ar" ? "EN" : "ع"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "min-h-9 px-2",
								onClick: toggleTheme,
								"aria-label": theme,
								children: theme === "dark" ? "Aa" : "Aa"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/",
								className: "min-h-9 px-2 text-muted",
								children: t.dash.exit
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto max-w-5xl px-4 py-6 pb-28 lg:pb-10",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t border-line bg-paper lg:hidden",
				"aria-label": "Studio mobile",
				children: items.map((item) => {
					const Icon = item.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: item.to,
						className: "flex min-h-16 flex-col items-center justify-center gap-1 text-xs text-muted",
						activeProps: { className: "text-ink" },
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("max-w-16 truncate"),
							children: t.dash[item.key]
						})]
					}, item.to);
				})
			})
		]
	});
}
//#endregion
export { StudioShell as t };
