import { i as __toESM } from "../_runtime.mjs";
import { _ as require_react, g as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { i as cn, l as useT, n as SiteFrame, r as WaButton } from "./chrome-ixJ0YwnM.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { h as reports, p as pillars, u as heroQuestion } from "./router-DNg9Mb-U.mjs";
import { t as FaqList } from "./faq-list-BArVeoTj.mjs";
import { n as QuestionCard, t as LabPanel } from "./lab-panel-D4trqfbv.mjs";
import { a as DialogOverlay, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BYNzz3H3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function pos(score) {
	return (score - 400) / 400 * 100;
}
function Results() {
	const { t, lang } = useT();
	const [active, setActive] = (0, import_react.useState)(reports[0].id);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [drawn, setDrawn] = (0, import_react.useState)(false);
	const report = reports.find((r) => r.id === active) ?? reports[0];
	(0, import_react.useEffect)(() => {
		setDrawn(false);
		const id = window.requestAnimationFrame(() => setDrawn(true));
		return () => window.cancelAnimationFrame(id);
	}, [active, open]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "border-y border-line bg-sheet/60",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-4 py-16 sm:py-24",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-xs tracking-stamp text-mark uppercase",
					children: t.results.eyebrow
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 max-w-3xl font-display text-4xl leading-none sm:text-6xl",
					children: t.results.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-2xl text-muted",
					children: t.results.lede
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 flex gap-2",
					role: "tablist",
					"aria-label": t.results.eyebrow,
					children: reports.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						role: "tab",
						"aria-selected": active === item.id,
						onClick: () => setActive(item.id),
						className: cn("min-h-11 rounded-full border px-4 text-sm font-semibold", active === item.id ? "border-ink bg-ink text-paper" : "border-line"),
						children: item.name
					}, item.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ladder, {
					reportId: report.id,
					drawn
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap items-end justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-xl text-sm text-muted",
						children: lang === "ar" ? report.noteAr : report.noteEn
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setOpen(true),
						className: "min-h-11 rounded-full border border-line px-4 text-sm font-semibold",
						children: t.results.enlarge
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-xs text-muted",
					children: t.results.only
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-10 grid gap-4 sm:grid-cols-2",
					children: [reports.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							setActive(item.id);
							setOpen(true);
						},
						className: "border border-line bg-paper p-5 text-start",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-mono text-xs text-muted",
								children: t.results.rw
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 font-display text-4xl leading-none tabular-nums",
								children: [
									item.rwFrom,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-mark",
										children: " → "
									}),
									item.rwTo
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm",
								children: lang === "ar" ? item.totalLabelAr : item.totalLabel
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-sm text-muted",
								children: item.name
							})
						]
					}, item.id)), [1, 2].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border border-dashed border-line p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs tracking-stamp text-muted uppercase",
							children: t.results.placeholder
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-muted",
							children: t.results.placeholderBody
						})]
					}, n))]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open,
			onOpenChange: setOpen,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-50 bg-ink/70" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
				className: "fixed inset-x-4 top-1/2 z-50 max-h-[90vh] -translate-y-1/2 overflow-auto border border-line bg-paper p-5 text-ink shadow-sheet sm:inset-x-auto sm:left-1/2 sm:w-[min(720px,92vw)] sm:-translate-x-1/2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
						className: "font-display text-3xl",
						children: [
							report.name,
							" · ",
							t.results.rw
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "mt-2 text-sm text-muted",
						children: lang === "ar" ? report.noteAr : report.noteEn
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ladder, {
							reportId: report.id,
							drawn,
							large: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
						className: "mt-8 min-h-11 rounded-full bg-ink px-4 text-sm font-semibold text-paper",
						children: t.results.close
					})
				]
			})] })
		})]
	});
}
function Ladder({ reportId, drawn, large }) {
	const { t } = useT();
	const report = reports.find((r) => r.id === reportId) ?? reports[0];
	const from = pos(report.rwFrom);
	const to = pos(report.rwTo);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("mt-8", large && "mt-4"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative h-16",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-x-0 top-7 h-px bg-line" }),
				[
					400,
					500,
					600,
					700,
					800
				].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute top-10 font-mono text-xs text-muted",
					style: {
						insetInlineStart: `${pos(n)}%`,
						transform: "translateX(-50%)"
					},
					children: n
				}, n)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute top-3 size-3 rounded-full border border-ink bg-paper",
					style: { insetInlineStart: `${drawn ? from : 8}%` }
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute top-1.5 size-6 rounded-full bg-signal transition-all duration-700",
					style: { insetInlineStart: `${drawn ? to : from}%` }
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 flex justify-between text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
				t.results.before,
				" ",
				report.rwFrom
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "font-semibold",
				children: [
					t.results.after,
					" ",
					report.rwTo
				]
			})]
		})]
	});
}
var LD = {
	"@context": "https://schema.org",
	"@type": "EducationalOrganization",
	name: "ScoreHigh SAT Prep",
	description: "Digital SAT Reading & Writing studio led by Teacher Ziad Ahmed for students in Egypt, Saudi Arabia, and the UAE.",
	founder: {
		"@type": "Person",
		name: "Ziad Ahmed"
	},
	areaServed: [
		"EG",
		"SA",
		"AE"
	],
	telephone: "+201599906731",
	knowsLanguage: ["en", "ar"]
};
function Home() {
	const { t, lang } = useT();
	const [picked, setPicked] = (0, import_react.useState)(null);
	const message = lang === "ar" ? "مرحبًا، أريد التسجيل في ScoreHigh. هذه درجتي الحالية في القراءة والكتابة: " : "Hello, I want to enroll in ScoreHigh. My current Reading & Writing score is ";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteFrame, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
			type: "application/ld+json",
			dangerouslySetInnerHTML: { __html: JSON.stringify(LD) }
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto flex max-w-6xl flex-col gap-8 px-4 py-8 lg:grid lg:grid-cols-2 lg:items-start lg:gap-12 lg:py-14",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "order-1 lg:col-start-1 lg:row-start-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs tracking-stamp text-mark uppercase",
						children: t.hero.kicker
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "mt-3 font-display text-4xl leading-none sm:text-6xl",
						children: [
							t.hero.line1,
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "marker-underline",
								children: t.hero.emphasis
							}),
							t.hero.line2 ? ` ${t.hero.line2}` : ""
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "order-2 lg:col-start-2 lg:row-start-1 lg:row-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 text-sm text-muted",
						children: t.hero.instruct
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuestionCard, {
						question: heroQuestion,
						selected: picked,
						onSelect: setPicked,
						kicker: t.hero.sheet
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "order-3 lg:col-start-1 lg:row-start-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "max-w-xl text-lg text-muted",
							children: t.hero.lede
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 flex flex-wrap gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WaButton, {
								message,
								children: t.hero.primary
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/lab",
								className: "inline-flex min-h-12 items-center rounded-full border border-line px-5 text-sm font-semibold",
								children: t.hero.secondary
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-md font-display text-2xl italic leading-snug",
							children: t.hero.philosophy
						})
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trust, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LabPanel, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Results, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto grid max-w-6xl gap-10 px-4 py-16 lg:grid-cols-[0.8fr_1.2fr] sm:py-24",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-xs tracking-stamp text-mark uppercase",
					children: t.about.eyebrow
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-4xl leading-none sm:text-5xl",
					children: t.about.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
					className: "mt-6 border-s-4 border-signal ps-4 font-display text-2xl italic",
					children: t.about.quote
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/about",
					className: "mt-6 inline-flex min-h-11 items-center text-sm font-semibold underline-offset-4 hover:underline",
					children: t.nav.about
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pillars, {})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-t border-line",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-4 py-16 sm:py-20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-end justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-4xl leading-none sm:text-5xl",
						children: t.programs.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/programs",
						className: "text-sm font-semibold underline-offset-4 hover:underline",
						children: t.nav.programs
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgramStrip, {})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-4 py-16",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-4xl leading-none",
					children: t.faq.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FaqList, { limit: 4 })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/faq",
					className: "mt-6 inline-flex min-h-11 items-center text-sm font-semibold underline-offset-4 hover:underline",
					children: t.faq.more
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FinalCta, {})
	] });
}
function Trust() {
	const { t } = useT();
	const items = [
		{
			k: t.trust.topK,
			v: t.trust.topV
		},
		{
			k: t.trust.actK,
			v: `${t.trust.actV}${t.trust.actS}`
		},
		{
			k: t.trust.psatK,
			v: `${t.trust.psatV}${t.trust.psatS}`
		},
		{
			k: t.trust.folK,
			v: `${t.trust.folV}${t.trust.folS}`
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "border-y border-line",
		"aria-label": t.trust.note,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto grid max-w-6xl gap-6 px-4 py-8 sm:grid-cols-4",
			children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex items-baseline justify-between gap-3 border-s border-line ps-4 sm:block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block font-mono text-xs tracking-stamp text-muted uppercase",
					children: item.k
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-4xl leading-none tabular-nums",
					children: item.v
				})]
			}, item.k))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mx-auto max-w-6xl px-4 pb-6 text-xs text-muted",
			children: t.trust.note
		})]
	});
}
function Pillars() {
	const { t, lang } = useT();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
		className: "relative space-y-8 border-s border-line ps-6",
		children: [pillars.map((pillar, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: cn("font-mono text-xs tracking-stamp", index === 2 ? "inline-block -rotate-6 border border-trap px-1.5 py-0.5 text-trap" : "text-mark", index === 1 && "inline-grid size-8 place-items-center rounded-full border border-mark"),
				children: ["0", index + 1]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-2 font-display text-3xl",
				children: lang === "ar" ? pillar.ar : pillar.en
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-xl text-muted",
				children: lang === "ar" ? pillar.bodyAr : pillar.bodyEn
			})
		] }, pillar.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: t.about.pillars
		})]
	});
}
function ProgramStrip() {
	const { t, lang } = useT();
	const message = lang === "ar" ? "مرحبًا، أريد تفاصيل برنامج ScoreHigh والسعر." : "Hello, I want the ScoreHigh program details and the price.";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-8 grid gap-4 lg:grid-cols-12",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "border border-ink bg-ink p-6 text-paper lg:col-span-7",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-xs tracking-stamp text-signal uppercase",
					children: t.programs.popular
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-3 font-display text-4xl text-paper",
					children: lang === "ar" ? "دورة المجموعة المباشرة" : "Live Group Course"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 font-display text-5xl text-signal",
					children: t.programs.price
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-paper/80",
					children: t.programs.priceNote
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WaButton, {
					message,
					className: "mt-6",
					children: t.programs.ask
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "border border-dashed border-trap bg-sheet p-6 lg:col-span-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-xs tracking-stamp text-trap uppercase",
					children: t.programs.spots
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-3 font-display text-3xl",
					children: lang === "ar" ? "تدريب فردي نخبة" : "Elite 1-on-1"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 font-display text-4xl",
					children: t.programs.price
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/programs",
					className: "mt-6 inline-flex min-h-11 items-center text-sm font-semibold underline-offset-4 hover:underline",
					children: t.nav.programs
				})
			]
		})]
	});
}
function FinalCta() {
	const { t, lang } = useT();
	const message = lang === "ar" ? "مرحبًا أستاذ زياد، هذه درجتي وموعد اختباري: " : "Hello Teacher Ziad, here is my score and test date: ";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "border-t border-line",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-4 py-16 sm:py-24",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "max-w-3xl font-display text-5xl leading-none sm:text-7xl",
					children: t.cta.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-xl text-muted",
					children: t.cta.lede
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WaButton, {
					message,
					className: "mt-8",
					children: t.cta.button
				})
			]
		})
	});
}
//#endregion
export { FinalCta, Pillars, ProgramStrip, Home as component };
