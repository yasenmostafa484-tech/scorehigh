import { g as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { l as useT, n as SiteFrame } from "./chrome-ixJ0YwnM.mjs";
import { r as FinalCta } from "./router-DNg9Mb-U.mjs";
import { t as FaqList } from "./faq-list-BArVeoTj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/faq-CO0G9Z4Y.js
var import_jsx_runtime = require_jsx_runtime();
function FaqPage() {
	const { t } = useT();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteFrame, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-3xl px-4 py-14",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-xs tracking-stamp text-mark uppercase",
				children: t.faq.eyebrow
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-5xl leading-none",
				children: t.faq.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FaqList, {})
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FinalCta, {})] });
}
//#endregion
export { FaqPage as component };
