import { i as __toESM } from "../_runtime.mjs";
import { _ as require_react, g as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { l as useT, n as SiteFrame } from "./chrome-ixJ0YwnM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/vault-w1NIDe1u.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function VaultPage() {
	const { t } = useT();
	const [name, setName] = (0, import_react.useState)("");
	const [contact, setContact] = (0, import_react.useState)("");
	const [note, setNote] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [pending, setPending] = (0, import_react.useState)(false);
	const [done, setDone] = (0, import_react.useState)(false);
	async function submit(e) {
		e.preventDefault();
		if (name.trim().length < 1) {
			setError(t.vault.errName);
			return;
		}
		if (contact.trim().length < 5) {
			setError(t.vault.errContact);
			return;
		}
		setError("");
		setPending(true);
		try {
			if (!(await fetch("/api/leads", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					name,
					contact,
					note
				})
			})).ok) throw new Error("no");
			const prev = JSON.parse(localStorage.getItem("scorehigh-leads") || "[]");
			localStorage.setItem("scorehigh-leads", JSON.stringify([...prev, {
				name,
				contact,
				note
			}]));
			setDone(true);
		} catch {
			setError(t.vault.errContact);
		} finally {
			setPending(false);
		}
	}
	const resources = [
		{
			title: t.vault.master,
			detail: "Recording"
		},
		{
			title: t.vault.exam,
			detail: "Bluebook 11"
		},
		{
			title: t.vault.drive,
			detail: "Drive"
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteFrame, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto grid max-w-6xl gap-10 px-4 py-14 lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-xs tracking-stamp text-mark uppercase",
				children: t.vault.eyebrow
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-5xl leading-none",
				children: t.vault.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-muted",
				children: t.vault.lede
			})
		] }), done ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border border-line bg-sheet p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl",
					children: t.vault.thanks
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					children: t.vault.thanksBody
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "mt-5 text-sm font-semibold underline",
					onClick: () => setDone(false),
					children: t.vault.again
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: submit,
			className: "grid gap-3 border border-line bg-sheet p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "grid gap-1 text-sm",
					children: [t.vault.name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: name,
						onChange: (e) => setName(e.target.value),
						className: "min-h-11 border border-line bg-paper px-3",
						autoComplete: "name",
						required: true
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "grid gap-1 text-sm",
					children: [t.vault.contact, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: contact,
						onChange: (e) => setContact(e.target.value),
						className: "min-h-11 border border-line bg-paper px-3",
						autoComplete: "email",
						required: true
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "grid gap-1 text-sm",
					children: [t.vault.note, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: note,
						onChange: (e) => setNote(e.target.value),
						className: "min-h-24 border border-line bg-paper px-3 py-2"
					})]
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-trap",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					disabled: pending,
					className: "min-h-12 rounded-full bg-signal px-5 font-semibold text-ink disabled:opacity-60",
					children: pending ? t.vault.sending : t.vault.send
				})
			]
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-6xl px-4 pb-16",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-3xl",
			children: t.vault.items
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 grid gap-3 md:grid-cols-3",
			children: resources.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "border border-dashed border-line p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs text-muted",
						children: item.detail
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-2 font-display text-2xl",
						children: item.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 font-mono text-xs tracking-stamp text-trap uppercase",
						children: t.vault.locked
					})
				]
			}, item.title))
		})]
	})] });
}
//#endregion
export { VaultPage as component };
