import { i as __toESM } from "../_runtime.mjs";
import { _ as require_react, g as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { c as usePrefs, l as useT } from "./chrome-ixJ0YwnM.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { g as sampleMastery, s as domains } from "./router-DNg9Mb-U.mjs";
import { t as StudioShell } from "./shell-B05Xmgs2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/skills-Dmi9icMg.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SkillsPage() {
	const { t, lang } = useT();
	const stats = usePrefs((s) => s.domains);
	const [sample, setSample] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(StudioShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-mono text-xs tracking-stamp text-mark uppercase",
			children: t.skills.title
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-2 font-display text-5xl leading-none",
			children: t.skills.title
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 max-w-xl text-muted",
			children: t.skills.lede
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "mt-4 text-sm font-semibold underline",
			onClick: () => setSample((v) => !v),
			children: sample ? t.skills.hide : t.skills.sample
		}),
		sample ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-trap",
			children: t.skills.sampleOn
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-8 space-y-6",
			children: domains.map((domain) => {
				const live = stats[domain.id];
				const pct = sample ? sampleMastery[domain.id] : live.total ? Math.round(live.correct / live.total * 100) : 0;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl",
							children: lang === "ar" ? domain.ar : domain.en
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-sm tabular-nums",
							children: live.total || sample ? `${pct}%` : t.skills.empty
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 h-3 bg-line",
						"aria-hidden": true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-3 bg-mark transition-all",
							style: { width: `${pct}%` }
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/practice",
						className: "mt-2 inline-flex min-h-10 items-center text-sm font-semibold",
						children: t.skills.drill
					})
				] }, domain.id);
			})
		})
	] });
}
//#endregion
export { SkillsPage as component };
