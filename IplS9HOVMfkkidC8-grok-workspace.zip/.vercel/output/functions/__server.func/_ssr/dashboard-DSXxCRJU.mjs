import { i as __toESM } from "../_runtime.mjs";
import { _ as require_react, g as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { a as dueCount, c as usePrefs, l as useT, o as missionCount } from "./chrome-ixJ0YwnM.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as domains } from "./router-DNg9Mb-U.mjs";
import { t as StudioShell } from "./shell-B05Xmgs2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-DSXxCRJU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var MONTHS = [
	"Mar 2026",
	"May 2026",
	"Jun 2026",
	"Aug 2026",
	"Sep 2026",
	"Oct 2026",
	"Nov 2026",
	"Dec 2026",
	"Mar 2027",
	"Not set"
];
function DashboardPage() {
	const profile = usePrefs((s) => s.profile);
	if (!profile) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Onboarding, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Today, { profile }) });
}
function Onboarding() {
	const { t, lang } = useT();
	const setProfile = usePrefs((s) => s.setProfile);
	const [step, setStep] = (0, import_react.useState)(0);
	const [name, setName] = (0, import_react.useState)("");
	const [current, setCurrent] = (0, import_react.useState)(580);
	const [target, setTarget] = (0, import_react.useState)(700);
	const [testDate, setTestDate] = (0, import_react.useState)(MONTHS[1]);
	const [ready, setReady] = (0, import_react.useState)(false);
	const focus = current < 600 ? ["sec", "info"] : current < 700 ? ["craft", "info"] : ["craft", "expression"];
	const draft = {
		name: name.trim() || (lang === "ar" ? "طالب" : "Student"),
		current,
		target: Math.max(target, current),
		testDate
	};
	if (ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(StudioShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-mono text-xs tracking-stamp text-mark uppercase",
			children: t.dash.roadmap
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-2 font-display text-5xl leading-none",
			children: draft.name
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scale, {
			current: draft.current,
			target: draft.target
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-xs text-muted",
			children: t.dash.estimate
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-8 font-display text-2xl",
			children: t.dash.focus
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 space-y-2",
			children: focus.map((id) => {
				const d = domains.find((item) => item.id === id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "border-s-4 border-mark ps-3",
					children: lang === "ar" ? d?.ar : d?.en
				}, id);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 text-sm text-muted",
			children: testDate === "Not set" ? t.dash.noDate : t.dash.weeks
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "mt-6 min-h-12 rounded-full bg-signal px-5 font-semibold text-ink",
			onClick: () => setProfile(draft),
			children: t.dash.enter
		})
	] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto min-h-screen max-w-xl bg-paper px-4 py-12 text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-xs tracking-stamp text-mark uppercase",
				children: t.dash.onboardKicker
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-5xl leading-none",
				children: t.dash.onboardTitle
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-6 font-mono text-xs text-muted",
				children: [
					"0",
					step + 1,
					" / 03"
				]
			}),
			step === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-4 grid gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t.dash.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: name,
					placeholder: t.dash.namePh,
					onChange: (e) => setName(e.target.value),
					className: "min-h-12 border border-line bg-sheet px-3"
				})]
			}) : null,
			step === 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreField, {
					label: t.dash.currentQ,
					value: current,
					onChange: setCurrent
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreField, {
					label: t.dash.targetQ,
					value: target,
					onChange: setTarget
				})]
			}) : null,
			step === 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-4 grid gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t.dash.dateQ }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					value: testDate,
					onChange: (e) => setTestDate(e.target.value),
					className: "min-h-12 border border-line bg-sheet px-3",
					children: MONTHS.map((month) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: month }, month))
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex gap-2",
				children: [step > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "min-h-11 rounded-full border border-line px-4",
					onClick: () => setStep((s) => s - 1),
					children: t.programs.back
				}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "min-h-11 rounded-full bg-ink px-4 font-semibold text-paper",
					onClick: () => step === 2 ? setReady(true) : setStep((s) => s + 1),
					children: t.programs.next
				})]
			})
		]
	});
}
function ScoreField({ label, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "grid gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex justify-between",
			children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-display text-3xl tabular-nums",
				children: value
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "range",
			min: 400,
			max: 800,
			step: 10,
			value,
			onChange: (e) => onChange(Number(e.target.value)),
			className: "accent-ink"
		})]
	});
}
function Today({ profile }) {
	const { t } = useT();
	const missions = usePrefs((s) => s.missions);
	const streak = usePrefs((s) => s.streak);
	const vault = usePrefs((s) => s.vault);
	const done = missionCount(missions);
	const due = dueCount(vault);
	const ring = (0, import_react.useMemo)(() => {
		const r = 42;
		const c = 2 * Math.PI * r;
		return {
			r,
			c,
			dash: `${c * done / 3} ${c}`
		};
	}, [done]);
	const rows = [
		{
			ok: missions.practice,
			label: t.dash.missionPractice
		},
		{
			ok: missions.vocab >= 5,
			label: t.dash.missionVocab
		},
		{
			ok: missions.vault >= 1,
			label: t.dash.missionVault
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6 lg:grid-cols-[1.2fr_0.8fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-xs tracking-stamp text-muted uppercase",
				children: t.dash.hello
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-5xl leading-none",
				children: profile.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 border border-line bg-sheet p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs tracking-stamp text-mark uppercase",
						children: t.dash.mission
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 space-y-3",
						children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: row.ok ? "bg-signal text-ink" : "border border-line",
								style: {
									width: 18,
									height: 18,
									display: "inline-grid",
									placeItems: "center",
									fontSize: 12
								},
								children: row.ok ? "✓" : ""
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: row.ok ? "text-muted line-through" : "",
								children: row.label
							})]
						}, row.label))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/practice",
						className: "mt-6 inline-flex min-h-11 items-center rounded-full bg-signal px-4 text-sm font-semibold text-ink",
						children: t.dash.continue
					})
				]
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-4 border border-line p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
					width: "100",
					height: "100",
					viewBox: "0 0 100 100",
					"aria-hidden": true,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "50",
						cy: "50",
						r: ring.r,
						fill: "none",
						stroke: "var(--line)",
						strokeWidth: "8"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "50",
						cy: "50",
						r: ring.r,
						fill: "none",
						stroke: "var(--mark)",
						strokeWidth: "8",
						strokeDasharray: ring.dash,
						strokeLinecap: "round",
						transform: "rotate(-90 50 50)"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs text-muted",
						children: t.dash.week
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-display text-4xl tabular-nums",
						children: [
							done,
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-lg text-muted",
								children: [t.dash.of, " 3"]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							t.dash.streak,
							": ",
							streak
						]
					})
				] })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border border-line p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs text-muted",
						children: t.dash.gauge
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scale, {
						current: profile.current,
						target: profile.target
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-muted",
						children: t.dash.estimate
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-sm",
						children: [
							t.dash.due,
							": ",
							due
						]
					})
				]
			})]
		})]
	});
}
function Scale({ current, target }) {
	const { t } = useT();
	const place = (n) => `${(n - 400) / 400 * 100}%`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative h-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-x-0 top-3 h-px bg-line" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute top-1 size-4 rounded-full bg-ink",
					style: { insetInlineStart: place(current) }
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute top-0.5 size-5 rounded-full bg-signal",
					style: { insetInlineStart: place(target) }
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex justify-between text-xs text-muted",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
				t.dash.current,
				" ",
				current
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
				t.dash.target,
				" ",
				target
			] })]
		})]
	});
}
//#endregion
export { DashboardPage as component };
