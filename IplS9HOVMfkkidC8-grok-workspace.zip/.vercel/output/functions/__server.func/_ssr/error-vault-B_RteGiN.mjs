import { i as __toESM } from "../_runtime.mjs";
import { _ as require_react, g as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { c as usePrefs, i as cn, l as useT, s as todayKey } from "./chrome-ixJ0YwnM.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as sampleMistakes, l as getQuestion, v as trapLabel } from "./router-DNg9Mb-U.mjs";
import { t as StudioShell } from "./shell-B05Xmgs2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/error-vault-B_RteGiN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var filters = [
	"all",
	"too-extreme",
	"half-right",
	"out-of-scope",
	"wrong-sense",
	"opposite",
	"agreement"
];
function VaultPage() {
	const { t, lang } = useT();
	const vault = usePrefs((s) => s.vault);
	const [filter, setFilter] = (0, import_react.useState)("all");
	const today = todayKey();
	const mine = vault.filter((card) => filter === "all" || card.trap === filter);
	const samples = sampleMistakes.filter((card) => filter === "all" || card.trap === filter);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(StudioShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-mono text-xs tracking-stamp text-mark uppercase",
			children: t.errors.title
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-2 font-display text-5xl leading-none",
			children: t.errors.title
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 max-w-xl text-muted",
			children: t.errors.lede
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-5 flex gap-2 overflow-x-auto",
			role: "group",
			"aria-label": t.errors.filter,
			children: filters.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setFilter(item),
				className: cn("min-h-10 shrink-0 rounded-full border px-3 text-sm", filter === item ? "border-ink bg-ink text-paper" : "border-line"),
				children: item === "all" ? t.errors.all : lang === "ar" ? trapLabel[item].ar : trapLabel[item].en
			}, item))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-8 font-display text-2xl",
			children: t.errors.yours
		}),
		mine.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted",
			children: t.errors.empty
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 grid gap-3",
			children: mine.map((card) => {
				const q = getQuestion(card.questionId);
				const due = !card.resolved && card.due <= today;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "border border-line bg-sheet p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2 text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "border border-trap px-1.5 py-0.5 font-mono tracking-stamp text-trap uppercase",
								children: lang === "ar" ? trapLabel[card.trap].ar : trapLabel[card.trap].en
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-muted",
								children: due ? t.errors.due : card.resolved ? t.errors.done : t.errors.later
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2",
							dir: "ltr",
							children: q.stem
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/practice",
							search: {
								q: card.questionId,
								card: card.id
							},
							className: "mt-3 inline-flex min-h-10 items-center text-sm font-semibold",
							children: t.errors.retry
						})
					]
				}, card.id);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-10 font-display text-2xl",
			children: t.errors.samples
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted",
			children: t.errors.samplesNote
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 grid gap-3 sm:grid-cols-2",
			children: samples.map((card) => {
				const q = getQuestion(card.questionId);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "border border-dashed border-line p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs text-trap",
							children: lang === "ar" ? trapLabel[card.trap].ar : trapLabel[card.trap].en
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm",
							dir: "ltr",
							children: q.stem
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 font-mono text-xs text-mark",
							children: t.errors.due
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/practice",
							search: { q: card.questionId },
							className: "mt-3 inline-flex min-h-10 items-center text-sm font-semibold",
							children: t.errors.retry
						})
					]
				}, card.id);
			})
		})
	] });
}
//#endregion
export { VaultPage as component };
