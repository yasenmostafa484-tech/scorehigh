import { i as __toESM } from "../_runtime.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
import { _ as require_react, g as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as Moon, r as Sun, s as Menu, t as X } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/use-t-CUYPol9I.js
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function weekKey(date = /* @__PURE__ */ new Date()) {
	const start = new Date(date.getFullYear(), 0, 1);
	const day = Math.floor((date.getTime() - start.getTime()) / 864e5);
	const week = Math.ceil((day + start.getDay() + 1) / 7);
	return `${date.getFullYear()}-W${week}`;
}
function todayKey(date = /* @__PURE__ */ new Date()) {
	return date.toISOString().slice(0, 10);
}
var emptyDomains = () => ({
	craft: {
		correct: 0,
		total: 0
	},
	info: {
		correct: 0,
		total: 0
	},
	sec: {
		correct: 0,
		total: 0
	},
	expression: {
		correct: 0,
		total: 0
	}
});
function freshMissions() {
	return {
		date: todayKey(),
		practice: false,
		vocab: 0,
		vault: 0
	};
}
var memoryStorage = {
	getItem: () => null,
	setItem: () => {},
	removeItem: () => {}
};
function bumpStreak(lastActive, streak) {
	const today = todayKey();
	if (lastActive === today) return {
		lastActive: today,
		streak
	};
	const y = /* @__PURE__ */ new Date();
	y.setDate(y.getDate() - 1);
	return {
		lastActive: today,
		streak: lastActive === todayKey(y) ? streak + 1 : 1
	};
}
var usePrefs = create()(persist((set, get) => ({
	lang: "en",
	theme: "light",
	profile: null,
	xp: 0,
	streak: 0,
	lastActive: null,
	weekId: weekKey(),
	missions: freshMissions(),
	vault: [],
	domains: emptyDomains(),
	history: [],
	setLang: (lang) => set({ lang }),
	setTheme: (theme) => set({ theme }),
	toggleTheme: () => {
		const next = get().theme === "dark" ? "light" : "dark";
		get().setTheme(next);
	},
	setProfile: (profile) => set({ profile }),
	recordAnswer: (domain, correct) => {
		const domains = {
			...get().domains,
			[domain]: { ...get().domains[domain] }
		};
		domains[domain] = {
			correct: domains[domain].correct + (correct ? 1 : 0),
			total: domains[domain].total + 1
		};
		const totals = Object.values(domains).reduce((acc, d) => ({
			correct: acc.correct + d.correct,
			total: acc.total + d.total
		}), {
			correct: 0,
			total: 0
		});
		const accuracy = totals.total ? Math.round(totals.correct / totals.total * 100) : 0;
		set({
			domains,
			history: [...get().history, {
				n: totals.total,
				accuracy
			}]
		});
	},
	finishModule: () => {
		const missions = normalizeMissions(get().missions);
		const streak = bumpStreak(get().lastActive, get().streak);
		set({
			missions: {
				...missions,
				practice: true
			},
			xp: get().xp + 40,
			...streak
		});
	},
	addVocab: (good) => {
		const missions = normalizeMissions(get().missions);
		const streak = bumpStreak(get().lastActive, get().streak);
		set({
			missions: {
				...missions,
				vocab: missions.vocab + 1
			},
			xp: get().xp + (good ? 10 : 2),
			...streak
		});
	},
	addMistake: (card) => {
		if (get().vault.some((v) => v.questionId === card.questionId && !v.resolved)) return;
		set({ vault: [{
			...card,
			due: todayKey(),
			retries: 0,
			resolved: false
		}, ...get().vault] });
	},
	retryCard: (id, correct) => {
		const missions = normalizeMissions(get().missions);
		const streak = bumpStreak(get().lastActive, get().streak);
		set({
			vault: get().vault.map((card) => {
				if (card.id !== id) return card;
				const retries = card.retries + 1;
				const due = /* @__PURE__ */ new Date();
				due.setDate(due.getDate() + (correct ? 4 : 1));
				return {
					...card,
					retries,
					due: todayKey(due),
					resolved: correct && retries >= 1
				};
			}),
			missions: {
				...missions,
				vault: missions.vault + 1
			},
			xp: get().xp + (correct ? 15 : 4),
			...streak
		});
	},
	resetDemo: () => set({
		xp: 0,
		streak: 0,
		lastActive: null,
		missions: freshMissions(),
		vault: [],
		domains: emptyDomains(),
		history: []
	})
}), {
	name: "scorehigh-prefs",
	skipHydration: true,
	storage: createJSONStorage(() => typeof window === "undefined" ? memoryStorage : localStorage)
}));
function normalizeMissions(missions) {
	const today = todayKey();
	if (missions.date !== today) return freshMissions();
	return missions;
}
function missionCount(missions) {
	const m = missions.date === todayKey() ? missions : freshMissions();
	return (m.practice ? 1 : 0) + (m.vocab >= 5 ? 1 : 0) + (m.vault >= 1 ? 1 : 0);
}
function dueCount(vault) {
	const today = todayKey();
	return vault.filter((c) => !c.resolved && c.due <= today).length;
}
var en = {
	nav: {
		lab: "AI lab",
		programs: "Programs",
		vault: "Free vault",
		about: "Ziad",
		faq: "FAQ",
		enroll: "Enroll on WhatsApp",
		student: "Student demo",
		menu: "Menu",
		close: "Close",
		themeToDark: "Switch to dark paper",
		themeToLight: "Switch to light paper",
		language: "Language"
	},
	hero: {
		kicker: "Teacher Ziad Ahmed · Digital SAT English",
		line1: "Stop guessing between two",
		emphasis: "almost-identical",
		line2: "answers.",
		lede: "Reading & Writing, taught as the test-maker’s mind. Name the trap. Then choose. For students in Egypt, Saudi Arabia, and the UAE — and the parents who pay.",
		primary: "Enroll on WhatsApp",
		secondary: "Try the AI lab",
		philosophy: "I don’t just teach content. I train you how to think.",
		sheet: "Question 01 · Words in context",
		instruct: "Tap an answer. The margin will say why it tempts."
	},
	trust: {
		note: "Credentials on the record. Nothing here is a class average we invented.",
		topK: "SAT",
		topV: "Top 1%",
		actK: "ACT English",
		actV: "36",
		actS: "/36",
		psatK: "PSAT",
		psatV: "1500",
		psatS: "+",
		folK: "Followers",
		folV: "23",
		folS: "K+"
	},
	lab: {
		eyebrow: "The lab",
		title: "Three tools. One habit: see the trap before you feel sure.",
		lede: "Sample items, written for this studio. Not official College Board questions.",
		trap: "Trap lab",
		decode: "Passage decoder",
		coach: "AI coach",
		twin: "Generate a twin question",
		twinNote: "Same logic, new clothes. A skeleton, then the twin.",
		working: "Cloning the logic…",
		correct: "That’s the logic.",
		trapWord: "Trap",
		see: "Margin note",
		claim: "Claim",
		pivot: "Pivot",
		conclusion: "Conclusion",
		decodeHelp: "Tap a sentence. Plain English on the left of the thought, Arabic on the right of it.",
		breakEn: "Plain English",
		breakAr: "بالعربية",
		vocab: "Words worth keeping",
		coachHelp: "Pick a band. The plan is a sample coaching read, not a promise.",
		weak: "Weak domains in this sample",
		week: "This week",
		projected: "Illustrated gain",
		gap: "Gap to the top of the band",
		sampleFlag: "The +110 figure is the studio’s sample diagnostic, shown as an illustration.",
		gapFlag: "This number is the distance to the band, not a predicted gain.",
		build: "570 toward 680",
		push: "650 toward 750+"
	},
	results: {
		eyebrow: "Reported movement",
		title: "Two score reports. No invented quotes.",
		lede: "Zaid and Nancy are the results on file. The empty frames are for the next real story — not a fake review.",
		before: "Before",
		after: "After",
		rw: "Reading & Writing",
		enlarge: "Enlarge",
		close: "Close report",
		placeholder: "Placeholder",
		placeholderBody: "Add a student story. Quote, photo, and report stay empty until they are real.",
		only: "Only the reported endpoints are drawn. The line does not invent the months in between."
	},
	about: {
		eyebrow: "The teacher",
		title: "Ziad Ahmed trains the decision, not the highlight.",
		lede: "Top 1% SAT. 36/36 ACT English. Multiple 1500+ PSATs. 23K+ followers. Digital SAT Reading & Writing for students in Egypt, Saudi Arabia, and the UAE.",
		noBio: "This page does not invent a childhood, a city, or a turning point that was not provided. The public record of the studio is the standard, the method, and the two reported score moves.",
		pillars: "Three margins",
		quote: "I don’t just teach content. I train you how to think."
	},
	programs: {
		eyebrow: "Programs",
		title: "One road, a narrower road, and a free door.",
		price: "[PRICE]",
		priceNote: "Confirmed on WhatsApp before you pay.",
		ask: "Ask on WhatsApp",
		spots: "Limited spots",
		popular: "Most students",
		fit: "Which program fits?",
		q1: "Where is Reading & Writing now?",
		q2: "How do you want to work?",
		q3: "When is the test?",
		lt: "Under 600",
		mid: "600–700",
		hi: "700 and up",
		group: "Live group",
		private: "Private coaching",
		self: "Start on my own",
		soon: "Inside 6 weeks",
		season: "This season",
		explore: "Still exploring",
		next: "Next",
		back: "Back",
		resultGroup: "Start with the live group.",
		resultElite: "Ask about Elite 1-on-1.",
		resultVault: "Open the free vault first.",
		resultBodyGroup: "You want company and a full road. The group is the main program. Mention your score on WhatsApp.",
		resultBodyElite: "You asked for a private plan, or you are already high and want the seat that stays limited.",
		resultBodyVault: "You are exploring or want to start alone. Take the masterclass and the exam vault, then decide.",
		restart: "Start the three questions again"
	},
	vault: {
		eyebrow: "Free vault",
		title: "The masterclass, Exam 11, and the question folder.",
		lede: "Leave a name and an email or WhatsApp number. This demo stores nothing on a server that can write back to you — it confirms the form and shows where the files will sit.",
		name: "Name",
		contact: "Email or WhatsApp",
		note: "Note for the studio (optional)",
		send: "Request the vault",
		sending: "Sending…",
		thanks: "Request noted in this demo.",
		thanksBody: "Nothing was emailed. The three resources below are placeholders until ScoreHigh connects the real recording, the Exam 11 walkthrough, and the Drive folder.",
		again: "Submit another request",
		items: "What the vault holds",
		master: "Masterclass recording",
		exam: "Bluebook Exam 11 walkthrough",
		drive: "Real-question Drive folder",
		locked: "Link placeholder",
		errName: "Add a name.",
		errContact: "Add an email or a WhatsApp number."
	},
	faq: {
		eyebrow: "Questions parents actually ask",
		title: "Straight answers.",
		more: "All questions"
	},
	cta: {
		title: "Bring the two answers you can’t separate.",
		lede: "Tell Ziad the score, the test date, and whether you want the group or a private seat.",
		button: "WhatsApp +20 159 990 6731"
	},
	footer: {
		rights: "ScoreHigh SAT Prep · Teacher Ziad Ahmed",
		trademark: "SAT is a registered trademark of the College Board, which is not affiliated with ScoreHigh.",
		instagram: "Instagram",
		tiktok: "TikTok",
		whatsapp: "WhatsApp"
	},
	dash: {
		home: "Today",
		skills: "Skills",
		vault: "Error vault",
		practice: "Practice",
		vocab: "Vocabulary",
		teacher: "Teacher view",
		exit: "Site",
		hello: "Today’s paper",
		mission: "Three moves",
		missionPractice: "Finish a practice module",
		missionVocab: "Clear 5 vocabulary cards",
		missionVault: "Retry 1 vault card",
		streak: "Day streak",
		week: "This week",
		of: "of",
		gauge: "From your diagnostic",
		current: "Now",
		target: "Target",
		estimate: "A coaching sketch, not an official score.",
		continue: "Open a module",
		setup: "Set the target first",
		due: "Due in the vault",
		onboardKicker: "Diagnostic",
		onboardTitle: "Three facts. Then a road.",
		name: "What should we call you?",
		namePh: "Your name",
		currentQ: "Current Reading & Writing",
		targetQ: "Target Reading & Writing",
		dateQ: "Test month",
		roadmap: "Your road",
		enter: "Enter the studio",
		focus: "Work these first",
		weeks: "Sittings before the date you chose",
		noDate: "No month chosen — the plan stays weekly anyway."
	},
	skills: {
		title: "Skill map",
		lede: "Mastery fills from modules you actually submit in this demo.",
		empty: "No items yet",
		sample: "Preview a labeled sample",
		sampleOn: "Sample session — not a real student. Hidden from the teacher’s reported list.",
		hide: "Hide sample",
		drill: "Drill this domain"
	},
	errors: {
		title: "Error vault",
		lede: "Every miss kept, tagged by the job the wrong answer was doing.",
		yours: "From your modules",
		samples: "Demo cards",
		samplesNote: "These four cards are samples so the vault isn’t an empty room. They are not a student’s private record.",
		empty: "No personal misses yet. Finish a module.",
		filter: "Filter",
		all: "All traps",
		retry: "Retry",
		due: "Due",
		later: "Later",
		done: "Settled"
	},
	practice: {
		mod: "Module",
		demo: "Demo timer",
		start: "Start timer",
		pause: "Pause",
		marker: "Marker",
		eliminate: "Eliminate",
		flag: "Flag",
		flagged: "Flagged",
		nav: "Navigator",
		submit: "Submit module",
		need: "Unanswered questions stay blank. Submit anyway?",
		review: "Review",
		your: "Your choice",
		key: "Key",
		nextMod: "Continue to Module 2",
		done: "Module complete",
		accuracy: "Demo accuracy",
		notOfficial: "Not an official SAT score. Four items are not a section.",
		again: "Reset this demo",
		dash: "Back to today",
		transition: "Module 2",
		transitionBody: "The set shifts. Same clock, tighter traps.",
		passage: "Passage",
		question: "Question",
		highlightHelp: "Marker is on. Tap a word to underline it."
	},
	vocab: {
		title: "Vocabulary arena",
		cards: "Cards",
		fire: "Quick-fire",
		flip: "Flip",
		knew: "I knew it",
		missed: "Missed it",
		streak: "Streak",
		xp: "XP",
		prompt: "Which word matches?",
		next: "Next card"
	},
	teacher: {
		eyebrow: "Teacher demo",
		title: "What is actually on file.",
		lede: "Zaid and Nancy show only the scores that were provided. No invented weekly points. The third row is a placeholder. The live panel is whoever is using this browser.",
		reported: "Reported",
		placeholder: "Placeholder — add a student",
		placeholderBody: "Name, scores, and notes stay blank on purpose.",
		you: "This browser",
		accuracy: "Running accuracy",
		none: "No module submitted in this browser yet.",
		domains: "Domains from submitted items"
	},
	common: { score: "Score" }
};
var ar = {
	nav: {
		lab: "مختبر الذكاء",
		programs: "البرامج",
		vault: "الخزنة المجانية",
		about: "زياد",
		faq: "أسئلة",
		enroll: "سجّل عبر واتساب",
		student: "تجربة الطالب",
		menu: "القائمة",
		close: "إغلاق",
		themeToDark: "التبديل إلى الورق الداكن",
		themeToLight: "التبديل إلى الورق الفاتح",
		language: "اللغة"
	},
	hero: {
		kicker: "المدرّس زياد أحمد · إنجليزي السات الرقمي",
		line1: "توقّف عن التخمين بين إجابتين",
		emphasis: "تكادان تتطابقان",
		line2: "",
		lede: "القراءة والكتابة كما يفكّر واضع الاختبار. سمِّ الفخ. ثم اختر. لطلاب مصر والسعودية والإمارات — وللأهل الذين يدفعون.",
		primary: "سجّل عبر واتساب",
		secondary: "جرّب المختبر",
		philosophy: "لا أدرّس المحتوى فقط. أدرّبك كيف تفكّر.",
		sheet: "سؤال 01 · معنى الكلمة في السياق",
		instruct: "اضغط إجابة. الهامش سيقول لماذا تغري."
	},
	trust: {
		note: "اعتمادات موثّقة. لا يوجد هنا متوسط صف اخترعناه.",
		topK: "السات",
		topV: "أعلى 1٪",
		actK: "ACT English",
		actV: "36",
		actS: "/36",
		psatK: "PSAT",
		psatV: "1500",
		psatS: "+",
		folK: "المتابعون",
		folV: "23",
		folS: "ألف+"
	},
	lab: {
		eyebrow: "المختبر",
		title: "ثلاث أدوات. عادة واحدة: انظر الفخ قبل أن تشعر باليقين.",
		lede: "أسئلة مكتوبة لهذا الاستوديو. ليست أسئلة رسمية من College Board.",
		trap: "مختبر الفخ",
		decode: "مفكّك الفقرة",
		coach: "مدرّب الذكاء",
		twin: "اصنع سؤالًا توأمًا",
		twinNote: "المنطق نفسه، ثوب جديد. هيكل ثم التوأم.",
		working: "نسخ المنطق…",
		correct: "هذا هو المنطق.",
		trapWord: "فخ",
		see: "ملاحظة هامش",
		claim: "ادّعاء",
		pivot: "انعطاف",
		conclusion: "نتيجة",
		decodeHelp: "اضغط جملة. إنجليزية مبسّطة ثم شرح عربي.",
		breakEn: "إنجليزية مبسّطة",
		breakAr: "الشرح العربي",
		vocab: "كلمات تستحق البقاء",
		coachHelp: "اختر نطاقًا. الخطة قراءة تدريبية للعرض، ليست وعدًا.",
		weak: "الجوانب الأضعف في هذا النموذج",
		week: "هذا الأسبوع",
		projected: "زيادة توضيحية",
		gap: "المسافة إلى أعلى النطاق",
		sampleFlag: "رقم ‎+110 هو التشخيص النموذجي للاستوديو، ويُعرض للتوضيح.",
		gapFlag: "هذا الرقم مسافة حتى أعلى النطاق، لا مكسب متوقّع.",
		build: "من 570 نحو 680",
		push: "من 650 نحو ‎750+"
	},
	results: {
		eyebrow: "حركة مُبلَّغ عنها",
		title: "تقريران. بلا اقتباسات مخترعة.",
		lede: "زيد ونانسي هما النتيجتان الموثّقتان. الإطارات الفارغة للقصة الحقيقية التالية — لا لمراجعة مزيفة.",
		before: "قبل",
		after: "بعد",
		rw: "القراءة والكتابة",
		enlarge: "تكبير",
		close: "إغلاق التقرير",
		placeholder: "عنصر نائب",
		placeholderBody: "أضف قصة طالب. الاقتباس والصورة والتقرير تبقى فارغة حتى تكون حقيقية.",
		only: "تُرسم النقطتان المُبلَّغ عنهما فقط. الخط لا يخترع الأشهر بينهما."
	},
	about: {
		eyebrow: "المدرّس",
		title: "زياد أحمد يدرّب القرار، لا التظليل.",
		lede: "أعلى 1٪ في السات. 36/36 في ACT English. عدة نتائج PSAT فوق 1500. أكثر من 23 ألف متابع. إنجليزي السات الرقمي لطلاب مصر والسعودية والإمارات.",
		noBio: "هذه الصفحة لا تخترع طفولة أو مدينة أو لحظة تحوّل لم تُذكر. السجل العام للاستوديو هو المعيار، والطريقة، وحركتا الدرجات المُبلَّغ عنهما.",
		pillars: "ثلاثة هوامش",
		quote: "لا أدرّس المحتوى فقط. أدرّبك كيف تفكّر."
	},
	programs: {
		eyebrow: "البرامج",
		title: "طريق، وطريق أضيق، وباب مجاني.",
		price: "[السعر]",
		priceNote: "يُؤكَّد على واتساب قبل الدفع.",
		ask: "اسأل على واتساب",
		spots: "مقاعد محدودة",
		popular: "معظم الطلاب",
		fit: "أي برنامج يناسبني؟",
		q1: "أين القراءة والكتابة الآن؟",
		q2: "كيف تريد أن تدرس؟",
		q3: "متى الاختبار؟",
		lt: "أقل من 600",
		mid: "600–700",
		hi: "700 فأكثر",
		group: "مجموعة مباشرة",
		private: "تدريب خاص",
		self: "أبدأ وحدي",
		soon: "خلال 6 أسابيع",
		season: "هذا الموسم",
		explore: "ما زلت أستكشف",
		next: "التالي",
		back: "رجوع",
		resultGroup: "ابدأ بالمجموعة المباشرة.",
		resultElite: "اسأل عن التدريب الفردي.",
		resultVault: "افتح الخزنة المجانية أولًا.",
		resultBodyGroup: "تريد رفقة وطريقًا كاملًا. المجموعة هي البرنامج الأساسي. اذكر درجتك على واتساب.",
		resultBodyElite: "طلبت خطة خاصة، أو أنت في نطاق مرتفع وتريد المقعد المحدود.",
		resultBodyVault: "تستكشف أو تريد البدء وحدك. خذ الماستر كلاس وخزنة الاختبار ثم قرّر.",
		restart: "أعد الأسئلة الثلاثة"
	},
	vault: {
		eyebrow: "الخزنة المجانية",
		title: "الماستر كلاس، وامتحان 11، ومجلد الأسئلة.",
		lede: "اترك اسمًا وبريدًا أو رقم واتساب. هذا العرض لا يكتب إلى خادم يراسلك — يؤكّد النموذج ويُظهر أين ستجلس الملفات.",
		name: "الاسم",
		contact: "البريد أو واتساب",
		note: "ملاحظة للاستوديو (اختياري)",
		send: "اطلب الخزنة",
		sending: "يُرسل…",
		thanks: "سُجّل الطلب داخل هذا العرض.",
		thanksBody: "لم يُرسل بريد. الموارد الثلاثة أدناه عناصر نائبة إلى أن يربط سكورهاي التسجيل الحقيقي وشرح امتحان 11 ومجلد درايف.",
		again: "إرسال طلب آخر",
		items: "ماذا تحوي الخزنة",
		master: "تسجيل الماستر كلاس",
		exam: "شرح امتحان بلو بوك 11",
		drive: "مجلد أسئلة حقيقية",
		locked: "رابط نائب",
		errName: "أضف اسمًا.",
		errContact: "أضف بريدًا أو رقم واتساب."
	},
	faq: {
		eyebrow: "أسئلة يسألها الأهل فعلًا",
		title: "إجابات مباشرة.",
		more: "كل الأسئلة"
	},
	cta: {
		title: "أحضر الإجابتين اللتين لا تفرّق بينهما.",
		lede: "أخبر زياد بالدرجة، وموعد الاختبار، وهل تريد المجموعة أم مقعدًا خاصًا.",
		button: "واتساب ‎+20 159 990 6731"
	},
	footer: {
		rights: "سكورهاي للسات · المدرّس زياد أحمد",
		trademark: "SAT علامة تجارية مسجّلة لـ College Board، وهي غير تابعة لسكورهاي.",
		instagram: "إنستغرام",
		tiktok: "تيك توك",
		whatsapp: "واتساب"
	},
	dash: {
		home: "اليوم",
		skills: "المهارات",
		vault: "خزنة الأخطاء",
		practice: "تدريب",
		vocab: "المفردات",
		teacher: "عرض المدرّس",
		exit: "الموقع",
		hello: "ورقة اليوم",
		mission: "ثلاث حركات",
		missionPractice: "أنهِ وحدة تدريب",
		missionVocab: "أنهِ 5 بطاقات مفردات",
		missionVault: "أعد بطاقة واحدة من الخزنة",
		streak: "أيام متتالية",
		week: "هذا الأسبوع",
		of: "من",
		gauge: "من تشخيصك",
		current: "الآن",
		target: "الهدف",
		estimate: "رسم تدريبي، لا درجة رسمية.",
		continue: "افتح وحدة",
		setup: "حدّد الهدف أولًا",
		due: "مستحق في الخزنة",
		onboardKicker: "تشخيص",
		onboardTitle: "ثلاث حقائق. ثم طريق.",
		name: "بماذا نناديك؟",
		namePh: "اسمك",
		currentQ: "القراءة والكتابة الآن",
		targetQ: "هدف القراءة والكتابة",
		dateQ: "شهر الاختبار",
		roadmap: "طريقك",
		enter: "ادخل الاستوديو",
		focus: "ابدأ بهذه",
		weeks: "جلسات قبل الشهر الذي اخترته",
		noDate: "لم يُختر شهر — الخطة تبقى أسبوعية على أي حال."
	},
	skills: {
		title: "خريطة المهارات",
		lede: "الإتقان يمتلئ من الوحدات التي تُسلّمها فعلًا في هذا العرض.",
		empty: "لا عناصر بعد",
		sample: "اعرض نموذجًا معلَّمًا",
		sampleOn: "جلسة نموذجية — ليست طالبًا حقيقيًا. لا تظهر في قائمة التقارير.",
		hide: "أخفِ النموذج",
		drill: "تدرّب على هذا الجانب"
	},
	errors: {
		title: "خزنة الأخطاء",
		lede: "كل خطأ يُحفظ، موسومًا بالوظيفة التي كانت تقوم بها الإجابة الخاطئة.",
		yours: "من وحداتك",
		samples: "بطاقات العرض",
		samplesNote: "هذه البطاقات الأربع نماذج حتى لا تكون الخزنة غرفة فارغة. ليست سجلًا خاصًا لطالب.",
		empty: "لا أخطاء شخصية بعد. أنهِ وحدة.",
		filter: "تصفية",
		all: "كل الفخاخ",
		retry: "إعادة",
		due: "مستحق",
		later: "لاحقًا",
		done: "استقر"
	},
	practice: {
		mod: "الوحدة",
		demo: "مؤقّت العرض",
		start: "ابدأ المؤقّت",
		pause: "إيقاف",
		marker: "قلم",
		eliminate: "استبعاد",
		flag: "علامة",
		flagged: "مُعلَّم",
		nav: "الفهرس",
		submit: "تسليم الوحدة",
		need: "بقيت أسئلة بلا إجابة. التسليم على أي حال؟",
		review: "مراجعة",
		your: "اختيارك",
		key: "المفتاح",
		nextMod: "إلى الوحدة 2",
		done: "اكتملت الوحدة",
		accuracy: "دقّة العرض",
		notOfficial: "ليست درجة سات رسمية. أربعة أسئلة ليست قسمًا.",
		again: "أعد ضبط العرض",
		dash: "العودة إلى اليوم",
		transition: "الوحدة 2",
		transitionBody: "تتغيّر المجموعة. الساعة نفسها، والفخاخ أضيق.",
		passage: "الفقرة",
		question: "السؤال",
		highlightHelp: "القلم يعمل. اضغط كلمة لتسطيرها."
	},
	vocab: {
		title: "ساحة المفردات",
		cards: "بطاقات",
		fire: "جولة سريعة",
		flip: "اقلب",
		knew: "عرفتها",
		missed: "فاتتني",
		streak: "سلسلة",
		xp: "نقاط",
		prompt: "أي كلمة تطابق؟",
		next: "البطاقة التالية"
	},
	teacher: {
		eyebrow: "عرض المدرّس",
		title: "ما هو موجود في الملف فعلًا.",
		lede: "زيد ونانسي يعرضان الدرجات المذكورة فقط. بلا نقاط أسبوعية مخترعة. الصف الثالث عنصر نائب. اللوحة الحيّة هي من يستخدم هذا المتصفح.",
		reported: "مُبلَّغ",
		placeholder: "عنصر نائب — أضف طالبًا",
		placeholderBody: "الاسم والدرجات والملاحظات تبقى فارغة عن قصد.",
		you: "هذا المتصفح",
		accuracy: "الدقّة الجارية",
		none: "لا وحدة مُسلَّمة في هذا المتصفح بعد.",
		domains: "الجوانب من العناصر المُسلَّمة"
	},
	common: { score: "الدرجة" }
};
function useT() {
	const lang = usePrefs((s) => s.lang);
	return {
		t: lang === "ar" ? ar : en,
		lang
	};
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/chrome-ixJ0YwnM.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var WA_DISPLAY = "+20 159 990 6731";
var WA_PHONE = "201599906731";
function waLink(text) {
	return `https://wa.me/${WA_PHONE}?text=${encodeURIComponent(text)}`;
}
var TIKTOK_URL = "https://www.tiktok.com/@scorehightutoring";
var INSTAGRAM_URL = "https://www.instagram.com/scorehightutoring/";
var links = [
	{
		to: "/lab",
		key: "lab"
	},
	{
		to: "/programs",
		key: "programs"
	},
	{
		to: "/vault",
		key: "vault"
	},
	{
		to: "/about",
		key: "about"
	},
	{
		to: "/faq",
		key: "faq"
	}
];
function enrollText(lang) {
	return lang === "ar" ? "مرحبًا، أريد السؤال عن التسجيل في ScoreHigh." : "Hello, I would like to ask about enrolling in ScoreHigh.";
}
function Header() {
	const { t, lang } = useT();
	const setLang = usePrefs((s) => s.setLang);
	const theme = usePrefs((s) => s.theme);
	const toggleTheme = usePrefs((s) => s.toggleTheme);
	const [open, setOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		document.body.style.overflow = open ? "hidden" : "";
		return () => {
			document.body.style.overflow = "";
		};
	}, [open]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-40 border-b border-line bg-paper",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex h-16 max-w-6xl items-center gap-3 px-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "flex items-center gap-2 font-display text-xl leading-none",
					onClick: () => setOpen(false),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "ScoreHigh" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "ms-6 hidden items-center gap-5 text-sm text-muted lg:flex",
					"aria-label": "Primary",
					children: links.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: item.to,
						className: "hover:text-ink",
						activeProps: { className: "text-ink" },
						children: t.nav[item.key]
					}, item.to))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ms-auto flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex rounded-full border border-line p-0.5 text-xs font-semibold",
							role: "group",
							"aria-label": t.nav.language,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: cn("min-h-9 rounded-full px-2.5", lang === "en" && "bg-ink text-paper"),
								"aria-pressed": lang === "en",
								onClick: () => setLang("en"),
								children: "EN"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: cn("min-h-9 rounded-full px-2.5", lang === "ar" && "bg-ink text-paper"),
								"aria-pressed": lang === "ar",
								onClick: () => setLang("ar"),
								children: "ع"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "grid size-11 place-items-center rounded-full border border-line",
							onClick: toggleTheme,
							"aria-label": theme === "dark" ? t.nav.themeToLight : t.nav.themeToDark,
							children: theme === "dark" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: waLink(enrollText(lang)),
							className: "hidden min-h-11 items-center rounded-full bg-signal px-4 text-sm font-semibold text-ink sm:inline-flex",
							children: t.nav.enroll
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "grid size-11 place-items-center rounded-full border border-line lg:hidden",
							"aria-expanded": open,
							"aria-label": open ? t.nav.close : t.nav.menu,
							onClick: () => setOpen((v) => !v),
							children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
						})
					]
				})
			]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border-t border-line bg-paper px-4 py-6 lg:hidden",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "grid gap-1",
				"aria-label": "Mobile",
				children: [links.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: item.to,
					onClick: () => setOpen(false),
					className: "font-display text-4xl leading-tight",
					children: t.nav[item.key]
				}, item.to)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/dashboard",
					onClick: () => setOpen(false),
					className: "mt-3 text-sm text-muted",
					children: t.nav.student
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: waLink(enrollText(lang)),
				className: "mt-6 inline-flex min-h-12 items-center rounded-full bg-signal px-5 font-semibold text-ink",
				children: t.nav.enroll
			})]
		}) : null]
	});
}
function Mark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: "size-8",
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "3",
				y: "2",
				width: "22",
				height: "28",
				rx: "2",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.6"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M8 22h12",
				stroke: "var(--mark)",
				strokeWidth: "3",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M20 6.5h6.5v6.5",
				fill: "none",
				stroke: "var(--trap)",
				strokeWidth: "1.6"
			})
		]
	});
}
function Footer() {
	const { t, lang } = useT();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "border-t border-line",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-8 px-4 py-12 md:grid-cols-[1.4fr_1fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-3xl",
					children: "ScoreHigh"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-md text-sm text-muted",
					children: t.footer.rights
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-xl text-xs leading-relaxed text-muted",
					children: t.footer.trademark
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap content-start gap-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						className: "inline-flex min-h-11 items-center rounded-full border border-line px-4",
						href: waLink(enrollText(lang)),
						children: [
							t.footer.whatsapp,
							" · ",
							WA_DISPLAY
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "inline-flex min-h-11 items-center rounded-full border border-line px-4",
						href: INSTAGRAM_URL,
						children: t.footer.instagram
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "inline-flex min-h-11 items-center rounded-full border border-line px-4",
						href: TIKTOK_URL,
						children: t.footer.tiktok
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/dashboard",
						className: "inline-flex min-h-11 items-center rounded-full border border-line px-4",
						children: t.nav.student
					})
				]
			})]
		})
	});
}
function SiteFrame({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-paper text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#main",
				className: "sr-only focus:not-sr-only focus:absolute focus:z-50 focus:m-3 focus:rounded-full focus:bg-signal focus:px-4 focus:py-2 focus:text-ink",
				children: "Skip to content"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreRail, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				id: "main",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
		]
	});
}
function ScoreRail() {
	const [progress, setProgress] = (0, import_react.useState)(8);
	(0, import_react.useEffect)(() => {
		const onScroll = () => {
			const max = document.documentElement.scrollHeight - window.innerHeight;
			const next = max <= 0 ? 8 : Math.min(100, Math.max(8, window.scrollY / max * 100));
			setProgress(next);
		};
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none fixed top-16 bottom-0 start-3 z-30 hidden w-10 lg:block",
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-y-24 start-4 w-px bg-line" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute start-4 bottom-24 w-px bg-mark",
				style: { height: `calc((100% - 12rem) * ${progress / 100})` }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute start-0 top-20 font-mono text-xs text-muted",
				children: "800"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute start-0 top-1/2 font-mono text-xs text-muted",
				children: "600"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "absolute start-0 bottom-16 font-mono text-xs text-muted",
				children: "400"
			})
		]
	});
}
function WaButton({ children, message, variant = "signal", className }) {
	const look = variant === "ink" ? "bg-ink text-paper" : variant === "ghost" ? "border border-line bg-transparent text-ink" : "bg-signal text-ink";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		href: waLink(message),
		className: cn("inline-flex min-h-12 items-center justify-center rounded-full px-5 text-sm font-semibold", look, className),
		children
	});
}
//#endregion
export { dueCount as a, usePrefs as c, cn as i, useT as l, SiteFrame as n, missionCount as o, WaButton as r, todayKey as s, Mark as t };
