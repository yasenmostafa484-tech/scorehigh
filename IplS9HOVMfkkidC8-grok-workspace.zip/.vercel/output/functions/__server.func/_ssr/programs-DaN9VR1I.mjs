import { i as __toESM } from "../_runtime.mjs";
import { _ as require_react, g as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { i as cn, l as useT, n as SiteFrame, r as WaButton } from "./chrome-ixJ0YwnM.mjs";
import { m as programs, r as FinalCta } from "./router-DNg9Mb-U.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/programs-DaN9VR1I.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function FitQuiz() {
	const { t, lang } = useT();
	const [step, setStep] = (0, import_react.useState)(0);
	const [band, setBand] = (0, import_react.useState)(null);
	const [style, setStyle] = (0, import_react.useState)(null);
	const [when, setWhen] = (0, import_react.useState)(null);
	const result = style === "self" || when === "explore" ? "vault" : style === "private" || band === "hi" ? "elite" : "group";
	const steps = [
		{
			q: t.programs.q1,
			value: band,
			set: (v) => setBand(v),
			options: [
				{
					id: "lt",
					label: t.programs.lt
				},
				{
					id: "mid",
					label: t.programs.mid
				},
				{
					id: "hi",
					label: t.programs.hi
				}
			]
		},
		{
			q: t.programs.q2,
			value: style,
			set: (v) => setStyle(v),
			options: [
				{
					id: "group",
					label: t.programs.group
				},
				{
					id: "private",
					label: t.programs.private
				},
				{
					id: "self",
					label: t.programs.self
				}
			]
		},
		{
			q: t.programs.q3,
			value: when,
			set: (v) => setWhen(v),
			options: [
				{
					id: "soon",
					label: t.programs.soon
				},
				{
					id: "season",
					label: t.programs.season
				},
				{
					id: "explore",
					label: t.programs.explore
				}
			]
		}
	];
	if (step >= 3) {
		const title = result === "elite" ? t.programs.resultElite : result === "vault" ? t.programs.resultVault : t.programs.resultGroup;
		const body = result === "elite" ? t.programs.resultBodyElite : result === "vault" ? t.programs.resultBodyVault : t.programs.resultBodyGroup;
		const message = lang === "ar" ? `مرحبًا، أوصى الموقع ببرنامج ${result}. أريد التفاصيل.` : `Hello, the site recommended the ${result} program. I'd like the details.`;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border border-line bg-sheet p-5 sm:p-7",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-xs tracking-stamp text-mark uppercase",
					children: t.programs.fit
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-3 font-display text-4xl leading-none",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-xl text-muted",
					children: body
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap gap-3",
					children: [result === "vault" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/vault",
						className: "inline-flex min-h-12 items-center rounded-full bg-signal px-5 font-semibold text-ink",
						children: t.nav.vault
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WaButton, {
						message,
						children: t.programs.ask
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-12 rounded-full border border-line px-5 text-sm",
						onClick: () => {
							setStep(0);
							setBand(null);
							setStyle(null);
							setWhen(null);
						},
						children: t.programs.restart
					})]
				})
			]
		});
	}
	const current = steps[step];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border border-line bg-sheet p-5 sm:p-7",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "font-mono text-xs text-muted",
				children: [
					"0",
					step + 1,
					" / 03 · ",
					t.programs.fit
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-3 font-display text-3xl leading-none",
				children: current.q
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 grid gap-2",
				children: current.options.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => current.set(option.id),
					className: cn("min-h-12 border px-4 text-start", current.value === option.id ? "border-ink bg-paper" : "border-line"),
					children: option.label
				}, option.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 flex gap-2",
				children: [step > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "min-h-11 rounded-full border border-line px-4",
					onClick: () => setStep((s) => s - 1),
					children: t.programs.back
				}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: !current.value,
					className: "min-h-11 rounded-full bg-ink px-4 font-semibold text-paper disabled:opacity-40",
					onClick: () => setStep((s) => s + 1),
					children: t.programs.next
				})]
			})
		]
	});
}
function ProgramsPage() {
	const { t, lang } = useT();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteFrame, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-6xl px-4 py-14",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-xs tracking-stamp text-mark uppercase",
				children: t.programs.eyebrow
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 max-w-3xl font-display text-5xl leading-none sm:text-6xl",
				children: t.programs.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 grid gap-5",
				children: programs.map((program) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: cn("grid gap-6 border p-5 sm:p-7 lg:grid-cols-[0.8fr_1.2fr]", program.id === "group" && "border-ink bg-ink text-paper", program.id === "elite" && "border-dashed border-trap bg-sheet", program.id === "vault" && "border-line bg-paper"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: cn("font-mono text-xs tracking-stamp uppercase", program.id === "group" ? "text-signal" : program.id === "elite" ? "text-trap" : "text-mark"),
							children: lang === "ar" ? program.tagAr : program.tagEn
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: cn("mt-3 font-display text-4xl", program.id === "group" && "text-paper"),
							children: lang === "ar" ? program.ar : program.en
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: cn("mt-4 font-display text-5xl", program.id === "group" && "text-signal"),
							children: program.id === "vault" ? lang === "ar" ? "مجاني" : "Free" : t.programs.price
						}),
						program.id !== "vault" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: cn("mt-1 text-sm", program.id === "group" ? "text-paper/75" : "text-muted"),
							children: t.programs.priceNote
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-5",
							children: program.id === "vault" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "/vault",
								className: "inline-flex min-h-12 items-center rounded-full bg-signal px-5 font-semibold text-ink",
								children: t.nav.vault
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WaButton, {
								message: lang === "ar" ? `مرحبًا، أريد برنامج ${program.ar}. ما السعر والمقاعد؟` : `Hello, I want the ${program.en}. What is the price and availability?`,
								variant: program.id === "group" ? "signal" : "ink",
								children: t.programs.ask
							})
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-3 text-sm",
						children: program.points.map((point) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "border-s-2 border-signal ps-3",
							children: lang === "ar" ? point.ar : point.en
						}, point.en))
					})]
				}, program.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FitQuiz, {})
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FinalCta, {})] });
}
//#endregion
export { ProgramsPage as component };
