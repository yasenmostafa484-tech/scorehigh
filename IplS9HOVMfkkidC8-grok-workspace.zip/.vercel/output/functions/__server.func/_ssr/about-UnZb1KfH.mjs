import { g as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { l as useT, n as SiteFrame } from "./chrome-ixJ0YwnM.mjs";
import { i as Pillars, r as FinalCta } from "./router-DNg9Mb-U.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-UnZb1KfH.js
var import_jsx_runtime = require_jsx_runtime();
function AboutPage() {
	const { t } = useT();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteFrame, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto grid max-w-6xl gap-10 px-4 py-14 lg:grid-cols-[1.1fr_0.9fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-xs tracking-stamp text-mark uppercase",
					children: t.about.eyebrow
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 font-display text-5xl leading-none sm:text-6xl",
					children: t.about.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-lg text-muted",
					children: t.about.lede
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-muted",
					children: t.about.noBio
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
					className: "mt-8 font-display text-3xl italic leading-snug",
					children: t.about.quote
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border border-line bg-sheet p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-7xl leading-none",
						children: "Z.A."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-6 space-y-3 font-mono text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "border-b border-line pb-2",
								children: "Top 1% SAT"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "border-b border-line pb-2",
								children: "36/36 ACT English"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "border-b border-line pb-2",
								children: "1500+ PSAT · multiple"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "23K+ followers" })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-sm text-muted",
						children: t.about.pillars
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "mx-auto max-w-6xl px-4 pb-16",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pillars, {})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FinalCta, {})
	] });
}
//#endregion
export { AboutPage as component };
