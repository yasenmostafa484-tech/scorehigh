//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DhzB8_lm.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/dashboard",
			"/error-vault",
			"/faq",
			"/lab",
			"/practice",
			"/programs",
			"/skills",
			"/teacher",
			"/vault",
			"/vocab",
			"/api/diagnostics",
			"/api/leads",
			"/api/questions"
		],
		preloads: [
			"/assets/index-Bbe4xU_c.js",
			"/assets/use-t-KAegUDOu.js",
			"/assets/preload-helper-3gp0G7DZ.js",
			"/assets/chrome-CSuAZl5Y.js",
			"/assets/content-C2icOGwG.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Bbe4xU_c.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-B4W-NQTR.js",
			"/assets/faq-list-C7leoDL3.js",
			"/assets/lab-panel-B47jJYwg.js"
		]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-BfOPJgHd.js"]
	},
	"/dashboard": {
		filePath: "/workspace/src/routes/dashboard.tsx",
		children: void 0,
		preloads: ["/assets/dashboard-DZofQaW_.js", "/assets/shell-Ce52MuoF.js"]
	},
	"/error-vault": {
		filePath: "/workspace/src/routes/error-vault.tsx",
		children: void 0,
		preloads: ["/assets/error-vault-10r3JHbJ.js", "/assets/shell-Ce52MuoF.js"]
	},
	"/faq": {
		filePath: "/workspace/src/routes/faq.tsx",
		children: void 0,
		preloads: ["/assets/faq-JwX5pclP.js", "/assets/faq-list-C7leoDL3.js"]
	},
	"/lab": {
		filePath: "/workspace/src/routes/lab.tsx",
		children: void 0,
		preloads: ["/assets/lab-BJjjBRyP.js", "/assets/lab-panel-B47jJYwg.js"]
	},
	"/practice": {
		filePath: "/workspace/src/routes/practice.tsx",
		children: void 0,
		preloads: ["/assets/practice-CYTNj3y4.js"]
	},
	"/programs": {
		filePath: "/workspace/src/routes/programs.tsx",
		children: void 0,
		preloads: ["/assets/programs-Cy-T0myn.js"]
	},
	"/skills": {
		filePath: "/workspace/src/routes/skills.tsx",
		children: void 0,
		preloads: ["/assets/skills-gJvpHVwx.js", "/assets/shell-Ce52MuoF.js"]
	},
	"/teacher": {
		filePath: "/workspace/src/routes/teacher.tsx",
		children: void 0,
		preloads: ["/assets/teacher-Dm7zHmJC.js", "/assets/shell-Ce52MuoF.js"]
	},
	"/vault": {
		filePath: "/workspace/src/routes/vault.tsx",
		children: void 0,
		preloads: ["/assets/vault-DXzQY4U3.js"]
	},
	"/vocab": {
		filePath: "/workspace/src/routes/vocab.tsx",
		children: void 0,
		preloads: ["/assets/vocab-C0W9CwLP.js", "/assets/shell-Ce52MuoF.js"]
	}
} });
//#endregion
export { tsrStartManifest };
